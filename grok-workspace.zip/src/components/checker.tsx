import { useEffect, useId, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { AlertTriangle, BookOpen, Check, ChevronDown, Copy, Info, Search, Trash2, X } from "lucide-react";
import { BUCKETS, DRUG_BY_ID, DRUGS, QUICK_ADD, drugsFromIds } from "@/data/catalog";
import type { Drug, Severity } from "@/data/types";
import { checkInteractions, summaryText } from "@/lib/check";
import { searchDrugs } from "@/lib/search";

const STORAGE_KEY = "layman.list.v1";
const MAX_ITEMS = 12;

const EXAMPLES: { id: string; label: string; detail: string; ids: string[] }[] = [
  {
    id: "bleed",
    label: "Warfarin + ibuprofen",
    detail: "A common bleed",
    ids: ["warfarin", "ibuprofen"],
  },
  {
    id: "triple",
    label: "Pressure trio",
    detail: "Kidneys, not just pressure",
    ids: ["lisinopril", "hydrochlorothiazide", "ibuprofen"],
  },
  {
    id: "cns",
    label: "Oxycodone + Xanax",
    detail: "Breathing risk",
    ids: ["oxycodone", "alprazolam"],
  },
  {
    id: "nitrate",
    label: "Nitro + sildenafil",
    detail: "Pressure crash",
    ids: ["nitroglycerin", "sildenafil"],
  },
  {
    id: "quiet",
    label: "Lisinopril + metformin",
    detail: "Often quiet in our list",
    ids: ["lisinopril", "metformin"],
  },
  {
    id: "minerals",
    label: "Cipro + iron",
    detail: "Neither one absorbs",
    ids: ["ciprofloxacin", "ferrous-sulfate"],
  },
  {
    id: "kratom",
    label: "Kratom + oxycodone",
    detail: "Opioid-like stacking",
    ids: ["kratom", "oxycodone"],
  },
];

const SEVERITY_META: Record<
  Severity,
  { label: string; hint: string; badge: string; banner: string; icon: typeof AlertTriangle }
> = {
  major: {
    label: "Serious",
    hint: "Ask before combining",
    badge: "bg-terra-soft text-terra",
    banner: "bg-terra-soft",
    icon: AlertTriangle,
  },
  moderate: {
    label: "Worth a conversation",
    hint: "Don’t ignore it",
    badge: "bg-amber-soft text-amber",
    banner: "bg-amber-soft",
    icon: Info,
  },
  minor: {
    label: "Smaller note",
    hint: "Still mention it",
    badge: "bg-minor-soft text-minor",
    banner: "bg-minor-soft",
    icon: Info,
  },
};

function brandLine(drug: Drug): string {
  if (drug.brands.length === 0) return drug.usedFor;
  return drug.brands.slice(0, 2).join(", ");
}

export function Checker() {
  if (typeof document !== "undefined") document.title = "Rx Mix";

  const [ids, setIds] = useState<string[]>([]);
  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const [bucket, setBucket] = useState<string | null>(null);
  const [focusId, setFocusId] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | Severity>("all");
  const [copied, setCopied] = useState(false);
  const [fullNotice, setFullNotice] = useState(false);
  const listId = useId();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          const next = parsed.filter((id): id is string => typeof id === "string" && DRUG_BY_ID.has(id));
          setIds(next.slice(0, MAX_ITEMS));
        }
      }
    } catch {
      /* ignore broken local storage */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
  }, [ids, ready]);

  const matches = useMemo(() => searchDrugs(query, 8), [query]);
  const drugs = useMemo(() => drugsFromIds(ids), [ids]);
  const report = useMemo(() => checkInteractions(drugs), [drugs]);
  const activeFilter: "all" | Severity =
    filter !== "all" && report.counts[filter] === 0 ? "all" : filter;
  const visibleFindings = report.findings.filter(
    (finding) => activeFilter === "all" || finding.severity === activeFilter,
  );
  const focused = focusId ? DRUG_BY_ID.get(focusId) : undefined;
  const bucketDrugs = bucket ? DRUGS.filter((drug) => drug.bucket === bucket) : [];

  function add(id: string) {
    setFullNotice(false);
    if (ids.includes(id)) {
      setQuery("");
      setOpen(false);
      setFocusId(id);
      return;
    }
    if (ids.length >= MAX_ITEMS) {
      setFullNotice(true);
      setOpen(false);
      return;
    }
    setIds((current) => [id, ...current]);
    setQuery("");
    setOpen(false);
    setHighlight(0);
    setFocusId(id);
    inputRef.current?.focus();
  }

  function remove(id: string) {
    setIds((current) => current.filter((item) => item !== id));
    setFocusId((current) => (current === id ? null : current));
  }

  function loadExample(next: string[]) {
    setIds(next);
    setFocusId(next[0] ?? null);
    setFilter("all");
    setFullNotice(false);
  }

  async function copySummary() {
    const text = summaryText(drugs, report);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  function onKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setOpen(true);
      setHighlight((index) => Math.min(index + 1, Math.max(matches.length - 1, 0)));
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setHighlight((index) => Math.max(index - 1, 0));
    } else if (event.key === "Escape") {
      setOpen(false);
    } else if (event.key === "Enter") {
      event.preventDefault();
      const pick = matches[highlight] ?? matches[0];
      if (pick) add(pick.id);
    }
  }

  const summary = buildSummary(drugs.length, report.highest, report.counts);

  return (
    <div className="min-h-screen">
      <header className="no-print sticky top-0 z-20 border-b border-line bg-paper">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-3">
            <span
              className="flex size-11 items-center justify-center rounded-xl bg-green font-sans text-lg font-bold leading-none tracking-tight text-card"
              aria-hidden="true"
            >
              RX
            </span>
            <div>
              <p className="font-sans text-xl font-bold leading-none tracking-tight text-ink">Rx Mix</p>
              <p className="text-sm text-muted">Medicines, in plain English</p>
            </div>
          </div>
          <p className="hidden max-w-xs text-right text-sm text-muted sm:block">
            A curated check. Not a diagnosis, and not a full database.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 sm:py-8">
        <div className="max-w-3xl">
          <h1 className="text-3xl text-ink sm:text-4xl">What happens when these are taken together?</h1>
          <p className="mt-3 text-lg text-muted">
            Add two or more medicines. Overlaps we know about are explained the way a careful pharmacist might say
            them out loud — what it means, and what to ask before anything changes.
          </p>
        </div>

        <p className="mt-5 max-w-3xl rounded-2xl border border-line bg-card px-4 py-3 text-sm text-ink">
          <span className="font-semibold">Educational only.</span> This is not medical advice, not a complete
          interaction list, and not a reason to start, stop, or change a medicine. Emergencies — trouble breathing,
          blue lips, chest pain, vomiting blood, black stools, a sudden severe headache, a seizure, or a blistering
          rash — need emergency services, not this page.
        </p>

        <div className="mt-6 grid items-start gap-6 lg:grid-cols-[22rem_minmax(0,1fr)]">
          <section className="no-print rounded-3xl border border-line bg-card p-4 sm:p-5">
            <h2 className="text-2xl text-ink">Your list</h2>
            <p className="mt-1 text-sm text-muted">Generic names, brands, and a few everyday extras.</p>

            <form
              className="relative mt-4"
              onSubmit={(event) => {
                event.preventDefault();
                const pick = matches[highlight] ?? matches[0];
                if (pick) add(pick.id);
              }}
            >
              <label htmlFor="med-search" className="sr-only">
                Search medicines
              </label>
              <Search className="pointer-events-none absolute top-1/2 left-3 size-5 -translate-y-1/2 text-muted" aria-hidden="true" />
              <input
                id="med-search"
                ref={inputRef}
                role="combobox"
                aria-expanded={open && query.trim().length > 0}
                aria-controls={listId}
                aria-autocomplete="list"
                value={query}
                placeholder="Try Lipitor, kratom, iron, vitamin C…"
                className="h-12 w-full rounded-xl border border-line bg-paper pr-4 pl-11 text-base text-ink placeholder:text-muted"
                onChange={(event) => {
                  setQuery(event.target.value);
                  setOpen(true);
                  setHighlight(0);
                }}
                onFocus={() => setOpen(true)}
                onKeyDown={onKeyDown}
              />
              {open && query.trim().length > 0 && (
                <ul
                  id={listId}
                  role="listbox"
                  className="absolute z-30 mt-1 max-h-80 w-full overflow-auto rounded-xl border border-line bg-card"
                >
                  {matches.length === 0 ? (
                    <li className="px-4 py-3 text-sm text-muted">
                      We don’t have that one. This list is common prescriptions, a few supplements, plus alcohol and
                      grapefruit — not every product on the shelf.
                    </li>
                  ) : (
                    matches.map((drug, index) => (
                      <li key={drug.id} role="option" aria-selected={index === highlight}>
                        <button
                          type="button"
                          className={`flex min-h-11 w-full flex-col items-start px-4 py-2 text-left ${
                            index === highlight ? "bg-green-soft" : "bg-card"
                          }`}
                          onMouseEnter={() => setHighlight(index)}
                          onMouseDown={(event) => event.preventDefault()}
                          onClick={() => add(drug.id)}
                        >
                          <span className="font-semibold text-ink">{drug.generic}</span>
                          <span className="text-sm text-muted">
                            {brandLine(drug)} · {drug.bucket}
                          </span>
                        </button>
                      </li>
                    ))
                  )}
                </ul>
              )}
            </form>

            {fullNotice && (
              <p className="mt-3 text-sm text-terra" role="status">
                Twelve is the limit here so the reading stays usable. A pharmacist should see a longer list.
              </p>
            )}

            <div className="mt-4">
              <p className="text-xs font-semibold tracking-wide text-muted uppercase">Quick add</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {QUICK_ADD.map((id) => {
                  const drug = DRUG_BY_ID.get(id);
                  if (!drug) return null;
                  const added = ids.includes(id);
                  return (
                    <button
                      key={id}
                      type="button"
                      disabled={added}
                      onClick={() => add(id)}
                      className="inline-flex min-h-11 items-center gap-1 rounded-full border border-line bg-paper px-3 text-sm font-semibold text-ink disabled:text-muted"
                    >
                      {added ? <Check className="size-4 text-green" aria-hidden="true" /> : <span aria-hidden="true">+</span>}
                      {drug.generic}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-5">
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="text-lg text-ink">
                  Checking <span className="tabular-nums">{drugs.length}</span>
                </h3>
                {drugs.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setIds([]);
                      setFocusId(null);
                    }}
                    className="inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-muted"
                  >
                    <Trash2 className="size-4" aria-hidden="true" />
                    Clear
                  </button>
                )}
              </div>
              {drugs.length === 0 ? (
                <p className="mt-2 text-sm text-muted">Nothing yet. Two items is enough to start. One still shows cautions.</p>
              ) : (
                <ul className="mt-2 flex flex-col gap-2">
                  {drugs.map((drug) => {
                    const selected = focusId === drug.id;
                    return (
                      <li key={drug.id} className="flex items-stretch gap-2">
                        <button
                          type="button"
                          aria-expanded={selected}
                          onClick={() => setFocusId(selected ? null : drug.id)}
                          className={`flex min-h-11 min-w-0 flex-1 flex-col items-start rounded-xl border px-3 py-2 text-left ${
                            selected ? "border-green bg-green-soft" : "border-line bg-paper"
                          }`}
                        >
                          <span className="font-semibold text-ink">{drug.generic}</span>
                          <span className="truncate text-sm text-muted">{brandLine(drug)}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => remove(drug.id)}
                          aria-label={`Remove ${drug.generic}`}
                          className="inline-flex size-11 shrink-0 items-center justify-center rounded-xl border border-line text-muted"
                        >
                          <X className="size-4" />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>

            {focused && (
              <article className="mt-4 rounded-2xl border border-line bg-paper p-4">
                <p className="text-xs font-semibold tracking-wide text-muted uppercase">{focused.bucket}</p>
                <h3 className="mt-1 text-2xl text-ink">{focused.generic}</h3>
                <p className="mt-2 text-sm text-ink">{focused.plain}</p>
                <p className="mt-2 text-sm text-muted">Often used for {focused.usedFor.toLowerCase()}.</p>
                {focused.brands.length > 0 && (
                  <p className="mt-2 text-sm text-muted">Also seen as {focused.brands.join(", ")}.</p>
                )}
              </article>
            )}

            <div className="mt-5">
              <p className="text-xs font-semibold tracking-wide text-muted uppercase">Load an example</p>
              <div className="mt-2 flex flex-col gap-2">
                {EXAMPLES.map((example) => (
                  <button
                    key={example.id}
                    type="button"
                    onClick={() => loadExample(example.ids)}
                    className="flex min-h-11 items-center justify-between gap-3 rounded-xl border border-line px-3 py-2 text-left"
                  >
                    <span>
                      <span className="block font-semibold text-ink">{example.label}</span>
                      <span className="block text-sm text-muted">{example.detail}</span>
                    </span>
                    <ChevronDown className="size-4 -rotate-90 text-muted" aria-hidden="true" />
                  </button>
                ))}
              </div>
            </div>

            <details className="mt-5 border-t border-line pt-4">
              <summary className="flex min-h-11 items-center justify-between gap-3 text-sm font-semibold text-ink">
                Browse by type
                <ChevronDown className="size-4 text-muted" aria-hidden="true" />
              </summary>
              <div className="mt-3 flex flex-wrap gap-2">
                {BUCKETS.map((name) => (
                  <button
                    key={name}
                    type="button"
                    aria-pressed={bucket === name}
                    onClick={() => setBucket((current) => (current === name ? null : name))}
                    className={`min-h-11 rounded-full border px-3 text-sm font-semibold ${
                      bucket === name ? "border-green bg-green text-card" : "border-line bg-paper text-ink"
                    }`}
                  >
                    {name}
                  </button>
                ))}
              </div>
              {bucket && (
                <ul className="mt-3 max-h-64 overflow-auto rounded-xl border border-line">
                  {bucketDrugs.map((drug) => {
                    const added = ids.includes(drug.id);
                    return (
                      <li key={drug.id} className="border-b border-line last:border-b-0">
                        <button
                          type="button"
                          disabled={added}
                          onClick={() => add(drug.id)}
                          className="flex min-h-11 w-full items-center justify-between gap-3 px-3 text-left disabled:text-muted"
                        >
                          <span>
                            <span className="block font-semibold">{drug.generic}</span>
                            <span className="block text-sm text-muted">{brandLine(drug)}</span>
                          </span>
                          {added ? <Check className="size-4 text-green" aria-hidden="true" /> : <span className="text-sm">Add</span>}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </details>
          </section>

          <section aria-live="polite">
            <div className={`rounded-3xl border border-line px-4 py-4 sm:px-5 ${summary.panel}`}>
              <p className={`text-sm font-semibold ${summary.kicker}`}>{summary.kickerText}</p>
              <h2 className="mt-1 text-3xl text-ink">{summary.title}</h2>
              <p className="mt-2 text-ink">{summary.body}</p>
              {drugs.length >= 2 && report.findings.length > 0 && (
                <p className="mt-3 text-sm font-semibold text-muted tabular-nums">
                  {report.counts.major} serious · {report.counts.moderate} to discuss · {report.counts.minor} smaller
                </p>
              )}
            </div>

            {drugs.length >= 2 && (
              <div className="no-print mt-4 flex flex-wrap gap-2">
                {(
                  [
                    ["all", "All"],
                    ["major", "Serious"],
                    ["moderate", "Conversation"],
                    ["minor", "Smaller"],
                  ] as const
                ).map(([key, label]) => {
                  const count = key === "all" ? report.findings.length : report.counts[key];
                  const selected = activeFilter === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      aria-pressed={selected}
                      disabled={count === 0}
                      onClick={() => setFilter(key)}
                      className={`min-h-11 rounded-full border px-3 text-sm font-semibold disabled:opacity-40 ${
                        selected ? "border-green bg-green text-card" : "border-line bg-card text-ink"
                      }`}
                    >
                      {label} <span className="tabular-nums">{count}</span>
                    </button>
                  );
                })}
                <button
                  type="button"
                  onClick={() => void copySummary()}
                  className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-card px-3 text-sm font-semibold text-ink"
                >
                  {copied ? <Check className="size-4 text-green" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
                  {copied ? "Copied" : "Copy for a pharmacist"}
                </button>
              </div>
            )}

            {drugs.length === 0 && <Intro />}

            {drugs.length === 1 && drugs[0] && (
              <p className="mt-4 text-sm text-muted">
                Add another item to check overlaps. Cautions for {drugs[0].generic} are below either way.
              </p>
            )}

            {drugs.length >= 2 && report.findings.length === 0 && (
              <article className="mt-4 rounded-3xl border border-line bg-card p-5">
                <h3 className="text-2xl text-ink">What “nothing found” does and doesn’t mean</h3>
                <p className="mt-2 text-ink">
                  These items don’t hit a rule in our curated set. That set is common medicines and well-known
                  overlaps — not every dose, gene, food, or new warning. A pharmacist with your full bottle list is
                  still the right check.
                </p>
              </article>
            )}

            <div className="mt-4 flex flex-col gap-4">
              {visibleFindings.map((finding) => {
                const meta = SEVERITY_META[finding.severity];
                const Icon = meta.icon;
                const names = finding.drugIds
                  .map((id) => DRUG_BY_ID.get(id)?.generic)
                  .filter((name): name is string => Boolean(name));
                return (
                  <article key={finding.id} className="rounded-3xl border border-line bg-card p-5">
                    <p className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-semibold ${meta.badge}`}>
                      <Icon className="size-4" aria-hidden="true" />
                      {meta.label}
                      <span className="font-medium">· {meta.hint}</span>
                    </p>
                    <h3 className="mt-3 text-2xl text-ink">{finding.title}</h3>
                    <p className="mt-2 text-base text-ink">{finding.plain}</p>
                    <div className={`mt-4 rounded-2xl px-4 py-3 ${meta.banner}`}>
                      <p className="text-xs font-semibold tracking-wide text-muted uppercase">What to do</p>
                      <p className="mt-1 text-ink">{finding.whatToDo}</p>
                    </div>
                    <details className="mt-3">
                      <summary className="flex min-h-11 items-center gap-2 text-sm font-semibold text-green-ink">
                        <BookOpen className="size-4" aria-hidden="true" />
                        Why this happens
                      </summary>
                      <p className="pb-2 text-sm text-ink">{finding.why}</p>
                    </details>
                    <p className="text-sm text-muted">On your list: {names.join(", ")}</p>
                  </article>
                );
              })}
            </div>

            {drugs.length > 0 && (
              <div className="mt-4 rounded-3xl border border-line bg-card p-5">
                <h3 className="text-2xl text-ink">Everyday cautions</h3>
                <p className="mt-1 text-sm text-muted">These travel with the medicine itself, even when no pair lit up.</p>
                <ul className="mt-4 flex flex-col gap-4">
                  {drugs.map((drug) => (
                    <li key={drug.id}>
                      <p className="font-semibold text-ink">{drug.generic}</p>
                      <ul className="mt-1 flex flex-col gap-1">
                        {drug.watch.map((item) => (
                          <li key={item} className="text-sm text-ink">
                            {item}
                          </li>
                        ))}
                      </ul>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        </div>

        <footer className="mt-10 max-w-3xl border-t border-line pt-6 text-sm text-muted">
          <p>
            Rx Mix covers a fixed, editorial set of common drugs, supplements (including minerals, vitamin C, probiotics, and kratom), alcohol, and grapefruit.
            It can miss rare, dose-dependent, genetic, and newly discovered interactions. Wording is simplified from
            patterns described in drug labels and standard references. It is not those references, and it is not a
            substitute for a pharmacist, clinician, or emergency service.
          </p>
        </footer>
      </main>
    </div>
  );
}

function Intro() {
  return (
    <div className="mt-4 grid gap-3 sm:grid-cols-3">
      {(
        [
          ["Serious", "Ask before combining", "Blood pressure crashes, slowed breathing, bleeding, kidney injury."],
          ["Conversation", "Don’t shrug it off", "Dose caps, lab checks, or a pairing that is sometimes intentional."],
          ["Smaller note", "Mention it anyway", "Duplicate bottles, timing gaps, supplements with a mild effect."],
        ] as const
      ).map(([title, hint, body]) => (
        <article key={title} className="rounded-2xl border border-line bg-card p-4">
          <h3 className="text-xl text-ink">{title}</h3>
          <p className="mt-1 text-sm font-semibold text-green-ink">{hint}</p>
          <p className="mt-2 text-sm text-muted">{body}</p>
        </article>
      ))}
    </div>
  );
}

function buildSummary(
  count: number,
  highest: Severity | null,
  counts: Record<Severity, number>,
): { title: string; body: string; kickerText: string; kicker: string; panel: string } {
  if (count === 0) {
    return {
      kickerText: "How a result reads",
      kicker: "text-green-ink",
      title: "Plain language, sorted by how much it matters",
      body: "Try aspirin and ibuprofen, or load an example. A quiet result is shown honestly — silence here is not a safety certificate.",
      panel: "bg-card",
    };
  }
  if (count === 1) {
    return {
      kickerText: "One item",
      kicker: "text-muted",
      title: "Add a second to check an overlap",
      body: "Single medicines still carry their own cautions — timing, food, and what not to bolt on later.",
      panel: "bg-card",
    };
  }
  if (!highest) {
    return {
      kickerText: "No rule hit",
      kicker: "text-green-ink",
      title: "Nothing in our list between these",
      body: "No curated interaction fired. Read the limit under the result before you treat that as an all-clear.",
      panel: "bg-green-soft",
    };
  }
  if (highest === "major") {
    return {
      kickerText: "Needs a real answer",
      kicker: "text-terra",
      title: counts.major === 1 ? "One serious interaction" : `${counts.major} serious interactions`,
      body: "Read these before the milder notes. Don’t change a prescribed medicine tonight because a page said so — do get a pharmacist or prescriber on the list.",
      panel: "bg-terra-soft",
    };
  }
  if (highest === "moderate") {
    return {
      kickerText: "Worth a conversation",
      kicker: "text-amber",
      title: "Something here should be mentioned",
      body: "No top-tier alarm in our list. These are still the kind of overlaps a pharmacist wants to hear about before you add a bottle.",
      panel: "bg-amber-soft",
    };
  }
  return {
    kickerText: "Smaller notes only",
    kicker: "text-minor",
    title: "No serious overlap in our list",
    body: "A few lesser points are worth naming at your next visit. Absence of a serious flag is not a complete safety check.",
    panel: "bg-minor-soft",
  };
}
