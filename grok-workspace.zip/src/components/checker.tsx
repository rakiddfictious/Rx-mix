import { useEffect, useId, useMemo, useRef, useState, type KeyboardEvent, type RefObject } from "react";
import { AlertTriangle, Check, ChevronDown, Copy, Info, Search, Trash2, X } from "lucide-react";
import { BUCKETS, DRUG_BY_ID, DRUGS, QUICK_ADD, drugsFromIds } from "@/data/catalog";
import type { Drug, Severity } from "@/data/types";
import { checkInteractions, summaryText } from "@/lib/check";
import { searchDrugs } from "@/lib/search";
import { sideEffectsFor } from "@/data/side-effects";

const STORAGE_KEY = "rxmix.pair.v1";

const EXAMPLES: { id: string; label: string; detail: string; ids: string[] }[] = [
  {
    id: "bleed",
    label: "Warfarin + ibuprofen",
    detail: "A common bleed",
    ids: ["warfarin", "ibuprofen"],
  },
  {
    id: "kidney",
    label: "Lisinopril + ibuprofen",
    detail: "Kidneys and pressure",
    ids: ["lisinopril", "ibuprofen"],
  },
  {
    id: "cns",
    label: "Oxycodone + Xanax",
    detail: "Breathing risk",
    ids: ["oxycodone", "alprazolam"],
  },
  {
    id: "nitrate",
    label: "Nitro + sildenafil",
    detail: "Pressure crash",
    ids: ["nitroglycerin", "sildenafil"],
  },
  {
    id: "quiet",
    label: "Lisinopril + metformin",
    detail: "Often quiet in our list",
    ids: ["lisinopril", "metformin"],
  },
  {
    id: "minerals",
    label: "Cipro + iron",
    detail: "Neither one absorbs",
    ids: ["ciprofloxacin", "ferrous-sulfate"],
  },
  {
    id: "kratom",
    label: "Kratom + oxycodone",
    detail: "Opioid-like stacking",
    ids: ["kratom", "oxycodone"],
  },
  {
    id: "methadone",
    label: "Methadone + Xanax",
    detail: "Breathing, plus it lingers",
    ids: ["methadone", "alprazolam"],
  },
  {
    id: "bupe",
    label: "Suboxone + oxycodone",
    detail: "Can trigger withdrawal",
    ids: ["buprenorphine-naloxone", "oxycodone"],
  },
  {
    id: "glp",
    label: "Ozempic + insulin",
    detail: "Low blood sugar",
    ids: ["semaglutide", "insulin"],
  },
  {
    id: "peptides",
    label: "Ipamorelin + CJC-1295",
    detail: "Same growth-hormone signal",
    ids: ["ipamorelin", "cjc-1295"],
  },
];

const SEVERITY_META: Record<
  Severity,
  { label: string; hint: string; badge: string; banner: string; icon: typeof AlertTriangle }
> = {
  major: {
    label: "Serious",
    hint: "Ask before combining",
    badge: "bg-terra-soft text-terra",
    banner: "bg-terra-soft",
    icon: AlertTriangle,
  },
  moderate: {
    label: "Worth a conversation",
    hint: "Don’t ignore it",
    badge: "bg-amber-soft text-amber",
    banner: "bg-amber-soft",
    icon: Info,
  },
  minor: {
    label: "Smaller note",
    hint: "Still mention it",
    badge: "bg-minor-soft text-minor",
    banner: "bg-minor-soft",
    icon: Info,
  },
};

function brandLine(drug: Drug): string {
  if (drug.brands.length === 0) return drug.usedFor;
  return drug.brands.slice(0, 2).join(", ");
}

export function Checker() {
  if (typeof document !== "undefined") document.title = "Rx Mix";

  const [slotA, setSlotA] = useState<string | null>(null);
  const [slotB, setSlotB] = useState<string | null>(null);
  const [checked, setChecked] = useState(false);
  const [ready, setReady] = useState(false);
  const [queryA, setQueryA] = useState("");
  const [queryB, setQueryB] = useState("");
  const [openSlot, setOpenSlot] = useState<"a" | "b" | null>(null);
  const [highlight, setHighlight] = useState(0);
  const [bucket, setBucket] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | Severity>("all");
  const [copied, setCopied] = useState(false);
  const listA = useId();
  const listB = useId();
  const inputA = useRef<HTMLInputElement>(null);
  const inputB = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          const record = parsed as { a?: unknown; b?: unknown };
          if (typeof record.a === "string" && DRUG_BY_ID.has(record.a)) setSlotA(record.a);
          if (typeof record.b === "string" && DRUG_BY_ID.has(record.b)) setSlotB(record.b);
        }
      }
    } catch {
      /* ignore broken local storage */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ a: slotA, b: slotB }));
  }, [slotA, slotB, ready]);

  const activeQuery = openSlot === "b" ? queryB : queryA;
  const matches = useMemo(() => searchDrugs(activeQuery, 8), [activeQuery]);
  const canCheck = Boolean(slotA && slotB && slotA !== slotB);
  const drugs = useMemo(
    () => (checked && canCheck ? drugsFromIds([slotA as string, slotB as string]) : []),
    [checked, canCheck, slotA, slotB],
  );
  const report = useMemo(() => checkInteractions(drugs), [drugs]);
  const activeFilter: "all" | Severity =
    filter !== "all" && report.counts[filter] === 0 ? "all" : filter;
  const visibleFindings = report.findings.filter(
    (finding) => activeFilter === "all" || finding.severity === activeFilter,
  );
  const bucketDrugs = bucket ? DRUGS.filter((drug) => drug.bucket === bucket) : [];
  const drugA = slotA ? DRUG_BY_ID.get(slotA) : undefined;
  const drugB = slotB ? DRUG_BY_ID.get(slotB) : undefined;

  function assign(slot: "a" | "b", id: string) {
    if (slot === "a") {
      if (id === slotB) return;
      setSlotA(id);
      setQueryA("");
    } else {
      if (id === slotA) return;
      setSlotB(id);
      setQueryB("");
    }
    setChecked(false);
    setOpenSlot(null);
    setHighlight(0);
  }

  function clearSlot(slot: "a" | "b") {
    if (slot === "a") setSlotA(null);
    else setSlotB(null);
    setChecked(false);
  }

  function fillEmpty(id: string) {
    if (id === slotA || id === slotB) return;
    if (!slotA) assign("a", id);
    else if (!slotB) assign("b", id);
  }

  function loadExample(next: string[]) {
    setSlotA(next[0] ?? null);
    setSlotB(next[1] ?? null);
    setQueryA("");
    setQueryB("");
    setChecked(true);
    setFilter("all");
    setOpenSlot(null);
  }

  function onKeyDown(slot: "a" | "b", event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setOpenSlot(slot);
      setHighlight((index) => Math.min(index + 1, Math.max(matches.length - 1, 0)));
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setHighlight((index) => Math.max(index - 1, 0));
    } else if (event.key === "Escape") {
      setOpenSlot(null);
    } else if (event.key === "Enter") {
      event.preventDefault();
      const pick = matches[highlight] ?? matches[0];
      if (pick && openSlot === slot) assign(slot, pick.id);
    }
  }

  async function copySummary() {
    const text = summaryText(drugs, report);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  const summary = buildSummary(drugs.length, report.highest, report.counts);

  return (
    <div className="min-h-screen">
      <header className="no-print sticky top-0 z-20 border-b border-line bg-paper">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-3">
            <span
              className="flex size-11 items-center justify-center rounded-xl bg-green font-sans text-lg font-bold leading-none tracking-tight text-card"
              aria-hidden="true"
            >
              RX
            </span>
            <div>
              <p className="font-sans text-xl font-bold leading-none tracking-tight text-ink">Rx Mix</p>
              <p className="text-sm text-muted">Medicines, in plain English</p>
            </div>
          </div>
          <p className="hidden max-w-xs text-right text-sm text-muted sm:block">
            A curated check. Not a diagnosis, and not a full database.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6 sm:py-8">
        <div className="max-w-3xl">
          <h1 className="text-3xl text-ink sm:text-4xl">What happens when these two are taken together?</h1>
          <p className="mt-3 text-lg text-muted">
            Put one medicine, peptide, or supplement in each box. Press Interactions. The result is only that pair,
            in plain language, plus the side effects of each one on its own.
          </p>
        </div>

        <p className="mt-5 max-w-3xl rounded-2xl border border-line bg-card px-4 py-3 text-sm text-ink">
          <span className="font-semibold">Educational only.</span> This is not medical advice, not a complete
          interaction list, and not a reason to start, stop, or change a medicine. Emergencies — trouble breathing,
          blue lips, chest pain, vomiting blood, black stools, a sudden severe headache, a seizure, or a blistering
          rash — need emergency services, not this page.
        </p>

        <div className="mt-6 grid items-start gap-6 lg:grid-cols-[22rem_minmax(0,1fr)]">
          <section className="no-print rounded-3xl border border-line bg-card p-4 sm:p-5">
            <h2 className="text-2xl text-ink">Check a pair</h2>
            <p className="mt-1 text-sm text-muted">One item in each box. The button runs the check.</p>

            <div className="mt-4 flex flex-col gap-3">
              <PairBox
                label="First medicine, peptide, or supplement"
                inputId="slot-a"
                listId={listA}
                selected={drugA}
                query={queryA}
                open={openSlot === "a" && queryA.trim().length > 0}
                matches={openSlot === "a" ? matches : []}
                highlight={highlight}
                inputRef={inputA}
                onQuery={(value) => {
                  setQueryA(value);
                  setOpenSlot("a");
                  setHighlight(0);
                }}
                onFocus={() => {
                  setOpenSlot("a");
                  setHighlight(0);
                }}
                onKeyDown={(event) => onKeyDown("a", event)}
                onPick={(id) => assign("a", id)}
                onClear={() => clearSlot("a")}
              />
              <PairBox
                label="Second medicine, peptide, or supplement"
                inputId="slot-b"
                listId={listB}
                selected={drugB}
                query={queryB}
                open={openSlot === "b" && queryB.trim().length > 0}
                matches={openSlot === "b" ? matches : []}
                highlight={highlight}
                inputRef={inputB}
                onQuery={(value) => {
                  setQueryB(value);
                  setOpenSlot("b");
                  setHighlight(0);
                }}
                onFocus={() => {
                  setOpenSlot("b");
                  setHighlight(0);
                }}
                onKeyDown={(event) => onKeyDown("b", event)}
                onPick={(id) => assign("b", id)}
                onClear={() => clearSlot("b")}
              />
            </div>

            {slotA && slotB && slotA === slotB && (
              <p className="mt-3 text-sm text-terra" role="status">
                Pick two different items. The same medicine in both boxes is not a mix.
              </p>
            )}

            <button
              type="button"
              disabled={!canCheck}
              onClick={() => setChecked(true)}
              className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-green text-base font-bold text-card disabled:opacity-40"
            >
              <Search className="size-5" aria-hidden="true" />
              Interactions
            </button>
            <p className="mt-2 text-sm text-muted">
              {canCheck ? "Both boxes are filled. Press Interactions to see this pair." : "Fill both boxes to run the check."}
            </p>

            {(slotA || slotB) && (
              <button
                type="button"
                onClick={() => {
                  setSlotA(null);
                  setSlotB(null);
                  setChecked(false);
                  setQueryA("");
                  setQueryB("");
                }}
                className="mt-2 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-muted"
              >
                <Trash2 className="size-4" aria-hidden="true" />
                Clear both
              </button>
            )}

            <div className="mt-5">
              <p className="text-xs font-semibold tracking-wide text-muted uppercase">Quick add</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {QUICK_ADD.map((id) => {
                  const drug = DRUG_BY_ID.get(id);
                  if (!drug) return null;
                  const added = id === slotA || id === slotB;
                  return (
                    <button
                      key={id}
                      type="button"
                      disabled={added || Boolean(slotA && slotB)}
                      onClick={() => fillEmpty(id)}
                      className="inline-flex min-h-11 items-center gap-1 rounded-full border border-line bg-paper px-3 text-sm font-semibold text-ink disabled:text-muted"
                    >
                      {added ? <Check className="size-4 text-green" aria-hidden="true" /> : <span aria-hidden="true">+</span>}
                      {drug.generic}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-5">
              <p className="text-xs font-semibold tracking-wide text-muted uppercase">Load an example</p>
              <div className="mt-2 flex flex-col gap-2">
                {EXAMPLES.map((example) => (
                  <button
                    key={example.id}
                    type="button"
                    onClick={() => loadExample(example.ids)}
                    className="flex min-h-11 items-center justify-between gap-3 rounded-xl border border-line px-3 py-2 text-left"
                  >
                    <span>
                      <span className="block font-semibold text-ink">{example.label}</span>
                      <span className="block text-sm text-muted">{example.detail}</span>
                    </span>
                    <ChevronDown className="size-4 -rotate-90 text-muted" aria-hidden="true" />
                  </button>
                ))}
              </div>
            </div>

            <details className="mt-5 border-t border-line pt-4">
              <summary className="flex min-h-11 items-center justify-between gap-3 text-sm font-semibold text-ink">
                Browse by type
                <ChevronDown className="size-4 text-muted" aria-hidden="true" />
              </summary>
              <div className="mt-3 flex flex-wrap gap-2">
                {BUCKETS.map((name) => (
                  <button
                    key={name}
                    type="button"
                    aria-pressed={bucket === name}
                    onClick={() => setBucket((current) => (current === name ? null : name))}
                    className={`min-h-11 rounded-full border px-3 text-sm font-semibold ${
                      bucket === name ? "border-green bg-green text-card" : "border-line bg-paper text-ink"
                    }`}
                  >
                    {name}
                  </button>
                ))}
              </div>
              {bucket && (
                <ul className="mt-3 max-h-64 overflow-auto rounded-xl border border-line">
                  {bucketDrugs.map((drug) => {
                    const added = drug.id === slotA || drug.id === slotB;
                    return (
                      <li key={drug.id} className="border-b border-line last:border-b-0">
                        <button
                          type="button"
                          disabled={added || Boolean(slotA && slotB)}
                          onClick={() => fillEmpty(drug.id)}
                          className="flex min-h-11 w-full items-center justify-between gap-3 px-3 text-left disabled:text-muted"
                        >
                          <span>
                            <span className="block font-semibold">{drug.generic}</span>
                            <span className="block text-sm text-muted">{brandLine(drug)}</span>
                          </span>
                          {added ? <Check className="size-4 text-green" aria-hidden="true" /> : <span className="text-sm">Add</span>}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </details>
          </section>

          <section aria-live="polite">
            <div className={`rounded-3xl border border-line px-4 py-4 sm:px-5 ${summary.panel}`}>
              <p className={`text-sm font-semibold ${canCheck && !checked ? "text-green-ink" : summary.kicker}`}>
                {canCheck && !checked ? "Ready" : summary.kickerText}
              </p>
              <h2 className="mt-1 text-3xl text-ink">
                {canCheck && !checked ? "Press Interactions" : summary.title}
              </h2>
              <p className="mt-2 text-ink">
                {canCheck && !checked
                  ? "The two boxes are filled. The check runs when you press the button, and only for that pair."
                  : summary.body}
              </p>
              {drugs.length >= 2 && report.findings.length > 0 && (
                <p className="mt-3 text-sm font-semibold text-muted tabular-nums">
                  {report.counts.major} serious · {report.counts.moderate} to discuss · {report.counts.minor} smaller
                </p>
              )}
            </div>

            {drugs.length >= 2 && (
              <div className="no-print mt-4 flex flex-wrap gap-2">
                {(
                  [
                    ["all", "All"],
                    ["major", "Serious"],
                    ["moderate", "Conversation"],
                    ["minor", "Smaller"],
                  ] as const
                ).map(([key, label]) => {
                  const count = key === "all" ? report.findings.length : report.counts[key];
                  const selected = activeFilter === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      aria-pressed={selected}
                      disabled={count === 0}
                      onClick={() => setFilter(key)}
                      className={`min-h-11 rounded-full border px-3 text-sm font-semibold disabled:opacity-40 ${
                        selected ? "border-green bg-green text-card" : "border-line bg-card text-ink"
                      }`}
                    >
                      {label} <span className="tabular-nums">{count}</span>
                    </button>
                  );
                })}
                <button
                  type="button"
                  onClick={() => void copySummary()}
                  className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-card px-3 text-sm font-semibold text-ink"
                >
                  {copied ? <Check className="size-4 text-green" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
                  {copied ? "Copied" : "Copy for a pharmacist"}
                </button>
              </div>
            )}

            {drugs.length === 0 && <Intro />}

            {drugs.length === 1 && drugs[0] && (
              <p className="mt-4 text-sm text-muted">
                Add another item to check overlaps. Cautions for {drugs[0].generic} are below either way.
              </p>
            )}

            {drugs.length >= 2 && report.findings.length === 0 && (
              <article className="mt-4 rounded-3xl border border-line bg-card p-5">
                <h3 className="text-2xl text-ink">What “nothing found” does and doesn’t mean</h3>
                <p className="mt-2 text-ink">
                  These items don’t hit a rule in our curated set. That set is common medicines and well-known
                  overlaps — not every dose, gene, food, or new warning. A pharmacist with your full bottle list is
                  still the right check.
                </p>
              </article>
            )}

            <div className="mt-4 flex flex-col gap-4">
              {visibleFindings.map((finding) => {
                const meta = SEVERITY_META[finding.severity];
                const Icon = meta.icon;
                const pairLines = finding.pairs.map((pair) =>
                  pair.map((id) => DRUG_BY_ID.get(id)?.generic ?? id).join(" + "),
                );
                const pairHeading =
                  finding.pairs.length > 1
                    ? "Each line is only that combination"
                    : (finding.pairs[0]?.length ?? 0) > 2
                      ? "These medicines only"
                      : "This pair only";
                return (
                  <article key={finding.id} className="rounded-3xl border border-line bg-card p-5">
                    <p className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-semibold ${meta.badge}`}>
                      <Icon className="size-4" aria-hidden="true" />
                      {meta.label}
                      <span className="font-medium">· {meta.hint}</span>
                    </p>
                    <h3 className="mt-3 text-2xl text-ink">{finding.title}</h3>
                    <div className="mt-3">
                      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{pairHeading}</p>
                      <ul className="mt-1 flex flex-col gap-1">
                        {pairLines.map((line) => (
                          <li key={line} className="font-semibold text-ink">
                            {line}
                          </li>
                        ))}
                      </ul>
                      {finding.pairs.length > 1 && (
                        <p className="mt-2 text-sm text-muted">
                          The explanation below is written once. It is not a new interaction, and it does not mean every
                          medicine on your list is in one mix.
                        </p>
                      )}
                    </div>
                    <p className="mt-3 text-base text-ink">{finding.plain}</p>
                    {finding.notice && (
                      <div className="mt-4">
                        <p className="text-xs font-semibold tracking-wide text-muted uppercase">What you might notice</p>
                        <p className="mt-1 text-ink">{finding.notice}</p>
                      </div>
                    )}
                    <div className={`mt-4 rounded-2xl px-4 py-3 ${meta.banner}`}>
                      <p className="text-xs font-semibold tracking-wide text-muted uppercase">What to do</p>
                      <p className="mt-1 text-ink">{finding.whatToDo}</p>
                    </div>
                    <div className="mt-4">
                      <p className="text-xs font-semibold tracking-wide text-muted uppercase">Why this happens</p>
                      <p className="mt-1 text-sm text-ink">{finding.why}</p>
                    </div>
                    {finding.howSure && <p className="mt-3 text-sm text-muted">How solid this is: {finding.howSure}</p>}
                  </article>
                );
              })}
            </div>

            {drugs.length > 0 && (
              <div className="mt-4 flex flex-col gap-4">
                {drugs.map((drug) => (
                  <article key={drug.id} className="rounded-3xl border border-line bg-card p-5">
                    <p className="text-xs font-semibold tracking-wide text-muted uppercase">Side effects</p>
                    <h3 className="mt-1 text-2xl text-ink">{drug.generic}</h3>
                    <p className="mt-1 text-sm text-muted">
                      Common effects and the serious ones to recognize. Not every rare effect on a label.
                    </p>
                    <ul className="mt-3 flex flex-col gap-2">
                      {sideEffectsFor(drug).map((item) => (
                        <li key={item} className="text-sm text-ink">
                          {item}
                        </li>
                      ))}
                    </ul>
                  </article>
                ))}
              </div>
            )}
          </section>
        </div>

        <footer className="mt-10 max-w-3xl border-t border-line pt-6 text-sm text-muted">
          <p>
            Rx Mix checks one pair at a time: prescriptions, peptides, and common supplements. Blackout peptide and NAD+ are not in this list.
            Side effects here are the common and serious ones, not every rare reaction. It can miss dose-dependent, genetic, and newly discovered interactions.
            Wording is simplified from patterns described in drug labels and standard references. It is not those references, and it is not a
            substitute for a pharmacist, clinician, or emergency service.
          </p>
        </footer>
      </main>
    </div>
  );
}

function PairBox({
  label,
  inputId,
  listId,
  selected,
  query,
  open,
  matches,
  highlight,
  inputRef,
  onQuery,
  onFocus,
  onKeyDown,
  onPick,
  onClear,
}: {
  label: string;
  inputId: string;
  listId: string;
  selected: Drug | undefined;
  query: string;
  open: boolean;
  matches: Drug[];
  highlight: number;
  inputRef: RefObject<HTMLInputElement | null>;
  onQuery: (value: string) => void;
  onFocus: () => void;
  onKeyDown: (event: KeyboardEvent<HTMLInputElement>) => void;
  onPick: (id: string) => void;
  onClear: () => void;
}) {
  return (
    <div className="relative">
      <label htmlFor={inputId} className="text-sm font-semibold text-ink">
        {label}
      </label>
      {selected ? (
        <div className="mt-1 flex h-14 items-center justify-between gap-2 rounded-xl border border-green bg-green-soft px-3">
          <span className="min-w-0">
            <span className="block truncate font-semibold text-ink">{selected.generic}</span>
            <span className="block truncate text-sm text-muted">{brandLine(selected)}</span>
          </span>
          <button
            type="button"
            onClick={onClear}
            aria-label={`Clear ${selected.generic}`}
            className="inline-flex size-11 shrink-0 items-center justify-center rounded-xl text-muted"
          >
            <X className="size-4" />
          </button>
        </div>
      ) : (
        <>
          <Search className="pointer-events-none absolute top-[2.35rem] left-3 size-5 text-muted" aria-hidden="true" />
          <input
            id={inputId}
            ref={inputRef}
            role="combobox"
            aria-expanded={open}
            aria-controls={listId}
            aria-autocomplete="list"
            value={query}
            placeholder="Search a name or brand"
            className="mt-1 h-14 w-full rounded-xl border border-line bg-paper pr-4 pl-11 text-base text-ink placeholder:text-muted"
            onChange={(event) => onQuery(event.target.value)}
            onFocus={onFocus}
            onKeyDown={onKeyDown}
          />
          {open && (
            <ul
              id={listId}
              role="listbox"
              className="absolute z-30 mt-1 max-h-72 w-full overflow-auto rounded-xl border border-line bg-card"
            >
              {matches.length === 0 ? (
                <li className="px-4 py-3 text-sm text-muted">
                  Not in this list. Try a generic name, a brand, or a peptide people actually search.
                </li>
              ) : (
                matches.map((drug, index) => (
                  <li key={drug.id} role="option" aria-selected={index === highlight}>
                    <button
                      type="button"
                      className={`flex min-h-11 w-full flex-col items-start px-4 py-2 text-left ${
                        index === highlight ? "bg-green-soft" : "bg-card"
                      }`}
                      onMouseDown={(event) => event.preventDefault()}
                      onClick={() => onPick(drug.id)}
                    >
                      <span className="font-semibold text-ink">{drug.generic}</span>
                      <span className="text-sm text-muted">
                        {brandLine(drug)} · {drug.bucket}
                      </span>
                    </button>
                  </li>
                ))
              )}
            </ul>
          )}
        </>
      )}
    </div>
  );
}

function Intro() {
  return (
    <div className="mt-4 grid gap-3 sm:grid-cols-3">
      {(
        [
          ["Serious", "Ask before combining", "Blood pressure crashes, slowed breathing, bleeding, kidney injury."],
          ["Conversation", "Don’t shrug it off", "Dose caps, lab checks, or a pairing that is sometimes intentional."],
          ["Smaller note", "Mention it anyway", "Duplicate bottles, timing gaps, supplements with a mild effect."],
        ] as const
      ).map(([title, hint, body]) => (
        <article key={title} className="rounded-2xl border border-line bg-card p-4">
          <h3 className="text-xl text-ink">{title}</h3>
          <p className="mt-1 text-sm font-semibold text-green-ink">{hint}</p>
          <p className="mt-2 text-sm text-muted">{body}</p>
        </article>
      ))}
    </div>
  );
}

function buildSummary(
  count: number,
  highest: Severity | null,
  counts: Record<Severity, number>,
): { title: string; body: string; kickerText: string; kicker: string; panel: string } {
  if (count === 0) {
    return {
      kickerText: "How a result reads",
      kicker: "text-green-ink",
      title: "Plain language, sorted by how much it matters",
      body: "Fill both boxes and press Interactions. A quiet result is shown honestly — silence here is not a safety certificate.",
      panel: "bg-card",
    };
  }
  if (count === 1) {
    return {
      kickerText: "One item",
      kicker: "text-muted",
      title: "Add a second to check an overlap",
      body: "Single medicines still carry their own cautions — timing, food, and what not to bolt on later.",
      panel: "bg-card",
    };
  }
  if (!highest) {
    return {
      kickerText: "No rule hit",
      kicker: "text-green-ink",
      title: "Nothing in our list between these",
      body: "No curated interaction fired. Read the limit under the result before you treat that as an all-clear.",
      panel: "bg-green-soft",
    };
  }
  if (highest === "major") {
    return {
      kickerText: "Needs a real answer",
      kicker: "text-terra",
      title: counts.major === 1 ? "One serious interaction" : `${counts.major} serious interactions`,
      body: "Read these before the milder notes. Don’t change a prescribed medicine tonight because a page said so — do get a pharmacist or prescriber on the list.",
      panel: "bg-terra-soft",
    };
  }
  if (highest === "moderate") {
    return {
      kickerText: "Worth a conversation",
      kicker: "text-amber",
      title: "Something here should be mentioned",
      body: "No top-tier alarm in our list. These are still the kind of overlaps a pharmacist wants to hear about before you add a bottle.",
      panel: "bg-amber-soft",
    };
  }
  return {
    kickerText: "Smaller notes only",
    kicker: "text-minor",
    title: "No serious overlap in our list",
    body: "A few lesser points are worth naming at your next visit. Absence of a serious flag is not a complete safety check.",
    panel: "bg-minor-soft",
  };
}
