import { DRUGS } from "@/data/catalog";
import type { Drug } from "@/data/types";

function norm(value: string): string {
  return value
    .toLowerCase()
    .replace(/['’.]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

const INDEX = DRUGS.map((drug) => {
  const generic = norm(drug.generic);
  const brands = drug.brands.map(norm);
  const aliases = drug.aliases.map(norm);
  const hay = norm([drug.generic, drug.bucket, drug.usedFor, ...drug.brands, ...drug.aliases].join(" "));
  return { drug, generic, brands, aliases, hay };
});

export function searchDrugs(raw: string, limit = 8): Drug[] {
  const query = norm(raw);
  if (!query) return [];

  const ranked = INDEX.map((row) => {
    let score = 0;
    if (row.generic === query) score = 100;
    else if (row.generic.startsWith(query)) score = 86;
    else if (row.brands.some((brand) => brand === query || brand.startsWith(query))) score = 80;
    else if (row.aliases.some((alias) => alias === query || alias.startsWith(query))) score = 74;
    else if (query.length >= 2 && row.generic.includes(query)) score = 64;
    else if (query.length >= 2 && row.brands.some((brand) => brand.includes(query))) score = 58;
    else if (query.length >= 2 && row.aliases.some((alias) => alias.includes(query))) score = 52;
    else if (query.length >= 3 && row.hay.includes(query)) score = 30;
    return { drug: row.drug, score };
  })
    .filter((row) => row.score > 0)
    .sort((a, b) => b.score - a.score || a.drug.generic.localeCompare(b.drug.generic));

  return ranked.slice(0, limit).map((row) => row.drug);
}
