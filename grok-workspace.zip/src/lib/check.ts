import { RULES, SUPPRESS_WHEN } from "@/data/rules";
import type { Drug, Matcher, Rule, Severity } from "@/data/types";

export type Finding = {
  id: string;
  severity: Severity;
  title: string;
  plain: string;
  why: string;
  whatToDo: string;
  drugIds: string[];
};

export type Report = {
  findings: Finding[];
  counts: Record<Severity, number>;
  highest: Severity | null;
};

const SEVERITY_RANK: Record<Severity, number> = {
  major: 0,
  moderate: 1,
  minor: 2,
};

function matches(drug: Drug, matcher: Matcher): boolean {
  if (matcher.ids?.includes(drug.id)) return true;
  if (matcher.classes?.some((name) => drug.classes.includes(name))) return true;
  return false;
}

function ruleFires(rule: Rule, drugs: Drug[]): boolean {
  const used = new Set<string>();

  function walk(groupIndex: number): boolean {
    if (groupIndex === rule.groups.length) return true;
    const group = rule.groups[groupIndex];
    if (!group) return false;
    for (const drug of drugs) {
      if (used.has(drug.id)) continue;
      if (!matches(drug, group)) continue;
      used.add(drug.id);
      if (walk(groupIndex + 1)) return true;
      used.delete(drug.id);
    }
    return false;
  }

  return walk(0);
}

function involvedDrugs(rule: Rule, drugs: Drug[]): Drug[] {
  return drugs.filter((drug) => rule.groups.some((group) => matches(drug, group)));
}

export function joinNames(names: readonly string[]): string {
  if (names.length === 0) return "";
  if (names.length === 1) return names[0] ?? "";
  if (names.length === 2) return `${names[0]} and ${names[1]}`;
  return `${names.slice(0, -1).join(", ")}, and ${names[names.length - 1]}`;
}

function fill(template: string, drugs: Drug[]): string {
  return template.replaceAll("{meds}", joinNames(drugs.map((drug) => drug.generic)));
}

export function checkInteractions(drugs: Drug[]): Report {
  const fired: { rule: Rule; drugs: Drug[] }[] = [];

  for (const rule of RULES) {
    if (!ruleFires(rule, drugs)) continue;
    const involved = involvedDrugs(rule, drugs);
    if (involved.length < rule.groups.length) continue;
    fired.push({ rule, drugs: involved });
  }

  const firedIds = new Set(fired.map((hit) => hit.rule.id));
  const hidden = new Set<string>();
  for (const [keeper, drops] of Object.entries(SUPPRESS_WHEN)) {
    if (!firedIds.has(keeper)) continue;
    for (const id of drops) hidden.add(id);
  }

  const findings = fired
    .filter((hit) => !hidden.has(hit.rule.id))
    .map((hit) => ({
      id: hit.rule.id,
      severity: hit.rule.severity,
      title: hit.rule.title,
      plain: fill(hit.rule.plain, hit.drugs),
      why: fill(hit.rule.why, hit.drugs),
      whatToDo: fill(hit.rule.whatToDo, hit.drugs),
      drugIds: hit.drugs.map((drug) => drug.id),
    }))
    .sort((a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity] || a.title.localeCompare(b.title));

  const counts: Record<Severity, number> = { major: 0, moderate: 0, minor: 0 };
  for (const finding of findings) counts[finding.severity] += 1;

  const highest = findings[0]?.severity ?? null;
  return { findings, counts, highest };
}

export function summaryText(drugs: Drug[], report: Report): string {
  const lines = [
    "Rx Mix — plain-language interaction check",
    "Educational only. Not medical advice and not a complete interaction database.",
    "",
    "On the list:",
    ...drugs.map((drug) => {
      const brand = drug.brands[0];
      return brand ? `- ${drug.generic} (${brand})` : `- ${drug.generic}`;
    }),
    "",
  ];

  if (report.findings.length === 0) {
    lines.push("No interactions from our curated list between these items.");
    lines.push("That is not proof the combination is safe.");
  } else {
    for (const finding of report.findings) {
      const label =
        finding.severity === "major" ? "SERIOUS" : finding.severity === "moderate" ? "WORTH A CONVERSATION" : "SMALLER NOTE";
      lines.push(`${label}: ${finding.title}`);
      lines.push(finding.plain);
      lines.push(`What to do: ${finding.whatToDo}`);
      lines.push("");
    }
  }

  lines.push("Confirm with a pharmacist or the clinician who prescribes these before changing any medicine.");
  return lines.join("\n");
}
