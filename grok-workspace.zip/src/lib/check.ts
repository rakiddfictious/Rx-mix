import { RULES, SUPPRESS_WHEN } from "@/data/rules";
import { DRUG_BY_ID } from "@/data/catalog";
import type { Drug, Matcher, Rule, Severity } from "@/data/types";

export type Finding = {
  id: string;
  severity: Severity;
  title: string;
  plain: string;
  why: string;
  whatToDo: string;
  notice?: string;
  howSure?: string;
  /** Each inner list is one combination. A pair rule never pulls in a third medicine. */
  pairs: string[][];
  drugIds: string[];
};

export type Report = {
  findings: Finding[];
  counts: Record<Severity, number>;
  highest: Severity | null;
};

const SEVERITY_RANK: Record<Severity, number> = {
  major: 0,
  moderate: 1,
  minor: 2,
};

function matches(drug: Drug, matcher: Matcher): boolean {
  if (matcher.ids?.includes(drug.id)) return true;
  if (matcher.classes?.some((name) => drug.classes.includes(name))) return true;
  return false;
}

function enumerateTuples(rule: Rule, drugs: Drug[]): Drug[][] {
  const found: Drug[][] = [];
  const used = new Set<string>();

  function walk(groupIndex: number, acc: Drug[]): void {
    if (groupIndex === rule.groups.length) {
      found.push([...acc]);
      return;
    }
    const group = rule.groups[groupIndex];
    if (!group) return;
    for (const drug of drugs) {
      if (used.has(drug.id)) continue;
      if (!matches(drug, group)) continue;
      used.add(drug.id);
      acc.push(drug);
      walk(groupIndex + 1, acc);
      acc.pop();
      used.delete(drug.id);
    }
  }

  walk(0, []);

  const seen = new Set<string>();
  const unique: Drug[][] = [];
  for (const tuple of found) {
    const key = tuple
      .map((drug) => drug.id)
      .sort()
      .join("+");
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push([...tuple].sort((a, b) => a.generic.localeCompare(b.generic)));
  }
  return unique;
}

function covers(keeper: Drug[], drop: Drug[]): boolean {
  const ids = new Set(keeper.map((drug) => drug.id));
  return drop.every((drug) => ids.has(drug.id));
}

function fillTuples(template: string, tuples: Drug[][]): string {
  if (tuples.length === 1) return fill(template, tuples[0] ?? []);
  return template.replaceAll("{meds}", tuples[0]?.length === 2 ? "These pairs" : "These combinations");
}

export function checkInteractions(drugs: Drug[]): Report {
  const hits = RULES.map((rule) => ({ rule, tuples: enumerateTuples(rule, drugs) })).filter((hit) => hit.tuples.length > 0);
  const byId = new Map(hits.map((hit) => [hit.rule.id, hit]));

  for (const [keeperId, dropIds] of Object.entries(SUPPRESS_WHEN)) {
    const keeper = byId.get(keeperId);
    if (!keeper) continue;
    for (const dropId of dropIds) {
      const drop = byId.get(dropId);
      if (!drop) continue;
      drop.tuples = drop.tuples.filter((tuple) => !keeper.tuples.some((kept) => covers(kept, tuple)));
    }
  }

  const findings: Finding[] = hits
    .filter((hit) => hit.tuples.length > 0)
    .map((hit) => {
      const pairs = hit.tuples.map((tuple) => tuple.map((drug) => drug.id));
      const drugIds = [...new Set(pairs.flat())];
      return {
        id: hit.rule.id,
        severity: hit.rule.severity,
        title: hit.rule.title,
        plain: fillTuples(hit.rule.plain, hit.tuples),
        why: fillTuples(hit.rule.why, hit.tuples),
        whatToDo: fillTuples(hit.rule.whatToDo, hit.tuples),
        notice: hit.rule.notice ? fillTuples(hit.rule.notice, hit.tuples) : undefined,
        howSure: hit.rule.howSure,
        pairs,
        drugIds,
      };
    })
    .sort((a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity] || a.title.localeCompare(b.title));

  const counts: Record<Severity, number> = { major: 0, moderate: 0, minor: 0 };
  for (const finding of findings) counts[finding.severity] += 1;

  const highest = findings[0]?.severity ?? null;
  return { findings, counts, highest };
}

export function joinNames(names: readonly string[]): string {
  if (names.length === 0) return "";
  if (names.length === 1) return names[0] ?? "";
  if (names.length === 2) return `${names[0]} and ${names[1]}`;
  return `${names.slice(0, -1).join(", ")}, and ${names[names.length - 1]}`;
}

function fill(template: string, drugs: Drug[]): string {
  return template.replaceAll("{meds}", joinNames(drugs.map((drug) => drug.generic)));
}

export function summaryText(drugs: Drug[], report: Report): string {
  const lines = [
    "Rx Mix — plain-language interaction check",
    "Educational only. Not medical advice and not a complete interaction database.",
    "",
    "On the list:",
    ...drugs.map((drug) => {
      const brand = drug.brands[0];
      return brand ? `- ${drug.generic} (${brand})` : `- ${drug.generic}`;
    }),
    "",
  ];

  if (report.findings.length === 0) {
    lines.push("No interactions from our curated list between these items.");
    lines.push("That is not proof the combination is safe.");
  } else {
    for (const finding of report.findings) {
      const label =
        finding.severity === "major" ? "SERIOUS" : finding.severity === "moderate" ? "WORTH A CONVERSATION" : "SMALLER NOTE";
      lines.push(`${label}: ${finding.title}`);
      for (const pair of finding.pairs) {
        const names = pair.map((id) => DRUG_BY_ID.get(id)?.generic ?? id);
        lines.push(names.join(" + "));
      }
      lines.push(finding.plain);
      if (finding.notice) lines.push(`What you might notice: ${finding.notice}`);
      lines.push(`What to do: ${finding.whatToDo}`);
      if (finding.howSure) lines.push(`How solid this is: ${finding.howSure}`);
      lines.push("");
    }
  }

  lines.push("Confirm with a pharmacist or the clinician who prescribes these before changing any medicine.");
  return lines.join("\n");
}
