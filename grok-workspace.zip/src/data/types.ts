export type Severity = "major" | "moderate" | "minor";

export type Drug = {
  id: string;
  generic: string;
  brands: string[];
  aliases: string[];
  classes: string[];
  bucket: string;
  plain: string;
  usedFor: string;
  watch: string[];
};

export type Matcher = {
  classes?: readonly string[];
  ids?: readonly string[];
};

export type Rule = {
  id: string;
  groups: readonly Matcher[];
  severity: Severity;
  title: string;
  plain: string;
  why: string;
  whatToDo: string;
  /** Everyday symptoms, when we have a clear picture of them. */
  notice?: string;
  /** How solid the evidence is, in one sentence. */
  howSure?: string;
};
