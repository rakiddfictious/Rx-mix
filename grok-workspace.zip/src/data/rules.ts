import type { Rule } from "@/data/types";

/** When the key rule has already fired, hide these noisier overlaps. */
export const SUPPRESS_WHEN: Record<string, readonly string[]> = {
  "triple-whammy": ["nsaid-pressure"],
  "k-stack": ["ace-spiro"],
  "alcohol-downer": ["opioid-downer"],
  "maoi-serotonin": ["ssri-serotonin-major", "ssri-serotonin-mod", "ssri-trazodone", "ssri-dup"],
  "sedating-downer": ["sedating-dup"],
  "kratom-maoi": ["kratom-serotonin"],
};

export const RULES: Rule[] = [
  {
    id: "nitrate-pde5",
    groups: [{ classes: ["nitrate"] }, { classes: ["pde5"] }],
    severity: "major",
    title: "Blood pressure can crash",
    plain:
      "{meds} together can drop blood pressure hard enough to cause fainting or shock. That includes a daily nitrate pill, not only the emergency chest spray.",
    why: "Both open blood vessels. Stacked, the effect is much stronger than either one alone.",
    whatToDo:
      "Do not combine them. After sildenafil the unsafe window is about 24 hours; after tadalafil it is about 48 hours. If chest pain happens in that window, emergency staff need to know what you took and when — some usual chest-pain treatments are unsafe then.",
  },
  {
    id: "alcohol-downer",
    groups: [{ classes: ["alcohol"] }, { classes: ["opioid", "benzo", "zd"] }],
    severity: "major",
    title: "Breathing can slow or stop",
    plain:
      "{meds} all slow the brain. Together — even without feeling very drunk — they can make breathing dangerously slow, especially during sleep.",
    why: "Alcohol, opioids, benzodiazepines, and sleep medicines like zolpidem depress the drive to breathe. The combination is more than additive.",
    whatToDo:
      "Don’t drink on top of these. If a clinician prescribed an opioid and a benzodiazepine together, don’t change them on your own tonight, but make sure they know about both, and don’t add extra doses. Emergency care if someone is hard to wake, breathing is slow, or lips look blue.",
  },
  {
    id: "opioid-downer",
    groups: [{ classes: ["opioid"] }, { classes: ["benzo", "zd"] }],
    severity: "major",
    title: "A boxed warning for slowed breathing",
    plain:
      "{meds} are a known cause of fatal sedation. The opioid and the anxiety or sleep medicine reinforce each other.",
    why: "Both dampen the brainstem signals that keep breathing going. The FDA requires a boxed warning on this pairing.",
    whatToDo:
      "If both were prescribed, the prescribers should each know the full list. Don’t add alcohol. Don’t raise either dose to chase relief. Emergency care for slow breathing, blue lips, or someone who won’t wake.",
  },
  {
    id: "opioid-gaba",
    groups: [{ classes: ["opioid"] }, { classes: ["gabapentinoid"] }],
    severity: "major",
    title: "Extra sedation and slow breathing",
    plain:
      "{meds} together raise the chance of profound sleepiness and slowed breathing. This pairing has its own FDA warning.",
    why: "Gabapentin and pregabalin add to opioid sedation, especially in older adults or with lung disease.",
    whatToDo:
      "Don’t start or raise either one without the prescriber seeing the full list. Avoid alcohol. Get help urgently if breathing slows or the person can’t be woken.",
  },
  {
    id: "opioid-dup",
    groups: [{ classes: ["opioid"] }, { classes: ["opioid"] }],
    severity: "major",
    title: "Two opioid pain medicines",
    plain: "{meds} are both opioids. Taking two stacks sedation, constipation, and the risk of slowed breathing.",
    why: "They act on the same receptors. A second opioid is not a safer add-on.",
    whatToDo:
      "This is rarely something to piece together yourself. Ask which one you should actually be on. Remember combination products like Percocet or Norco already contain an opioid.",
  },
  {
    id: "sedative-dup",
    groups: [{ classes: ["benzo", "zd"] }, { classes: ["benzo", "zd"] }],
    severity: "moderate",
    title: "Two medicines that slow the brain",
    plain: "{meds} both sedate. Together, falls, confusion, and next-day impairment are more likely.",
    why: "Benzodiazepines and Z-drugs like zolpidem overlap in how they quiet the nervous system.",
    whatToDo: "Ask whether both are still needed. Don’t add alcohol. Don’t stop a regular benzodiazepine abruptly.",
  },
  {
    id: "sedating-downer",
    groups: [{ classes: ["sedating"] }, { classes: ["opioid", "benzo", "zd"] }],
    severity: "moderate",
    title: "Drowsiness stacks",
    plain:
      "{meds} can make you much sleepier than either alone. Nighttime antihistamines and trazodone count, not only prescription sleep pills.",
    why: "Sedating antihistamines and trazodone add antihistamine or serotonin sedation on top of a drug that already slows the brain.",
    whatToDo:
      "Avoid driving until you know how the mix feels. Older adults are especially fall-prone. If an opioid is involved and breathing seems slow, treat that as urgent.",
  },
  {
    id: "sedating-dup",
    groups: [{ classes: ["sedating"] }, { classes: ["sedating"] }],
    severity: "moderate",
    title: "Two sedating medicines",
    plain: "{meds} both make people drowsy. The hangover is easy to underestimate because each one felt mild alone.",
    why: "Their sedating effects add up, along with dry mouth, constipation, and confusion in older adults.",
    whatToDo: "You usually don’t need both. Ask which one to keep, especially if either is only for sleep.",
  },
  {
    id: "dual-anticoag",
    groups: [{ classes: ["anticoagulant"] }, { classes: ["anticoagulant"] }],
    severity: "major",
    title: "Two blood thinners",
    plain: "{meds} are both anticoagulants. Outside a short, supervised hospital plan, doubling them is a serious bleeding risk.",
    why: "They block clotting by related paths. The bleed risk is not a small step up.",
    whatToDo:
      "Don’t take both unless a hospital team set a brief overlap on purpose. If you were switched from one to the other, confirm the old one was stopped.",
  },
  {
    id: "anticoag-nsaid",
    groups: [{ classes: ["anticoagulant"] }, { classes: ["nsaid"] }],
    severity: "major",
    title: "Bleeding risk jumps",
    plain:
      "{meds} are a classic bad casual mix. The blood thinner stops clots; the pain pill irritates the stomach and makes platelets less sticky.",
    why: "NSAIDs (ibuprofen, naproxen, celecoxib) add gastrointestinal injury on top of impaired clotting.",
    whatToDo:
      "Ask before using this pain pill, even for a few days. Acetaminophen is often considered instead, but it has its own ceiling — and with warfarin, several days of higher doses can still move the INR. Urgent care for black stools, vomiting blood, or a sudden severe headache.",
  },
  {
    id: "anticoag-antiplatelet",
    groups: [{ classes: ["anticoagulant"] }, { classes: ["antiplatelet"] }],
    severity: "major",
    title: "Two ways of slowing clots",
    plain:
      "{meds} slow clotting by different routes. Bleeding is meaningfully more likely. Sometimes a heart doctor wants exactly this pair after a stent or a valve — and sometimes it was never the plan.",
    why: "Anticoagulants and antiplatelet drugs (aspirin, clopidogrel) interrupt different steps. Together, plugs form less well.",
    whatToDo:
      "Don’t add aspirin or stop a prescribed pair on your own. Confirm with the prescriber that both are still intended. Extra NSAID pain pills on top are a separate, bigger problem.",
  },
  {
    id: "dual-antiplatelet",
    groups: [{ classes: ["antiplatelet"] }, { classes: ["antiplatelet"] }],
    severity: "moderate",
    title: "Two antiplatelet medicines",
    plain:
      "{meds} both keep platelets from clumping. After a stent this pair is often deliberate for a set number of months. It is also easy to recreate by accident with over-the-counter aspirin.",
    why: "Dual antiplatelet therapy prevents stent clots, at the cost of easier bruising and bleeding.",
    whatToDo:
      "If a cardiologist prescribed both, don’t stop either for a procedure or a nosebleed without calling them. If aspirin was your own addition, ask before keeping it.",
  },
  {
    id: "ssri-bleed",
    groups: [{ classes: ["ssri", "snri"] }, { classes: ["nsaid", "antiplatelet", "anticoagulant"] }],
    severity: "major",
    title: "Bleeding is more likely",
    plain:
      "{meds} raise bleeding risk, especially in the stomach. Antidepressants in the SSRI and SNRI families make platelets a little less effective, and the other medicine already affects clotting or the stomach lining.",
    why: "Platelets need serotonin to do their job. SSRIs and SNRIs lower platelet serotonin. NSAIDs, aspirin, clopidogrel, and anticoagulants each add their own hit.",
    whatToDo:
      "Low-dose aspirin plus an antidepressant is sometimes intentional. Don’t add ibuprofen or naproxen on top without asking. Urgent help for black stools, vomiting blood, or a sudden severe headache.",
  },
  {
    id: "ssri-serotonin-major",
    groups: [{ classes: ["ssri", "snri"] }, { classes: ["opioid_serotonergic", "stjohns"] }],
    severity: "major",
    title: "Serotonin can build up",
    plain:
      "{meds} both push serotonin. With tramadol that also means a higher seizure risk. With St John’s wort it is not a gentle herbal add-on — it is a second antidepressant.",
    why: "Too much serotonin causes serotonin syndrome: agitation, sweating, tremor, diarrhea, and confusion. Tramadol lowers the seizure threshold as well.",
    whatToDo:
      "Don’t combine these on your own. If you already feel unusually agitated, shaky, feverish, or confused, get urgent care and bring the list. A prescriber who wants both should be the one managing it.",
  },
  {
    id: "ssri-serotonin-mod",
    groups: [{ classes: ["ssri", "snri"] }, { classes: ["dxm", "triptan"] }],
    severity: "moderate",
    title: "A smaller serotonin overlap",
    plain:
      "{meds} both touch serotonin. Serious reactions are uncommon, especially with a normal dose of a migraine triptan, but cough syrup is easy to overdo.",
    why: "Triptans and dextromethorphan (the DM in cough medicine) have serotonergic activity on top of an antidepressant.",
    whatToDo:
      "Use the labeled dose, not extra. Skip ‘DM’ cough syrup if you can use something else, or ask a pharmacist. Get help for agitation, heavy sweating, tremor, or confusion.",
  },
  {
    id: "ssri-trazodone",
    groups: [{ classes: ["ssri", "snri"] }, { ids: ["trazodone"] }],
    severity: "minor",
    title: "Often prescribed together for sleep",
    plain:
      "{meds} both raise serotonin a little. Clinicians commonly pair a daytime antidepressant with low-dose trazodone at night. Serious reactions are uncommon at usual sleep doses.",
    why: "Trazodone is mildly serotonergic. The overlap is real but usually tolerated.",
    whatToDo:
      "This one is a mention, not an alarm. Still report agitation, tremor, heavy sweating, or confusion. Don’t raise both doses at once without asking.",
  },
  {
    id: "ssri-dup",
    groups: [{ classes: ["ssri", "snri"] }, { classes: ["ssri", "snri"] }],
    severity: "moderate",
    title: "Two antidepressants from the same shelf",
    plain: "{meds} overlap. Two SSRIs, or an SSRI plus an SNRI, raise serotonin and side effects without a clear everyday reason.",
    why: "They work through the same pathway. Duplicate therapy is usually a leftover from a switch that wasn’t finished.",
    whatToDo:
      "Ask which one is current. If you are mid-switch, confirm the taper rather than taking full doses of both.",
  },
  {
    id: "maoi-serotonin",
    groups: [
      { classes: ["maoi"] },
      { classes: ["ssri", "snri", "opioid_serotonergic", "dxm", "triptan", "stjohns"], ids: ["trazodone"] },
    ],
    severity: "major",
    title: "A dangerous serotonin mix",
    plain:
      "{meds} are not a safe combination. MAOIs plus other serotonergic medicines can cause serotonin syndrome, which can be severe.",
    why: "An MAOI stops serotonin from being broken down. Adding a drug that raises serotonin can overwhelm the system.",
    whatToDo:
      "Do not combine them or start one right after the other. Washout timing is a specialist decision — fluoxetine in particular lingers for weeks. Urgent care for high fever, confusion, rigid muscles, or dramatic swings in blood pressure.",
  },
  {
    id: "maoi-decongestant",
    groups: [{ classes: ["maoi"] }, { classes: ["decongestant"] }],
    severity: "major",
    title: "Blood pressure can spike",
    plain: "{meds} can cause a sudden, severe rise in blood pressure. A stuffy-nose pill is not minor on an MAOI.",
    why: "MAOIs change how the body handles the stimulant effect of pseudoephedrine. The result can be a hypertensive crisis.",
    whatToDo:
      "Don’t take pseudoephedrine or similar decongestants. Ask a pharmacist for a non-decongestant option. Emergency care for a severe headache, chest pain, or a pounding heart after a cold pill.",
  },
  {
    id: "bupropion-tramadol",
    groups: [{ ids: ["bupropion"] }, { ids: ["tramadol"] }],
    severity: "moderate",
    title: "Seizure risk goes up",
    plain: "{meds} each lower the seizure threshold. Together the risk is higher than with either one, especially above usual doses.",
    why: "Bupropion and tramadol both make seizures more likely. The problem is seizures more than serotonin.",
    whatToDo: "Don’t combine them unless a prescriber chose that knowingly. Skip extra doses. Alcohol binges push the same risk.",
  },
  {
    id: "vka-boosters",
    groups: [
      { ids: ["warfarin"] },
      { ids: ["metronidazole", "smx-tmp", "ciprofloxacin", "levofloxacin", "clarithromycin", "amiodarone"] },
    ],
    severity: "major",
    title: "Warfarin can become too strong",
    plain:
      "{meds} can push the INR up — that is the blood test that measures warfarin — and bleeding follows. The antibiotic or heart medicine is often the new piece.",
    why: "These drugs slow warfarin’s clearance or, with some antibiotics, also disturb vitamin K–producing gut bacteria.",
    whatToDo:
      "The prescriber who manages warfarin needs to know before or as soon as the other drug starts. Dose changes and extra INR checks are common. Don’t adjust warfarin yourself. Watch for unusual bleeding.",
  },
  {
    id: "vka-azithro",
    groups: [{ ids: ["warfarin"] }, { ids: ["azithromycin"] }],
    severity: "moderate",
    title: "The INR can drift",
    plain: "{meds} sometimes raise warfarin’s effect. It is less predictable than with clarithromycin or Bactrim, but it is not zero.",
    why: "Azithromycin is a milder enzyme interaction than clarithromycin, yet INR bumps are still reported.",
    whatToDo: "Tell the warfarin clinic you started a Z-Pak. Ask whether an extra INR check is wanted.",
  },
  {
    id: "vka-doxy",
    groups: [{ ids: ["warfarin"] }, { classes: ["tetracycline"] }],
    severity: "moderate",
    title: "Warfarin may run a bit strong",
    plain: "{meds} can nudge the INR upward. Not everyone is affected, which is why a lab check beats guessing.",
    why: "Some antibiotics, doxycycline included, are associated with higher INR readings.",
    whatToDo: "Let the anticoagulation clinic know. Don’t change the warfarin dose on your own.",
  },
  {
    id: "vka-steroid",
    groups: [{ ids: ["warfarin"] }, { classes: ["corticosteroid"] }],
    severity: "moderate",
    title: "Steroid pills can move the INR",
    plain: "{meds} don’t have one simple direction. The INR can rise or fall when prednisone starts or stops.",
    why: "Corticosteroids change warfarin response in both directions in different people.",
    whatToDo: "If prednisone is more than a day or two, ask for an INR plan. Mention when the steroid stops, too — that swing matters.",
  },
  {
    id: "vka-apap",
    groups: [{ ids: ["warfarin"] }, { ids: ["acetaminophen"] }],
    severity: "moderate",
    title: "Several days of acetaminophen can raise the INR",
    plain:
      "{meds} are often paired on purpose because acetaminophen doesn’t irritate the stomach the way ibuprofen does. A catch: higher doses for several days can still strengthen warfarin.",
    why: "Regular acetaminophen, especially above occasional low doses, is associated with INR increases.",
    whatToDo:
      "Occasional labeled doses are the usual advice, not standing high doses. If you need it most days, tell the warfarin clinic. Count hidden acetaminophen in cold and opioid combos.",
  },
  {
    id: "vka-inducer",
    groups: [{ ids: ["warfarin"] }, { classes: ["inducer"] }],
    severity: "major",
    title: "Warfarin can become too weak",
    plain:
      "{meds} can make warfarin wear off faster, so clots become more likely. If the other product is later stopped, warfarin can suddenly become too strong.",
    why: "These drugs induce liver enzymes that clear warfarin. St John’s wort, carbamazepine, and rifampin are the ones in this list.",
    whatToDo:
      "Don’t start or stop these without the anticoagulation clinic. INR checks and dose changes go in both directions. This is the opposite problem from antibiotics that make warfarin too strong.",
  },
  {
    id: "statin-clarithro-high",
    groups: [{ classes: ["macrolide_strong"] }, { classes: ["statin_3a4_high"] }],
    severity: "major",
    title: "Muscle breakdown risk",
    plain:
      "{meds} are a poor combination. Simvastatin and lovastatin levels can soar with clarithromycin, and muscles can break down.",
    why: "Clarithromycin blocks CYP3A4, the enzyme that clears these particular statins. Muscle injury can release a protein that harms the kidneys.",
    whatToDo:
      "Do not keep taking simvastatin or lovastatin during clarithromycin unless a prescriber gave a specific hold-or-switch plan. Azithromycin is often chosen instead precisely to avoid this. Dark urine, severe weakness, or muscle pain needs urgent care.",
  },
  {
    id: "statin-clarithro-mod",
    groups: [{ classes: ["macrolide_strong"] }, { classes: ["statin_3a4_mod"] }],
    severity: "moderate",
    title: "The statin level can rise",
    plain: "{meds} — clarithromycin can raise atorvastatin. The risk is real but more manageable than with simvastatin.",
    why: "Atorvastatin also uses CYP3A4, just not as exclusively, so the jump is smaller than with simvastatin or lovastatin.",
    whatToDo:
      "Ask whether to pause atorvastatin for the antibiotic course. Don’t add grapefruit on top. Report severe muscle pain.",
  },
  {
    id: "statin-nondhp-high",
    groups: [{ classes: ["ccb_nondhp"] }, { classes: ["statin_3a4_high"] }],
    severity: "major",
    title: "The statin dose has a hard ceiling",
    plain:
      "{meds} together mean simvastatin or lovastatin must stay at a low dose, or be switched. Higher doses have caused serious muscle injury.",
    why: "Diltiazem and verapamil block CYP3A4 enough to matter for these statins. Labels set maximum statin doses for the pair.",
    whatToDo:
      "Don’t raise the statin on your own. Ask if the current dose is within the allowed cap, or whether rosuvastatin or pravastatin would be simpler.",
  },
  {
    id: "statin-nondhp-mod",
    groups: [{ classes: ["ccb_nondhp"] }, { classes: ["statin_3a4_mod"] }],
    severity: "moderate",
    title: "Atorvastatin may run higher",
    plain: "{meds} can raise atorvastatin levels. Many people still take a pair like this, at a moderated dose.",
    why: "Verapamil and diltiazem partially block the enzyme that clears atorvastatin.",
    whatToDo: "Make sure one clinician sees both. Report new muscle pain rather than pushing through it.",
  },
  {
    id: "statin-amio-high",
    groups: [{ ids: ["amiodarone"] }, { classes: ["statin_3a4_high"] }],
    severity: "major",
    title: "Amiodarone limits the statin dose",
    plain: "{meds} require a low simvastatin or lovastatin dose. Amiodarone sticks around for months, so the interaction does too.",
    why: "Amiodarone inhibits the enzyme that clears these statins. The combination has caused muscle breakdown.",
    whatToDo:
      "Confirm the statin dose is within the cap, or ask about a switch to a statin that cares less (pravastatin or rosuvastatin). Muscle pain or dark urine needs a call.",
  },
  {
    id: "statin-amlodipine",
    groups: [{ ids: ["amlodipine"] }, { classes: ["statin_3a4_high"] }],
    severity: "moderate",
    title: "Simvastatin has a dose cap here",
    plain: "{meds} are commonly prescribed together, but simvastatin usually should not go above 20 mg when amlodipine is on board.",
    why: "Amlodipine raises simvastatin levels modestly. The label answers with a dose limit, not a ban.",
    whatToDo: "Check the simvastatin strength. Don’t increase it without asking. Lovastatin has a similar caution.",
  },
  {
    id: "grapefruit-statin-high",
    groups: [{ classes: ["grapefruit"] }, { classes: ["statin_3a4_high"] }],
    severity: "major",
    title: "Grapefruit and this statin don’t mix",
    plain: "{meds} — grapefruit can markedly raise simvastatin or lovastatin and has been tied to muscle injury.",
    why: "Grapefruit blocks CYP3A4 in the gut. These two statins depend on that enzyme. The block can last into the next day.",
    whatToDo:
      "Avoid grapefruit and grapefruit juice on these statins. Ordinary oranges are fine. Pravastatin and rosuvastatin are the ones less affected — a switch is a clinician decision, not a DIY one.",
  },
  {
    id: "grapefruit-statin-mod",
    groups: [{ classes: ["grapefruit"] }, { classes: ["statin_3a4_mod"] }],
    severity: "moderate",
    title: "Large amounts of grapefruit matter",
    plain: "{meds} — a lot of grapefruit can raise atorvastatin. A rare small glass is a different scale than daily big glasses.",
    why: "Atorvastatin is partly cleared by the enzyme grapefruit blocks, so the rise is moderate rather than extreme.",
    whatToDo: "Avoid daily grapefruit juice. Mention your actual habit at the next visit rather than guessing a safe volume.",
  },
  {
    id: "statin-inducer",
    groups: [{ classes: ["inducer"] }, { classes: ["statin_3a4_high", "statin_3a4_mod"] }],
    severity: "moderate",
    title: "The cholesterol medicine may not work as well",
    plain: "{meds} — the inducer speeds clearance of simvastatin, lovastatin, or atorvastatin, so the cholesterol effect can shrink.",
    why: "Carbamazepine, rifampin, and St John’s wort induce CYP3A4. Less statin stays in the blood.",
    whatToDo:
      "Don’t be reassured by a ‘natural’ product if your LDL was finally controlled. Ask whether the statin should change. Stopping the inducer later can suddenly raise the statin level.",
  },
  {
    id: "statin-dup",
    groups: [{ classes: ["statin"] }, { classes: ["statin"] }],
    severity: "moderate",
    title: "Two statins",
    plain: "{meds} are the same kind of cholesterol medicine. You should not need both. Side effects add, benefit doesn’t double.",
    why: "Duplicate statin therapy increases muscle toxicity without a standard indication.",
    whatToDo: "Confirm which bottle is current. Combination pills sometimes hide a statin you also take separately.",
  },
  {
    id: "triple-whammy",
    groups: [{ classes: ["acei", "arb"] }, { classes: ["thiazide", "loop"] }, { classes: ["nsaid"] }],
    severity: "major",
    title: "A trio that can injure the kidneys",
    plain:
      "{meds} are the ‘triple whammy’: a blood-pressure medicine that protects the kidney’s pressure system, a water pill, and an NSAID pain pill. Together they can cause sudden kidney injury, especially in older adults or when you’re dry.",
    why: "ACE inhibitors and ARBs change kidney blood flow, diuretics shrink volume, and NSAIDs block the prostaglandins kidneys use when stressed. All three at once remove the backup plan.",
    whatToDo:
      "Don’t add the pain pill on your own. If you are already on all three, ask whether that is still intended and whether kidney labs are being watched. Drink normally unless you were told to limit fluids, and pause to ask during a stomach bug.",
  },
  {
    id: "nsaid-pressure",
    groups: [{ classes: ["nsaid"] }, { classes: ["acei", "arb", "thiazide", "loop"] }],
    severity: "moderate",
    title: "The pain pill can fight the blood-pressure pill",
    plain:
      "{meds} — NSAIDs can raise blood pressure, make water pills less effective, and strain kidneys. The risk is highest if you are also dehydrated.",
    why: "Prostaglandins help the kidney and support the effect of these blood-pressure medicines. NSAIDs block them.",
    whatToDo:
      "A short course may be fine for some people and a bad idea for others. Ask, especially if you already have kidney disease. Adding a water pill later turns this into a more serious trio.",
  },
  {
    id: "nsaid-dup",
    groups: [{ classes: ["nsaid"] }, { classes: ["nsaid"] }],
    severity: "moderate",
    title: "Two anti-inflammatory pain pills",
    plain: "{meds} are both NSAIDs. Taking two does not add clean relief. It does add stomach, kidney, and blood-pressure risk.",
    why: "They share a mechanism. The ceiling for pain relief arrives before the ceiling for harm.",
    whatToDo: "Pick one. If pain is not controlled, that is a reason to reassess, not to add Aleve on top of Advil.",
  },
  {
    id: "aspirin-nsaid",
    groups: [{ ids: ["aspirin"] }, { classes: ["nsaid"] }],
    severity: "moderate",
    title: "Pain pills can crowd low-dose aspirin",
    plain:
      "{meds} together raise the chance of a stomach bleed. If ibuprofen is one of them, it can also block the clot-prevention job of low-dose aspirin when the doses are close together.",
    why: "NSAIDs injure the stomach lining and affect platelets. Ibuprofen can occupy the same platelet spot aspirin needs in order to work for the heart.",
    whatToDo:
      "Ask before using this combination. If a clinician wants both, they often have you take aspirin first and wait, or they pick a different pain medicine. Acetaminophen does not block aspirin’s heart effect the way ibuprofen can.",
  },
  {
    id: "prednisone-nsaid",
    groups: [{ classes: ["corticosteroid"] }, { classes: ["nsaid"] }],
    severity: "major",
    title: "A setup for stomach ulcers",
    plain: "{meds} together are much harder on the stomach than either alone. Ulcers and bleeding are the concern.",
    why: "Steroids and NSAIDs each impair the stomach’s defenses. The combination multiplies ulcer risk.",
    whatToDo:
      "Don’t add ibuprofen or naproxen to a prednisone course without asking. If both are required, a clinician may add a stomach-protection medicine. Black stools or vomiting blood is urgent.",
  },
  {
    id: "lithium-nsaid",
    groups: [{ classes: ["lithium"] }, { classes: ["nsaid"] }],
    severity: "major",
    title: "Lithium can rise to a toxic level",
    plain: "{meds} — NSAIDs can make the kidneys hold onto lithium. Toxicity looks like tremor, confusion, slurred speech, and heavy diarrhea.",
    why: "NSAIDs reduce lithium clearance. The level can climb over days, not months.",
    whatToDo:
      "Don’t start a standing NSAID without the lithium prescriber. If you already took some and feel newly shaky or confused, get a same-day level. Acetaminophen is the pain option usually discussed instead.",
  },
  {
    id: "lithium-thiazide",
    groups: [{ classes: ["lithium"] }, { classes: ["thiazide"] }],
    severity: "major",
    title: "This water pill can spike lithium",
    plain: "{meds} are a textbook interaction. Hydrochlorothiazide can raise lithium into the toxic range.",
    why: "Thiazide diuretics increase lithium reabsorption in the kidney. Loop water pills are less predictable; thiazides are the classic problem.",
    whatToDo:
      "Don’t add or stop the water pill without a lithium level plan. Dehydration and low-salt diets push the same direction. Same-day care for confusion, worsening tremor, or vomiting.",
  },
  {
    id: "lithium-raas",
    groups: [{ classes: ["lithium"] }, { classes: ["acei", "arb"] }],
    severity: "major",
    title: "Blood-pressure pills can raise lithium",
    plain: "{meds} can slowly increase the lithium level, particularly in older adults or when you get dehydrated.",
    why: "ACE inhibitors and ARBs reduce lithium excretion. The rise may show up over weeks.",
    whatToDo:
      "Starting either medicine should come with a lithium level check. A stomach bug is a reason to call, not to push fluids blindly if you were given different sick-day rules.",
  },
  {
    id: "lithium-metro",
    groups: [{ classes: ["lithium"] }, { ids: ["metronidazole"] }],
    severity: "moderate",
    title: "Lithium levels can creep up",
    plain: "{meds} have been linked to higher lithium levels. It is less famous than the NSAID interaction and still worth a check.",
    why: "Metronidazole is reported to reduce lithium clearance in some people.",
    whatToDo: "Tell the lithium prescriber you are starting metronidazole. Ask if a level is due. Watch for new tremor or confusion.",
  },
  {
    id: "mtx-nsaid",
    groups: [{ classes: ["mtx"] }, { classes: ["nsaid"] }],
    severity: "major",
    title: "Methotrexate toxicity",
    plain:
      "{meds} can raise methotrexate to a toxic level — mouth sores, low blood counts, kidney strain. Some people with arthritis are prescribed both on purpose, with monitoring. Adding an NSAID yourself is different.",
    why: "NSAIDs reduce methotrexate clearance. The danger is greatest with the high doses used in cancer, but low weekly doses are not automatically exempt.",
    whatToDo:
      "Don’t add ibuprofen or naproxen without the prescriber who manages methotrexate. Confirm you are on a weekly schedule, not daily. Fever, mouth ulcers, or unusual bruising need a prompt call.",
  },
  {
    id: "mtx-bactrim",
    groups: [{ classes: ["mtx"] }, { ids: ["smx-tmp"] }],
    severity: "major",
    title: "A bone-marrow combination to avoid",
    plain: "{meds} together can crash blood counts. This is one of the antibiotic pairings rheumatology teams try hard to avoid.",
    why: "Both interfere with folate metabolism. The bone marrow can stop making cells.",
    whatToDo:
      "Do not take Bactrim with methotrexate unless a specialist is explicitly managing it. If it was just prescribed, call before you take it. Fever or a bad sore throat on methotrexate is already a reason to call.",
  },
  {
    id: "digoxin-amio",
    groups: [{ ids: ["digoxin"] }, { ids: ["amiodarone"] }],
    severity: "major",
    title: "Digoxin can double",
    plain: "{meds} — amiodarone commonly doubles the digoxin level. The digoxin dose is often cut in half when amiodarone starts.",
    why: "Amiodarone blocks transporters and kidneys pathways that clear digoxin. Amiodarone also lasts for months.",
    whatToDo:
      "Don’t start either without the cardiologist adjusting digoxin. Nausea, halos around lights, confusion, or a very slow pulse can be toxicity — same-day care.",
  },
  {
    id: "digoxin-clarithro",
    groups: [{ ids: ["digoxin"] }, { ids: ["clarithromycin"] }],
    severity: "major",
    title: "The antibiotic can cause digoxin toxicity",
    plain: "{meds} — clarithromycin can raise digoxin quickly. People have been hospitalized for this.",
    why: "Clarithromycin inhibits P-glycoprotein, which helps clear digoxin, and may also change gut bacteria that normally inactivate some of it.",
    whatToDo:
      "The prescriber should pick a different antibiotic or plan a digoxin check. Don’t wait for a routine visit if you feel nauseated, confused, or notice visual halos.",
  },
  {
    id: "digoxin-azithro",
    groups: [{ ids: ["digoxin"] }, { ids: ["azithromycin"] }],
    severity: "moderate",
    title: "Digoxin can tick upward",
    plain: "{meds} have been linked to higher digoxin levels, less dramatically than with clarithromycin.",
    why: "Azithromycin can still affect digoxin transport in some people.",
    whatToDo: "Mention the Z-Pak to whoever manages digoxin. New nausea or visual changes deserve a level, not a wait.",
  },
  {
    id: "digoxin-k-wasting",
    groups: [{ ids: ["digoxin"] }, { classes: ["k_wasting"] }],
    severity: "moderate",
    title: "Low potassium makes digoxin dangerous",
    plain: "{meds} — water pills that waste potassium don’t raise digoxin directly. They make a normal digoxin level act toxic.",
    why: "The heart is much more sensitive to digoxin when potassium or magnesium is low.",
    whatToDo:
      "Don’t skip potassium checks. Leg cramps, muscle weakness, or a suddenly slower pulse are reasons to call. Replacing potassium is a dose, not a guess.",
  },
  {
    id: "digoxin-nondhp",
    groups: [{ ids: ["digoxin"] }, { classes: ["ccb_nondhp"] }],
    severity: "moderate",
    title: "Digoxin levels and heart rate both fall",
    plain: "{meds} can raise digoxin and slow the heart further. Verapamil is the louder of the two.",
    why: "Verapamil and diltiazem reduce digoxin clearance and also slow conduction through the same heart node.",
    whatToDo: "This pairing needs one clinician watching the rate and the level. Report dizziness or a pulse that feels too slow.",
  },
  {
    id: "bb-nondhp",
    groups: [{ classes: ["beta_blocker"] }, { classes: ["ccb_nondhp"] }],
    severity: "major",
    title: "The heart rate can fall too far",
    plain: "{meds} both slow the heart’s electrical gate. Together they can cause a very slow pulse or a block that makes people faint.",
    why: "Beta blockers and non-dihydropyridine calcium blockers (verapamil, diltiazem) depress the same AV node. Amlodipine does not do this the same way.",
    whatToDo:
      "Don’t combine verapamil or diltiazem with a beta blocker unless a cardiologist is driving. A pulse under the range you were given, or fainting, needs urgent care.",
  },
  {
    id: "k-stack",
    groups: [{ classes: ["potassium"] }, { classes: ["acei", "arb", "k_sparing"] }],
    severity: "major",
    title: "Potassium can climb too high",
    plain:
      "{meds} both raise potassium. High potassium can disturb the heart’s rhythm before you feel anything. Salt substitutes count as potassium.",
    why: "ACE inhibitors, ARBs, and spironolactone reduce potassium excretion. A supplement adds more in.",
    whatToDo:
      "Don’t start potassium or a salt substitute unless a clinician who sees your labs told you to. If you were told to take both, keep the lab schedule. New weakness or skipped heartbeats deserve a call.",
  },
  {
    id: "ace-spiro",
    groups: [{ classes: ["acei", "arb"] }, { classes: ["k_sparing"] }],
    severity: "moderate",
    title: "A common pair that needs lab checks",
    plain:
      "{meds} are often prescribed together in heart failure. The point of the visits is potassium. It can rise even without a potassium pill.",
    why: "Both reduce potassium loss. The benefit in heart failure is real; so is hyperkalemia if nobody is looking.",
    whatToDo:
      "Don’t skip bloodwork. Don’t add potassium, salt substitute, or an NSAID on the side. Hold questions during a dehydrating illness should go to the clinic, not to guesswork.",
  },
  {
    id: "ace-arb",
    groups: [{ classes: ["acei"] }, { classes: ["arb"] }],
    severity: "moderate",
    title: "Two blood-pressure families you usually don’t stack",
    plain: "{meds} work on the same hormone system. Using both raises potassium and kidney risk without better everyday blood-pressure control.",
    why: "Dual blockade of the renin-angiotensin system failed in trials: more harm, little added benefit.",
    whatToDo: "Ask if one of them is a leftover. Don’t restart an old ACE inhibitor on top of a newer ARB.",
  },
  {
    id: "pde5-alpha",
    groups: [{ classes: ["pde5"] }, { classes: ["alpha_blocker"] }],
    severity: "moderate",
    title: "Blood pressure can sag when you stand",
    plain: "{meds} both relax vessels. Dizziness on standing is the usual problem, not the nitrate-level crash.",
    why: "Alpha blockers and PDE5 inhibitors have additive blood-pressure effects. Tamsulosin is a frequent real-world pair.",
    whatToDo:
      "If you use both, they are often started apart, at low doses, not on the same evening for the first time. Sit or lie down if you feel faint. This is different from the absolute ban with nitrates.",
  },
  {
    id: "clopi-ppi",
    groups: [{ ids: ["clopidogrel"] }, { classes: ["ppi_2c19"] }],
    severity: "moderate",
    title: "This acid pill can weaken clopidogrel",
    plain: "{meds} — omeprazole and esomeprazole can stop clopidogrel from turning into its active form. Pantoprazole is the acid medicine usually swapped in.",
    why: "Clopidogrel needs the CYP2C19 enzyme to activate. Omeprazole and esomeprazole block that enzyme. Pantoprazole does so much less.",
    whatToDo:
      "Don’t pick Prilosec or Nexium off the shelf if you take Plavix. Ask about pantoprazole, or whether you still need an acid pill at all.",
  },
  {
    id: "qt-pair",
    groups: [{ classes: ["qt_risk"] }, { classes: ["qt_risk"] }],
    severity: "moderate",
    title: "Two medicines that can stretch the heart’s rhythm",
    plain:
      "{meds} can add to each other’s effect on the QT interval — a measurement of the heart’s electrical reset. In uncommon cases that becomes a dangerous rhythm. Citalopram is the antidepressant in this list where the warning is strongest.",
    why: "Drugs that prolong QT do it more when combined, when potassium is low, or when doses are high.",
    whatToDo:
      "Tell the prescriber, especially if you have a history of long QT, fainting, or low potassium. Don’t stack extra doses. A fainting spell or a racing collapse is emergency care.",
  },
  {
    id: "ssri-qt-ppi",
    groups: [{ ids: ["citalopram", "escitalopram"] }, { classes: ["ppi_2c19"] }],
    severity: "moderate",
    title: "The acid pill can raise this antidepressant",
    plain:
      "{meds} — omeprazole or esomeprazole can increase citalopram or escitalopram. Higher levels matter because of the heart-rhythm warning, especially with citalopram.",
    why: "Those PPIs block CYP2C19, which helps clear both antidepressants.",
    whatToDo:
      "Ask whether the antidepressant dose is still right, or whether pantoprazole should replace the acid pill. Don’t increase the antidepressant to chase effect.",
  },
  {
    id: "fq-steroid",
    groups: [{ classes: ["fq"] }, { classes: ["corticosteroid"] }],
    severity: "moderate",
    title: "Tendon injury is more likely",
    plain: "{meds} together raise the chance of tendonitis or tendon rupture, particularly the Achilles, and particularly over age 60.",
    why: "Fluoroquinolones already carry a tendon warning. Systemic steroids multiply it.",
    whatToDo:
      "Stop strenuous loading and call if a tendon hurts, swells, or you feel a pop. Ask whether a different antibiotic was an option before you start, if you haven’t taken it yet.",
  },
  {
    id: "levo-cations",
    groups: [{ classes: ["thyroid"] }, { classes: ["calcium", "iron", "magnesium", "zinc", "polyvalent"] }],
    severity: "moderate",
    title: "The thyroid pill may not get absorbed",
    plain:
      "{meds} in the same sitting means less levothyroxine gets in. People slowly become under-replaced and think the dose ‘stopped working.’ A multivitamin counts.",
    why: "Calcium, iron, magnesium, and zinc bind levothyroxine in the gut. Separation by about four hours avoids most of it.",
    whatToDo:
      "Take levothyroxine on an empty stomach, and park calcium, iron, magnesium, zinc, and multivitamins at the other end of the day. If you have been taking them together, don’t change the thyroid dose until a clinician sees a lab — the level may rebound once you separate them.",
  },
  {
    id: "levo-ppi",
    groups: [{ classes: ["thyroid"] }, { classes: ["ppi"] }],
    severity: "moderate",
    title: "Less stomach acid, less thyroid absorption",
    plain: "{meds} — long-term acid suppression can reduce how much levothyroxine you absorb. The dose sometimes needs to go up, then come back down if the acid pill stops.",
    why: "Levothyroxine dissolves better in an acidic stomach. PPIs raise the pH.",
    whatToDo: "Mention both at lab time. Don’t adjust the thyroid dose because you feel different for a week.",
  },
  {
    id: "abx-cations",
    groups: [{ classes: ["fq", "tetracycline"] }, { classes: ["polyvalent"] }],
    severity: "moderate",
    title: "Neither the antibiotic nor the mineral gets absorbed",
    plain:
      "{meds} bind to each other in the stomach. The antibiotic may not work, and the iron, calcium, magnesium, or zinc mostly goes to waste too. Vitamin C is not this problem — the minerals are.",
    why: "Ciprofloxacin, levofloxacin, and doxycycline grab onto these minerals (chelation). The clump doesn’t pass into the blood. A multivitamin counts, and so do antacids.",
    whatToDo:
      "Separate them by several hours. A common instruction is the antibiotic 2 hours before or 6 hours after the mineral — use the timing on your bottle. Don’t stop the antibiotic. Amoxicillin and azithromycin are not in this chelation group.",
  },
  {
    id: "alendronate-calcium",
    groups: [{ ids: ["alendronate"] }, { classes: ["polyvalent"] }],
    severity: "moderate",
    title: "Minerals block the osteoporosis pill",
    plain:
      "{meds} at the same time means the alendronate doesn’t absorb. Calcium is the usual culprit; iron, magnesium, zinc, and multivitamins do it too.",
    why: "Alendronate already absorbs poorly. Polyvalent minerals bind what’s left.",
    whatToDo:
      "Alendronate first, plain water only, upright, empty stomach, at least 30 minutes before food or any other pill — including calcium, iron, magnesium, zinc, and vitamins.",
  },
  {
    id: "inducer-oc",
    groups: [{ classes: ["inducer"] }, { classes: ["coc"] }],
    severity: "major",
    title: "Birth control pills can fail",
    plain:
      "{meds} — this is one of the real cases where another medicine makes combined birth control less reliable. Most ordinary antibiotics do not do this. These do.",
    why: "Carbamazepine, rifampin, and St John’s wort induce enzymes that clear contraceptive hormones. Breakthrough bleeding can be a clue, but pregnancy can happen without it.",
    whatToDo:
      "Use a backup method or a different contraceptive that your clinician says is unaffected. Don’t rely on the pill alone while the inducer is on board, and ask how long to keep the backup after it stops.",
  },
  {
    id: "lamotrigine-oc",
    groups: [{ ids: ["lamotrigine"] }, { classes: ["coc"] }],
    severity: "moderate",
    title: "The pill can cut lamotrigine levels",
    plain:
      "{meds} — estrogen in combined birth control can drop lamotrigine by about half. Seizure control or mood stability can slip. The pill week off can then make the level jump.",
    why: "Estrogen induces the pathway that clears lamotrigine. The interaction is on the seizure medicine more than on the contraceptive.",
    whatToDo:
      "The prescriber often adjusts the lamotrigine dose and times it around pill packs. Don’t change either dose because you feel off — call. This entry is not a progestin-only pill or an IUD.",
  },
  {
    id: "lamotrigine-cbz",
    groups: [{ ids: ["lamotrigine"] }, { ids: ["carbamazepine"] }],
    severity: "moderate",
    title: "Carbamazepine lowers lamotrigine",
    plain: "{meds} — carbamazepine speeds clearance of lamotrigine, so the lamotrigine dose that worked alone may be too low.",
    why: "Carbamazepine induces glucuronidation, the route that clears lamotrigine.",
    whatToDo: "Dose changes belong to the prescriber, with a titration that still respects rash risk. Don’t double lamotrigine to compensate.",
  },
  {
    id: "colchicine-clarithro",
    groups: [{ classes: ["colchicine"] }, { classes: ["macrolide_strong"] }],
    severity: "major",
    title: "Colchicine toxicity, including fatal cases",
    plain: "{meds} can make colchicine levels dangerous. Severe diarrhea, weakness, and low blood counts have led to deaths.",
    why: "Clarithromycin blocks both CYP3A4 and P-glycoprotein, the two exits colchicine uses.",
    whatToDo:
      "Do not take this antibiotic with colchicine unless a specialist rewrote the plan. If you already did, call promptly — especially if diarrhea is severe. Azithromycin is not in this same contraindicated bucket.",
  },
  {
    id: "colchicine-statin",
    groups: [{ classes: ["colchicine"] }, { classes: ["statin"] }],
    severity: "moderate",
    title: "Muscle injury is more likely",
    plain: "{meds} together add muscle toxicity. Many people take both for gout and cholesterol, with a clear warning to report muscle pain.",
    why: "Colchicine and statins can each injure muscle. The overlap is pharmacologic and, for some statins, also about shared clearance.",
    whatToDo: "Report unexplained muscle pain, weakness, or dark urine. Don’t raise either dose without asking.",
  },
  {
    id: "colchicine-grapefruit",
    groups: [{ classes: ["colchicine"] }, { classes: ["grapefruit"] }],
    severity: "moderate",
    title: "Grapefruit raises colchicine",
    plain: "{meds} — grapefruit can increase colchicine exposure. With a drug this narrow, that is worth skipping the fruit.",
    why: "Grapefruit inhibits the gut enzyme and transporters that limit how much colchicine gets in.",
    whatToDo: "Avoid grapefruit while you take colchicine. Ordinary oranges are a fine substitute.",
  },
  {
    id: "alcohol-metro",
    groups: [{ classes: ["alcohol"] }, { ids: ["metronidazole"] }],
    severity: "major",
    title: "The label says do not drink",
    plain:
      "{meds} can cause flushing, nausea, vomiting, and a pounding heart. The warning covers the whole course and a few days after the last dose.",
    why: "Metronidazole is labeled for a disulfiram-like reaction with alcohol. Reports vary, and the instruction does not.",
    whatToDo:
      "Skip alcohol until about three days after the last dose, unless your own clinician gave a different window. Mouthwash and some liquid medicines contain alcohol — a pharmacist can check those.",
  },
  {
    id: "alcohol-metformin",
    groups: [{ classes: ["alcohol"] }, { ids: ["metformin"] }],
    severity: "moderate",
    title: "Heavy drinking is the problem, not a sip",
    plain:
      "{meds} — binge drinking on metformin raises a rare but serious risk called lactic acidosis, and it also swings blood sugar.",
    why: "Alcohol and metformin both touch lactate metabolism. The risk is concentrated in heavy drinking, dehydration, and kidney disease — not in a single drink with dinner for most people.",
    whatToDo:
      "Be honest about the amount. Binges and drinking while dehydrated or acutely ill are the pattern to stop. If you drink most days, ask how that fits the medicine.",
  },
  {
    id: "alcohol-hypo",
    groups: [{ classes: ["alcohol"] }, { classes: ["insulin", "sulfonylurea"] }],
    severity: "moderate",
    title: "Alcohol can push blood sugar too low",
    plain: "{meds} — alcohol blocks the liver from releasing sugar, so insulin or a sulfonylurea can overshoot into a low.",
    why: "The liver is busy clearing alcohol and won’t do its usual glucose rescue. The low can show up hours later, including overnight.",
    whatToDo:
      "Don’t drink on an empty stomach if you use these medicines. Know your low-sugar plan. A bedtime snack is sometimes advised after drinking — ask what fits your doses.",
  },
  {
    id: "alcohol-warfarin",
    groups: [{ classes: ["alcohol"] }, { ids: ["warfarin"] }],
    severity: "moderate",
    title: "Alcohol makes warfarin unpredictable",
    plain: "{meds} — a binge can raise bleeding risk, and day-to-day swings in drinking make the INR harder to stabilize.",
    why: "Alcohol affects warfarin metabolism and, when heavy, the liver that makes clotting factors. Falls while anticoagulated add head-bleed risk.",
    whatToDo: "Keep intake steady and modest if you drink at all, and tell the clinic the real number. A fall with a hit to the head needs urgent evaluation.",
  },
  {
    id: "alcohol-nsaid",
    groups: [{ classes: ["alcohol"] }, { classes: ["nsaid"] }],
    severity: "moderate",
    title: "Both irritate the stomach",
    plain: "{meds} together make a stomach bleed more likely than either alone.",
    why: "Alcohol and NSAIDs each damage the mucosal barrier. Together they are a common cause of ulcer bleeding.",
    whatToDo: "Skip the combination when you can. If you need a pain pill after drinking, ask a pharmacist rather than doubling the NSAID.",
  },
  {
    id: "alcohol-apap",
    groups: [{ classes: ["alcohol"] }, { ids: ["acetaminophen"] }],
    severity: "moderate",
    title: "Liver risk when both are heavy",
    plain: "{meds} — daily heavy drinking plus higher doses of acetaminophen is what stresses the liver. A single labeled dose is a different situation.",
    why: "Chronic alcohol use depletes the backup pathway the liver uses to detoxify acetaminophen.",
    whatToDo:
      "Stay inside the daily maximum, and lower if you drink heavily — ask a pharmacist for the number that fits you. Count combination cold and pain products.",
  },
  {
    id: "alcohol-ssri",
    groups: [{ classes: ["alcohol"] }, { classes: ["ssri", "snri"] }],
    severity: "minor",
    title: "Alcohol can blunt the reason you take this",
    plain: "{meds} — alcohol can worsen drowsiness and make mood and sleep harder to judge. It is not a hard chemical ban for most people.",
    why: "The interaction is mostly additive sedation and the effect of alcohol on depression itself, not a single dangerous metabolite.",
    whatToDo: "If mood is why you take the medicine, the drinking pattern belongs in the visit. Don’t drive if the mix makes you foggy.",
  },
  {
    id: "cyp2d6-bb",
    groups: [{ classes: ["cyp2d6_strong"] }, { ids: ["metoprolol", "carvedilol"] }],
    severity: "moderate",
    title: "The beta blocker can become too strong",
    plain: "{meds} — fluoxetine and paroxetine can raise metoprolol or carvedilol. A very slow pulse, fatigue, or cold hands can be the clue.",
    why: "Those two SSRIs strongly block CYP2D6, a main route for these beta blockers. Sertraline is not in this strong group.",
    whatToDo:
      "If the antidepressant is new and the pulse has dropped, call. Dose changes are common. Don’t stop the beta blocker suddenly to ‘fix’ it.",
  },
  {
    id: "insulin-su",
    groups: [{ classes: ["insulin"] }, { classes: ["sulfonylurea"] }],
    severity: "moderate",
    title: "Low blood sugar is more likely",
    plain: "{meds} both lower blood sugar actively. Together, lows are a planned risk, not a surprise you should discover overnight.",
    why: "Sulfonylureas force insulin release and injected insulin adds more. There is no extra brake.",
    whatToDo:
      "Know the low-sugar symptoms and treatment you were taught. If lows are recurring, that is a dose conversation, not a reason to eat through it forever.",
  },
  {
    id: "bb-hypo",
    groups: [{ classes: ["beta_blocker"] }, { classes: ["insulin", "sulfonylurea"] }],
    severity: "moderate",
    title: "A low can be quieter than usual",
    plain:
      "{meds} — beta blockers can hide a fast heartbeat, one of the usual alarms for low blood sugar. Sweating can still happen.",
    why: "The warning signs of hypoglycemia are partly adrenaline. Beta blockers blunt those signs. They can also slightly change how a low recovers.",
    whatToDo:
      "Learn the signs that still show up for you, especially sweating and confusion. Check a glucose rather than waiting to ‘feel’ a low if you are unsure.",
  },
  {
    id: "ginkgo-bleed",
    groups: [{ classes: ["ginkgo"] }, { classes: ["anticoagulant", "antiplatelet"] }],
    severity: "moderate",
    title: "Extra bleeding reports",
    plain: "{meds} — ginkgo has been tied, in case reports, to extra bleeding when combined with blood thinners or antiplatelet drugs.",
    why: "Ginkgo may inhibit platelet activating factor. The evidence is not a large trial, and the consequence of being wrong is a bleed.",
    whatToDo: "Tell the prescriber you take it. Stopping a supplement is usually simpler than adjusting a blood thinner around it.",
  },
  {
    id: "fishoil-bleed",
    groups: [{ classes: ["fishoil"] }, { classes: ["anticoagulant", "antiplatelet"] }],
    severity: "minor",
    title: "High-dose fish oil adds a little bleed risk",
    plain: "{meds} — a standard small capsule is a minor note. Prescription-strength omega-3 doses are the ones that matter more.",
    why: "High-dose omega-3s can impair platelets slightly. Food portions of fish are not the same as concentrated capsules.",
    whatToDo: "Say the dose out loud at your next visit, in milligrams. Don’t stack several ‘heart health’ products that all claim a blood effect.",
  },
  {
    id: "ppi-dup",
    groups: [{ classes: ["ppi"] }, { classes: ["ppi"] }],
    severity: "minor",
    title: "Two acid-blocking pills",
    plain: "{meds} are the same kind of medicine. A prescription PPI plus an over-the-counter one is a common accidental double.",
    why: "More acid suppression isn’t more healing once you’re on a full dose. It does add long-term downsides.",
    whatToDo: "Check bottles for omeprazole, esomeprazole, and pantoprazole hiding under brand names. Keep one, unless a clinician split the timing on purpose.",
  },
  {
    id: "antihistamine-dup",
    groups: [{ classes: ["antihistamine"] }, { classes: ["antihistamine"] }],
    severity: "minor",
    title: "Two allergy antihistamines",
    plain: "{meds} usually don’t both need to be on the daily list. Diphenhydramine is the one that sedates.",
    why: "They compete for the same histamine receptors. Sedation and anticholinergic effects are what you gain from adding Benadryl.",
    whatToDo: "Pick the non-drowsy one for the day unless a clinician told you to use diphenhydramine for a specific reason, like a bad itch at night.",
  },
  {
    id: "abx-probiotic",
    groups: [{ classes: ["antibiotic"] }, { classes: ["probiotic"] }],
    severity: "moderate",
    title: "The antibiotic can wipe out the probiotic",
    plain:
      "{meds} taken together means the antibiotic can kill the live bacteria in the supplement before they do anything. The antibiotic itself still works. This is one of the real cases where an antibiotic blocks a supplement.",
    why: "Bacterial probiotics have to survive the gut to matter. An antibiotic in the same swallow is built to kill bacteria. Yeast probiotics such as Florastor are less affected.",
    whatToDo:
      "Separate them by at least two hours. Don’t skip antibiotic doses to ‘protect’ the probiotic. Severely suppressed immune systems are a reason to ask before using live bacteria at all.",
  },
  {
    id: "vka-vitk",
    groups: [{ ids: ["warfarin"] }, { classes: ["vitamin_k"] }],
    severity: "major",
    title: "Vitamin K can cancel warfarin",
    plain:
      "{meds} pull in opposite directions. Vitamin K is what the body uses to make the clotting factors warfarin is trying to slow down. A supplement is a much bigger change than a salad.",
    why: "Warfarin blocks the recycling of vitamin K. Extra vitamin K, especially K1 or K2 pills, can drop the INR and let clots form.",
    whatToDo:
      "Don’t start, stop, or change a vitamin K supplement unless the anticoagulation clinic is in on it. If it was prescribed as a reversal plan, that is a specific dose — not an everyday add-on. Leafy greens can stay if the weekly amount is steady.",
  },
  {
    id: "b12-depleters",
    groups: [{ classes: ["vitamin_b12"] }, { classes: ["biguanide", "ppi"] }],
    severity: "moderate",
    title: "These medicines can lower vitamin B12",
    plain:
      "{meds} — metformin and long-term acid-blocking pills reduce B12 absorption over months, mostly from food. A B12 pill is often part of the fix, not something you have to avoid.",
    why: "Stomach acid helps release B12 from food. Metformin interferes with absorption in the last part of the small intestine. Short antibiotic courses are not the same issue.",
    whatToDo:
      "If you have been on metformin or a daily PPI for a long time, ask whether a B12 level is due. Don’t stop either medicine because of this note.",
  },
  {
    id: "vitc-iron",
    groups: [{ classes: ["vitamin_c"] }, { classes: ["iron"] }],
    severity: "minor",
    title: "Vitamin C helps iron get in",
    plain:
      "{meds} — vitamin C increases iron absorption. That can be the point of taking them together, and it can also mean more stomach upset or more iron than you meant.",
    why: "Ascorbic acid keeps iron in the form the gut absorbs more easily.",
    whatToDo:
      "If a clinician told you to pair them, this is expected. If iron levels are already high, or the iron is only inside a multivitamin you didn’t realize you were doubling, mention the vitamin C dose.",
  },
  {
    id: "vitc-warfarin",
    groups: [{ classes: ["vitamin_c"] }, { ids: ["warfarin"] }],
    severity: "minor",
    title: "Very high doses of vitamin C occasionally move the INR",
    plain:
      "{meds} — ordinary dietary vitamin C is not a warfarin problem. Grams-per-day supplement doses have occasionally been reported to change the INR.",
    why: "Evidence is thin and not one-directional. It is a mention, not a ban.",
    whatToDo: "Tell the warfarin clinic if you take high-dose vitamin C every day. You do not need to avoid fruit.",
  },
  {
    id: "kratom-opioid",
    groups: [{ classes: ["kratom"] }, { classes: ["opioid"] }],
    severity: "major",
    title: "Kratom stacks with opioid pain medicines",
    plain:
      "{meds} can slow breathing the way two opioids can. Kratom is not an approved pain medicine, and products vary, including concentrated 7-hydroxymitragynine.",
    why: "Mitragynine and 7-hydroxymitragynine act on opioid receptors. Adding a prescription opioid multiplies sedation and respiratory depression.",
    whatToDo:
      "Don’t combine them. If someone is hard to wake, breathing slowly, or blue at the lips, that is emergency care — tell responders both were taken. Don’t stop a prescribed opioid on your own tonight; do make sure the prescriber knows about the kratom.",
  },
  {
    id: "kratom-cns",
    groups: [{ classes: ["kratom"] }, { classes: ["benzo", "zd", "alcohol", "gabapentinoid"] }],
    severity: "major",
    title: "Kratom plus sedatives can slow breathing",
    plain:
      "{meds} all depress the nervous system. With benzodiazepines, sleep medicines, gabapentin or pregabalin, or alcohol, the risk is slowed breathing and profound sedation — not just feeling sleepy.",
    why: "Kratom has opioid-like effects. Those add to other drugs that already slow the drive to breathe.",
    whatToDo:
      "Don’t mix them. Emergency care if breathing slows or the person can’t be woken. Regular kratom use can also cause withdrawal if stopped abruptly — that is a clinician conversation, not a same-night cold stop piled on top of other sedatives without advice.",
  },
  {
    id: "kratom-sedating",
    groups: [{ classes: ["kratom"] }, { classes: ["sedating"] }],
    severity: "moderate",
    title: "Extra drowsiness with kratom",
    plain: "{meds} — sedating antihistamines and trazodone add sleepiness on top of kratom. Falls and next-day fog are the usual result.",
    why: "Kratom is already sedating in many doses. Diphenhydramine and trazodone add to that.",
    whatToDo: "Avoid driving until you know the mix. Don’t add alcohol or an opioid on top.",
  },
  {
    id: "kratom-serotonin",
    groups: [{ classes: ["kratom"] }, { classes: ["ssri", "snri", "dxm", "triptan", "opioid_serotonergic", "stjohns"] }],
    severity: "moderate",
    title: "Kratom and serotonin don’t sit quietly",
    plain:
      "{meds} — case reports describe serotonin toxicity and, with tramadol, seizures when kratom is added to serotonergic medicines. This is less mapped than St John’s wort, and still not something to experiment with.",
    why: "Kratom has serotonergic activity besides its opioid-like effect. Tramadol adds seizure risk on top.",
    whatToDo:
      "Don’t add kratom to an antidepressant, a triptan, dextromethorphan, or tramadol on your own. Agitation, heavy sweating, tremor, confusion, or a seizure needs urgent care. Bring the product with you.",
  },
  {
    id: "kratom-maoi",
    groups: [{ classes: ["kratom"] }, { classes: ["maoi"] }],
    severity: "major",
    title: "Kratom and an MAOI are a bad mix",
    plain: "{meds} can cause serotonin toxicity or blood-pressure swings. An MAOI already has a strict list. Kratom is not a safe exception.",
    why: "MAOIs block serotonin breakdown. Kratom has both serotonergic and stimulant-like activity.",
    whatToDo:
      "Do not combine them. A severe headache, chest pain, high fever, rigid muscles, or confusion is emergency care. The washout rules for an MAOI are a specialist decision.",
  },
  {
    id: "kratom-warfarin",
    groups: [{ classes: ["kratom"] }, { ids: ["warfarin"] }],
    severity: "moderate",
    title: "Kratom can make warfarin unpredictable",
    plain: "{meds} — kratom has been reported to push warfarin’s effect around, including a higher INR. Products aren’t standardized, so the effect isn’t either.",
    why: "Lab and case reports suggest kratom can inhibit liver enzymes that clear warfarin, including CYP2C9. That is not the same as a measured dose in a tablet.",
    whatToDo:
      "Tell the anticoagulation clinic before you take it, or as soon as you already have. Don’t adjust warfarin yourself. Watch for unusual bleeding.",
  },
  {
    id: "kratom-bupropion",
    groups: [{ classes: ["kratom"] }, { ids: ["bupropion"] }],
    severity: "moderate",
    title: "Seizure risk goes up",
    plain: "{meds} each lower the seizure threshold. Together the risk is higher, and kratom dose is rarely what the label implies.",
    why: "Bupropion is dose-limited because of seizures. Kratom has also been tied to seizures, especially with other at-risk drugs.",
    whatToDo: "Don’t combine them on your own. A seizure is emergency care.",
  },
  {
    id: "kratom-decongestant",
    groups: [{ classes: ["kratom"] }, { classes: ["decongestant"] }],
    severity: "moderate",
    title: "Both can raise blood pressure and heart rate",
    plain: "{meds} — pseudoephedrine and kratom can each make the pulse and blood pressure climb. Together that is more than a stuffy-nose fix.",
    why: "Kratom has stimulant effects at many doses. Decongestants add a second stimulant.",
    whatToDo: "Skip the decongestant, or ask a pharmacist for a non-stimulant option. Chest pain or a severe headache is emergency care.",
  },
];
