import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Info, c as Check, i as Search, n as TriangleAlert, o as Copy, r as Trash2, s as ChevronDown, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DxPcA8yY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BUCKETS = [
	"Heart & pressure",
	"Cholesterol",
	"Clotting",
	"Pain",
	"Diabetes",
	"Mood & sleep",
	"Infection",
	"Stomach",
	"Thyroid, hormones & bone",
	"Breathing & allergy",
	"Joints & immune",
	"Peptides",
	"Other prescriptions",
	"Food, drink & supplements"
];
var QUICK_ADD = [
	"ibuprofen",
	"aspirin",
	"acetaminophen",
	"lisinopril",
	"atorvastatin",
	"metformin",
	"sertraline",
	"omeprazole"
];
var DRUGS = [
	{
		id: "lisinopril",
		generic: "Lisinopril",
		brands: ["Zestril", "Prinivil"],
		aliases: ["ace inhibitor", "blood pressure"],
		classes: ["acei"],
		bucket: "Heart & pressure",
		plain: "Relaxes blood vessels so pressure falls. A dry cough is a known side effect of this family, not necessarily a cold.",
		usedFor: "High blood pressure and heart failure",
		watch: ["Potassium can creep up. Salt substitutes are often potassium chloride — don’t start one on your own.", "Dehydration (a stomach bug, a heat wave) raises the chance of a kidney bump. Ask if you should pause it when you can’t keep fluids down."]
	},
	{
		id: "enalapril",
		generic: "Enalapril",
		brands: ["Vasotec"],
		aliases: ["ace inhibitor"],
		classes: ["acei"],
		bucket: "Heart & pressure",
		plain: "An ACE inhibitor, same family as lisinopril. It lowers blood pressure by relaxing vessels.",
		usedFor: "High blood pressure and heart failure",
		watch: ["A dry cough can be the medicine itself.", "Potassium and kidney labs are part of staying on it safely."]
	},
	{
		id: "losartan",
		generic: "Losartan",
		brands: ["Cozaar"],
		aliases: ["arb", "blood pressure"],
		classes: ["arb"],
		bucket: "Heart & pressure",
		plain: "An ARB. It lowers blood pressure in a similar way to ACE inhibitors, usually without the dry cough.",
		usedFor: "High blood pressure and diabetic kidney protection",
		watch: ["Potassium can rise. Don’t add potassium pills or salt substitutes unless someone is checking labs."]
	},
	{
		id: "valsartan",
		generic: "Valsartan",
		brands: ["Diovan"],
		aliases: ["arb"],
		classes: ["arb"],
		bucket: "Heart & pressure",
		plain: "An ARB blood-pressure medicine, related to losartan.",
		usedFor: "High blood pressure and heart failure",
		watch: ["Kidney function and potassium are the labs that matter with this one."]
	},
	{
		id: "amlodipine",
		generic: "Amlodipine",
		brands: ["Norvasc"],
		aliases: ["calcium channel blocker", "blood pressure"],
		classes: ["ccb_dhp"],
		bucket: "Heart & pressure",
		plain: "A calcium-channel blocker. It relaxes arteries. Ankle swelling is common and is not always ‘extra fluid’ from the heart.",
		usedFor: "High blood pressure and chest pain from narrow arteries",
		watch: ["Grapefruit is a smaller issue here than with simvastatin, but large daily amounts are still worth mentioning.", "With simvastatin, the statin dose often has to stay modest."]
	},
	{
		id: "diltiazem",
		generic: "Diltiazem",
		brands: ["Cardizem", "Cartia"],
		aliases: ["calcium channel blocker"],
		classes: ["ccb_nondhp"],
		bucket: "Heart & pressure",
		plain: "A calcium-channel blocker that also slows the heart rate. It blocks a liver enzyme that clears several other drugs.",
		usedFor: "Blood pressure, chest pain, and rate control",
		watch: ["It can slow the pulse a lot if combined with a beta blocker.", "Ankles can swell."]
	},
	{
		id: "verapamil",
		generic: "Verapamil",
		brands: ["Calan", "Verelan"],
		aliases: ["calcium channel blocker"],
		classes: ["ccb_nondhp"],
		bucket: "Heart & pressure",
		plain: "A heart-rate-slowing calcium-channel blocker. Constipation is a frequent, ordinary side effect.",
		usedFor: "Blood pressure, chest pain, and heart-rate control",
		watch: ["Stacking it with a beta blocker can slow the heart too far.", "It raises levels of several other medicines."]
	},
	{
		id: "metoprolol",
		generic: "Metoprolol",
		brands: ["Lopressor", "Toprol-XL"],
		aliases: ["beta blocker", "blood pressure"],
		classes: ["beta_blocker"],
		bucket: "Heart & pressure",
		plain: "A beta blocker. It slows the pulse and lowers blood pressure. Stopping it suddenly can make chest pain or a racing heart rebound.",
		usedFor: "Blood pressure, heart rate, heart failure, and after a heart attack",
		watch: ["It can hide a fast heartbeat — one of the usual warning signs of low blood sugar.", "Don’t stop it abruptly unless a clinician tells you to."]
	},
	{
		id: "carvedilol",
		generic: "Carvedilol",
		brands: ["Coreg"],
		aliases: ["beta blocker"],
		classes: ["beta_blocker"],
		bucket: "Heart & pressure",
		plain: "A beta blocker often used in heart failure. It slows the heart and widens vessels a bit.",
		usedFor: "Heart failure and blood pressure",
		watch: ["Dizziness on standing is common at the start.", "Don’t stop suddenly."]
	},
	{
		id: "atenolol",
		generic: "Atenolol",
		brands: ["Tenormin"],
		aliases: ["beta blocker"],
		classes: ["beta_blocker"],
		bucket: "Heart & pressure",
		plain: "A beta blocker that is cleared more by the kidneys than by the liver.",
		usedFor: "Blood pressure and heart rate",
		watch: ["Don’t stop it suddenly.", "The dose often changes if kidney function falls."]
	},
	{
		id: "hydrochlorothiazide",
		generic: "Hydrochlorothiazide",
		brands: ["Microzide"],
		aliases: [
			"hctz",
			"water pill",
			"thiazide"
		],
		classes: ["thiazide", "k_wasting"],
		bucket: "Heart & pressure",
		plain: "A ‘water pill.’ It helps the kidneys spill salt and water. It also spills potassium.",
		usedFor: "High blood pressure and mild swelling",
		watch: ["Leg cramps can be a clue that potassium is low.", "It can make lithium levels climb — a classic, important overlap."]
	},
	{
		id: "furosemide",
		generic: "Furosemide",
		brands: ["Lasix"],
		aliases: ["water pill", "loop diuretic"],
		classes: ["loop", "k_wasting"],
		bucket: "Heart & pressure",
		plain: "A stronger water pill. Urine output goes up within an hour. Potassium and magnesium can fall.",
		usedFor: "Swelling from heart, kidney, or liver disease",
		watch: ["Low potassium makes digoxin more dangerous.", "Weighing yourself is often how people notice they need a dose check — follow the plan you were given."]
	},
	{
		id: "spironolactone",
		generic: "Spironolactone",
		brands: ["Aldactone"],
		aliases: ["water pill", "potassium sparing"],
		classes: ["k_sparing"],
		bucket: "Heart & pressure",
		plain: "A water pill that holds onto potassium instead of wasting it. Breast tenderness can happen in any sex.",
		usedFor: "Heart failure, swelling, and high blood pressure",
		watch: ["Potassium can get too high, especially with ACE inhibitors, ARBs, or potassium pills.", "Salt substitutes are usually potassium. Ask first."]
	},
	{
		id: "digoxin",
		generic: "Digoxin",
		brands: ["Lanoxin"],
		aliases: ["digitalis"],
		classes: ["cardiac_glycoside"],
		bucket: "Heart & pressure",
		plain: "An older heart medicine with a narrow safe range. Too much causes nausea, vision halos, and a slow or irregular pulse.",
		usedFor: "Heart failure and rate control in atrial fibrillation",
		watch: ["Poor appetite, confusion, or yellow-green vision halos need a same-day call.", "Low potassium — often from water pills — makes toxicity more likely."]
	},
	{
		id: "amiodarone",
		generic: "Amiodarone",
		brands: ["Pacerone", "Cordarone"],
		aliases: ["antiarrhythmic"],
		classes: ["antiarrhythmic", "qt_risk"],
		bucket: "Heart & pressure",
		plain: "A powerful rhythm medicine that stays in the body for weeks to months. It changes how many other drugs are cleared.",
		usedFor: "Serious heart-rhythm problems",
		watch: ["Sunburn happens easily. Thyroid, liver, and lungs are monitored on purpose.", "Warfarin and digoxin doses are often cut when this is started."]
	},
	{
		id: "nitroglycerin",
		generic: "Nitroglycerin",
		brands: ["Nitrostat", "Nitrolingual"],
		aliases: [
			"nitro",
			"ntg",
			"chest spray"
		],
		classes: ["nitrate"],
		bucket: "Heart & pressure",
		plain: "A fast nitrate for chest pain. It widens blood vessels. Sit down — dizziness is expected.",
		usedFor: "Angina (chest pain from the heart)",
		watch: ["Never combine with sildenafil (Viagra) or tadalafil (Cialis). The pressure drop can be dangerous.", "If chest pain is new, severe, or not easing as your plan says, that is emergency care — and tell them about any erectile medicine."]
	},
	{
		id: "isosorbide",
		generic: "Isosorbide mononitrate",
		brands: ["Imdur"],
		aliases: [
			"isosorbide",
			"nitrate",
			"imdur"
		],
		classes: ["nitrate"],
		bucket: "Heart & pressure",
		plain: "A daily nitrate pill, not just an emergency spray. It keeps blood vessels relaxed through the day.",
		usedFor: "Prevention of angina",
		watch: ["Erectile medicines like sildenafil and tadalafil are not safe with any nitrate, including this daily one.", "A headache is common and often eases over time."]
	},
	{
		id: "atorvastatin",
		generic: "Atorvastatin",
		brands: ["Lipitor"],
		aliases: ["statin", "cholesterol"],
		classes: ["statin", "statin_3a4_mod"],
		bucket: "Cholesterol",
		plain: "A statin. It lowers LDL cholesterol and stabilizes plaque. Muscle aches need reporting, especially with fever or dark urine.",
		usedFor: "High cholesterol and heart-attack prevention",
		watch: ["Large amounts of grapefruit juice can raise the level. A small glass now and then is a different conversation than daily quarts.", "Clarithromycin and some heart medicines raise the level more than azithromycin does."]
	},
	{
		id: "simvastatin",
		generic: "Simvastatin",
		brands: ["Zocor"],
		aliases: ["statin", "cholesterol"],
		classes: ["statin", "statin_3a4_high"],
		bucket: "Cholesterol",
		plain: "A statin that is especially sensitive to grapefruit and to certain antibiotics and heart medicines.",
		usedFor: "High cholesterol",
		watch: ["Avoid grapefruit juice.", "Unexplained muscle pain, weakness, or cola-colored urine needs a call — that can be muscle breakdown."]
	},
	{
		id: "lovastatin",
		generic: "Lovastatin",
		brands: ["Mevacor", "Altoprev"],
		aliases: ["statin"],
		classes: ["statin", "statin_3a4_high"],
		bucket: "Cholesterol",
		plain: "A statin in the same sensitive group as simvastatin. Grapefruit and some antibiotics don’t mix well with it.",
		usedFor: "High cholesterol",
		watch: ["Avoid grapefruit.", "Report unexplained muscle pain or dark urine."]
	},
	{
		id: "rosuvastatin",
		generic: "Rosuvastatin",
		brands: ["Crestor"],
		aliases: ["statin", "cholesterol"],
		classes: ["statin"],
		bucket: "Cholesterol",
		plain: "A statin that is less bothered by grapefruit than simvastatin or lovastatin. It is still a statin — muscle symptoms matter.",
		usedFor: "High cholesterol",
		watch: ["Grapefruit is not the big issue it is with simvastatin, which is why this one is often chosen.", "Still report unexplained muscle pain or dark urine."]
	},
	{
		id: "pravastatin",
		generic: "Pravastatin",
		brands: ["Pravachol"],
		aliases: ["statin"],
		classes: ["statin"],
		bucket: "Cholesterol",
		plain: "A statin cleared by a different route. Grapefruit and many enzyme-blocking drugs affect it less.",
		usedFor: "High cholesterol",
		watch: ["Muscle pain that is new and unexplained still deserves a call."]
	},
	{
		id: "warfarin",
		generic: "Warfarin",
		brands: ["Coumadin", "Jantoven"],
		aliases: [
			"blood thinner",
			"coumadin",
			"anticoagulant"
		],
		classes: ["anticoagulant", "vka"],
		bucket: "Clotting",
		plain: "A blood thinner dosed to a lab test called the INR. Many foods, antibiotics, and pain pills move that number.",
		usedFor: "Clot prevention and treatment",
		watch: [
			"Leafy greens are allowed — keep the amount steady week to week instead of banning them.",
			"Call urgently for black stools, vomiting blood, a sudden severe headache, or a hard hit to the head.",
			"Ask before any new antibiotic, pain pill, or supplement."
		]
	},
	{
		id: "apixaban",
		generic: "Apixaban",
		brands: ["Eliquis"],
		aliases: [
			"blood thinner",
			"doac",
			"eliquis"
		],
		classes: ["anticoagulant", "doac"],
		bucket: "Clotting",
		plain: "A newer blood thinner. No routine INR, but bleeding risk is still real — especially with pain pills.",
		usedFor: "Atrial fibrillation and clot treatment or prevention",
		watch: ["Don’t double up after a missed dose unless your plan says so. Twice-daily timing matters.", "Ibuprofen and naproxen add bleeding risk. Ask before using them."]
	},
	{
		id: "rivaroxaban",
		generic: "Rivaroxaban",
		brands: ["Xarelto"],
		aliases: ["blood thinner", "doac"],
		classes: ["anticoagulant", "doac"],
		bucket: "Clotting",
		plain: "A once-daily blood thinner for many people. Higher doses are taken with food so the body absorbs them.",
		usedFor: "Atrial fibrillation and clots",
		watch: ["Take the larger doses with a real meal, not just a cracker, if that’s what you were told.", "Avoid casual NSAID pain pills."]
	},
	{
		id: "dabigatran",
		generic: "Dabigatran",
		brands: ["Pradaxa"],
		aliases: ["blood thinner", "doac"],
		classes: ["anticoagulant", "doac"],
		bucket: "Clotting",
		plain: "A blood thinner capsule. It must stay in the original bottle — damp pill organizers can ruin it.",
		usedFor: "Atrial fibrillation and clots",
		watch: ["Heartburn is fairly common.", "Don’t crush or store it loose for the week."]
	},
	{
		id: "clopidogrel",
		generic: "Clopidogrel",
		brands: ["Plavix"],
		aliases: [
			"blood thinner",
			"antiplatelet",
			"plavix"
		],
		classes: ["antiplatelet"],
		bucket: "Clotting",
		plain: "An antiplatelet. It stops platelets from clumping. People often call it a blood thinner, but it is not the same family as warfarin or Eliquis.",
		usedFor: "Stents, heart attacks, and stroke prevention",
		watch: ["Omeprazole and esomeprazole can make it work less well. Pantoprazole is often the acid pill chosen instead.", "Bleeding and bruising are more likely, especially with aspirin or NSAIDs."]
	},
	{
		id: "aspirin",
		generic: "Aspirin",
		brands: ["Bayer", "Ecotrin"],
		aliases: [
			"asa",
			"baby aspirin",
			"heart aspirin"
		],
		classes: ["antiplatelet"],
		bucket: "Clotting",
		plain: "At low dose it is a clot-prevention medicine. At pain-relief doses it is also hard on the stomach. This entry covers both.",
		usedFor: "Heart protection, pain, and fever",
		watch: ["Ibuprofen, taken close to the same time, can block the heart-protection effect of low-dose aspirin.", "Not for children or teens with viral illness — that raises Reye syndrome risk."]
	},
	{
		id: "ibuprofen",
		generic: "Ibuprofen",
		brands: ["Advil", "Motrin"],
		aliases: [
			"nsaid",
			"advil",
			"motrin"
		],
		classes: ["nsaid"],
		bucket: "Pain",
		plain: "An NSAID pain and fever medicine. It can irritate the stomach, strain the kidneys, and add bleeding risk on blood thinners.",
		usedFor: "Pain, fever, and inflammation",
		watch: ["Take the lowest dose that helps, for the shortest time.", "Late pregnancy is a reason to avoid it unless a clinician directs it."]
	},
	{
		id: "naproxen",
		generic: "Naproxen",
		brands: ["Aleve", "Naprosyn"],
		aliases: ["nsaid", "aleve"],
		classes: ["nsaid"],
		bucket: "Pain",
		plain: "A longer-lasting NSAID than ibuprofen. Same family risks: stomach, kidneys, blood pressure, and bleeding.",
		usedFor: "Pain and inflammation",
		watch: ["Two NSAIDs together (for example Aleve plus Advil) add risk without adding much relief."]
	},
	{
		id: "celecoxib",
		generic: "Celecoxib",
		brands: ["Celebrex"],
		aliases: ["nsaid", "cox-2"],
		classes: ["nsaid"],
		bucket: "Pain",
		plain: "An NSAID designed to be easier on the stomach. It can still affect kidneys, blood pressure, and bleeding on blood thinners.",
		usedFor: "Arthritis and pain",
		watch: ["‘Easier on the stomach’ does not mean safe with warfarin or in dehydration."]
	},
	{
		id: "acetaminophen",
		generic: "Acetaminophen",
		brands: ["Tylenol"],
		aliases: [
			"apap",
			"paracetamol",
			"tylenol"
		],
		classes: ["analgesic"],
		bucket: "Pain",
		plain: "A pain and fever medicine that is not an NSAID. The main everyday danger is taking too much, because it hides in many combination products.",
		usedFor: "Pain and fever",
		watch: [
			"Percocet, some Norco/Vicodin, and many cold syrups already contain it. Add those doses together.",
			"Daily heavy drinking plus high doses is hard on the liver.",
			"Several days of higher doses can nudge warfarin’s INR up."
		]
	},
	{
		id: "tramadol",
		generic: "Tramadol",
		brands: ["Ultram", "ConZip"],
		aliases: ["opioid", "ultram"],
		classes: [
			"opioid",
			"opioid_serotonergic",
			"full_agonist"
		],
		bucket: "Pain",
		plain: "A weaker opioid that also raises serotonin. Seizure risk is higher than with many other pain medicines, especially with antidepressants.",
		usedFor: "Pain",
		watch: ["Not a ‘safe opioid.’ Breathing, sedation, and serotonin reactions still happen.", "Seizure risk rises with high doses and with some antidepressants."]
	},
	{
		id: "hydrocodone",
		generic: "Hydrocodone",
		brands: [
			"Norco",
			"Vicodin",
			"Hysingla"
		],
		aliases: [
			"opioid",
			"norco",
			"vicodin"
		],
		classes: ["opioid", "full_agonist"],
		bucket: "Pain",
		plain: "An opioid pain medicine. Norco and Vicodin also contain acetaminophen — extra Tylenol on top can stack the liver dose.",
		usedFor: "Moderate to severe pain",
		watch: ["Alcohol, Xanax-type medicines, and sleep medicines can slow breathing dangerously.", "Constipation is expected. Ask for a plan instead of waiting it out."]
	},
	{
		id: "oxycodone",
		generic: "Oxycodone",
		brands: [
			"OxyContin",
			"Percocet",
			"Roxicodone"
		],
		aliases: ["opioid", "percocet"],
		classes: ["opioid", "full_agonist"],
		bucket: "Pain",
		plain: "An opioid. Percocet also contains acetaminophen. OxyContin is a long-acting form that must not be crushed.",
		usedFor: "Moderate to severe pain",
		watch: ["Do not mix with alcohol or benzodiazepines such as alprazolam, lorazepam, or clonazepam.", "If a product name includes Percocet, count the acetaminophen."]
	},
	{
		id: "morphine",
		generic: "Morphine",
		brands: ["MS Contin"],
		aliases: ["opioid"],
		classes: ["opioid", "full_agonist"],
		bucket: "Pain",
		plain: "A strong opioid. Long-acting tablets must be swallowed whole.",
		usedFor: "Severe pain",
		watch: ["Breathing can slow, especially with alcohol, benzodiazepines, or gabapentinoids.", "Itching and constipation are common."]
	},
	{
		id: "metformin",
		generic: "Metformin",
		brands: ["Glucophage"],
		aliases: ["diabetes"],
		classes: ["biguanide"],
		bucket: "Diabetes",
		plain: "A first-line diabetes medicine. It lowers sugar without usually causing lows by itself. Stomach upset is common early on.",
		usedFor: "Type 2 diabetes",
		watch: [
			"Diarrhea often settles if the dose is raised slowly.",
			"Heavy binge drinking is the everyday habit most worth flagging.",
			"Around contrast scans, follow the hold instructions you were given — they are not the same for everyone."
		]
	},
	{
		id: "glipizide",
		generic: "Glipizide",
		brands: ["Glucotrol"],
		aliases: ["sulfonylurea", "diabetes"],
		classes: ["sulfonylurea"],
		bucket: "Diabetes",
		plain: "Pushes the pancreas to release more insulin. Unlike metformin, it can cause low blood sugar.",
		usedFor: "Type 2 diabetes",
		watch: ["Shakiness, sweating, and confusion can be a low. Carry a fast sugar if you were told to.", "Beta blockers can hide the racing-heart warning of a low."]
	},
	{
		id: "insulin",
		generic: "Insulin",
		brands: [
			"Lantus",
			"Basaglar",
			"Humalog",
			"Novolog",
			"Tresiba"
		],
		aliases: [
			"lantus",
			"humalog",
			"novolog",
			"diabetes"
		],
		classes: ["insulin"],
		bucket: "Diabetes",
		plain: "The hormone that moves sugar into cells. This one entry stands in for long-acting and mealtime insulins.",
		usedFor: "Type 1 and type 2 diabetes",
		watch: ["Know your low-sugar plan. A beta blocker can blunt the fast-heartbeat warning; sweating may still happen.", "Doses are not interchangeable between brands and types."]
	},
	{
		id: "sertraline",
		generic: "Sertraline",
		brands: ["Zoloft"],
		aliases: [
			"ssri",
			"antidepressant",
			"zoloft"
		],
		classes: ["ssri"],
		bucket: "Mood & sleep",
		plain: "An SSRI antidepressant. It is also used for anxiety, PTSD, and OCD. It raises bleeding risk a little, and more so with pain pills.",
		usedFor: "Depression, anxiety, PTSD, and OCD",
		watch: ["The first weeks can feel more anxious or unsettled before it helps.", "Don’t stop suddenly — dizziness and ‘brain zaps’ are common if you do."]
	},
	{
		id: "fluoxetine",
		generic: "Fluoxetine",
		brands: ["Prozac"],
		aliases: [
			"ssri",
			"antidepressant",
			"prozac"
		],
		classes: ["ssri", "cyp2d6_strong"],
		bucket: "Mood & sleep",
		plain: "An SSRI that lingers for weeks after the last dose. It strongly blocks a liver enzyme that clears several other drugs, including some beta blockers.",
		usedFor: "Depression, anxiety, OCD, and bulimia",
		watch: ["Because it lasts so long, interactions can continue after you stop it.", "Don’t stop suddenly without a plan."]
	},
	{
		id: "escitalopram",
		generic: "Escitalopram",
		brands: ["Lexapro"],
		aliases: ["ssri", "lexapro"],
		classes: ["ssri", "qt_risk"],
		bucket: "Mood & sleep",
		plain: "An SSRI. Higher doses, older age, and low potassium are when its heart-rhythm caution matters most.",
		usedFor: "Depression and anxiety",
		watch: ["Omeprazole can raise the level.", "Don’t stop suddenly."]
	},
	{
		id: "citalopram",
		generic: "Citalopram",
		brands: ["Celexa"],
		aliases: ["ssri", "celexa"],
		classes: ["ssri", "qt_risk"],
		bucket: "Mood & sleep",
		plain: "An SSRI with a clearer heart-rhythm (QT) limit than most antidepressants in this list. Dose ceilings exist for a reason, especially over age 60.",
		usedFor: "Depression",
		watch: ["Don’t raise the dose on your own.", "Low potassium or low magnesium makes the rhythm issue more important."]
	},
	{
		id: "paroxetine",
		generic: "Paroxetine",
		brands: ["Paxil"],
		aliases: ["ssri", "paxil"],
		classes: ["ssri", "cyp2d6_strong"],
		bucket: "Mood & sleep",
		plain: "An SSRI that is harder to stop than some others, and a strong blocker of the enzyme that clears metoprolol.",
		usedFor: "Depression, anxiety, and panic",
		watch: ["Taper only with a clinician. Stopping abruptly is famously rough with this one."]
	},
	{
		id: "venlafaxine",
		generic: "Venlafaxine",
		brands: ["Effexor"],
		aliases: ["snri", "antidepressant"],
		classes: ["snri"],
		bucket: "Mood & sleep",
		plain: "An SNRI. It raises serotonin and norepinephrine. Blood pressure can creep up, and missed doses cause quick withdrawal symptoms.",
		usedFor: "Depression and anxiety",
		watch: ["Take it regularly — a late dose can cause dizziness and electricity-like sensations.", "Blood pressure is worth checking."]
	},
	{
		id: "duloxetine",
		generic: "Duloxetine",
		brands: ["Cymbalta"],
		aliases: ["snri", "antidepressant"],
		classes: ["snri"],
		bucket: "Mood & sleep",
		plain: "An SNRI used for mood and for nerve pain. It is not an NSAID, but it still adds some bleeding tendency.",
		usedFor: "Depression, anxiety, nerve pain, and fibromyalgia",
		watch: ["Don’t stop suddenly.", "Liver disease is a reason the dose may not be appropriate."]
	},
	{
		id: "bupropion",
		generic: "Bupropion",
		brands: ["Wellbutrin", "Zyban"],
		aliases: ["wellbutrin", "antidepressant"],
		classes: ["ndri"],
		bucket: "Mood & sleep",
		plain: "An antidepressant that is not an SSRI. It is more activating than sedating. Seizure risk is the main dose-limiting issue.",
		usedFor: "Depression and smoking cessation",
		watch: ["Alcohol binges and tramadol both push seizure risk the wrong way.", "It is usually avoided in people with an eating disorder or a seizure history."]
	},
	{
		id: "trazodone",
		generic: "Trazodone",
		brands: ["Desyrel"],
		aliases: ["sleep", "desyrel"],
		classes: ["sari", "sedating"],
		bucket: "Mood & sleep",
		plain: "Often used at night for sleep, sometimes for depression. It is sedating and mildly serotonergic.",
		usedFor: "Sleep and depression",
		watch: ["A painful erection that won’t settle is an emergency, even though it is uncommon.", "Morning hangover is common if the dose is high for you."]
	},
	{
		id: "alprazolam",
		generic: "Alprazolam",
		brands: ["Xanax"],
		aliases: [
			"benzo",
			"benzodiazepine",
			"xanax"
		],
		classes: ["benzo"],
		bucket: "Mood & sleep",
		plain: "A short-acting benzodiazepine. Relief is fast. With opioids or alcohol, breathing can slow to a dangerous level.",
		usedFor: "Anxiety and panic",
		watch: ["This combination with opioids has a boxed warning for fatal breathing suppression.", "Regular use should not be stopped cold turkey."]
	},
	{
		id: "lorazepam",
		generic: "Lorazepam",
		brands: ["Ativan"],
		aliases: ["benzo", "ativan"],
		classes: ["benzo"],
		bucket: "Mood & sleep",
		plain: "A benzodiazepine often used for anxiety or seizures in medical settings. It slows the brain.",
		usedFor: "Anxiety, agitation, and seizures",
		watch: ["Alcohol and opioids are the dangerous mix.", "Falls are more likely, especially in older adults."]
	},
	{
		id: "clonazepam",
		generic: "Clonazepam",
		brands: ["Klonopin"],
		aliases: ["benzo", "klonopin"],
		classes: ["benzo"],
		bucket: "Mood & sleep",
		plain: "A longer-acting benzodiazepine. It hangs around between doses, so sedation stacks quietly.",
		usedFor: "Panic, seizures, and some movement disorders",
		watch: ["Don’t combine casually with opioids, sleep medicines, or alcohol.", "Taper with a clinician if you have taken it regularly."]
	},
	{
		id: "zolpidem",
		generic: "Zolpidem",
		brands: ["Ambien"],
		aliases: [
			"sleeping pill",
			"ambien",
			"z-drug"
		],
		classes: ["zd"],
		bucket: "Mood & sleep",
		plain: "A sleep medicine. It is not a benzodiazepine, but it still depresses the brain and can cause sleepwalking or sleep-driving.",
		usedFor: "Short-term insomnia",
		watch: ["Take it only when you can stay in bed. No alcohol.", "Opioids plus this medicine are a breathing risk."]
	},
	{
		id: "gabapentin",
		generic: "Gabapentin",
		brands: ["Neurontin", "Gralise"],
		aliases: ["nerve pain", "neurontin"],
		classes: ["gabapentinoid"],
		bucket: "Mood & sleep",
		plain: "Used for nerve pain and seizures. With opioids it can slow breathing — that pairing has an FDA warning.",
		usedFor: "Nerve pain and seizures",
		watch: ["Dizziness and swelling are common.", "Don’t stop seizure doses suddenly."]
	},
	{
		id: "pregabalin",
		generic: "Pregabalin",
		brands: ["Lyrica"],
		aliases: ["nerve pain", "lyrica"],
		classes: ["gabapentinoid"],
		bucket: "Mood & sleep",
		plain: "A cousin of gabapentin, used for nerve pain, fibromyalgia, and seizures. Sedation and swelling are common.",
		usedFor: "Nerve pain, fibromyalgia, and seizures",
		watch: ["Opioids plus pregabalin raise the chance of dangerous sedation and slow breathing."]
	},
	{
		id: "lithium",
		generic: "Lithium",
		brands: ["Lithobid"],
		aliases: ["lithobid", "mood stabilizer"],
		classes: ["lithium"],
		bucket: "Mood & sleep",
		plain: "A mood stabilizer with a narrow safe range. Dehydration, water pills, NSAIDs, and ACE inhibitors can push it into toxicity.",
		usedFor: "Bipolar disorder",
		watch: ["New tremor, slurred speech, confusion, or severe diarrhea need same-day advice.", "Low-salt crash diets and stomach bugs dehydrate you and raise the level."]
	},
	{
		id: "phenelzine",
		generic: "Phenelzine",
		brands: ["Nardil"],
		aliases: ["maoi", "nardil"],
		classes: ["maoi"],
		bucket: "Mood & sleep",
		plain: "An MAOI antidepressant. It is uncommon and strict: many other medicines and some aged foods can cause a crisis.",
		usedFor: "Depression that hasn’t responded to other treatments",
		watch: ["Aged cheese, cured meats, tap beer, and soy sauce can spike blood pressure.", "Cold pills, other antidepressants, and tramadol are not casual add-ons. This needs a specialist list."]
	},
	{
		id: "carbamazepine",
		generic: "Carbamazepine",
		brands: ["Tegretol"],
		aliases: ["tegretol", "seizure"],
		classes: ["inducer"],
		bucket: "Mood & sleep",
		plain: "A seizure and nerve-pain medicine that speeds up the liver. It makes many other drugs — including birth-control pills and warfarin — wear off faster.",
		usedFor: "Seizures, trigeminal neuralgia, and bipolar disorder",
		watch: ["A rash needs a same-day call. Rarely it is severe.", "It is one of the medicines that really can make combined birth control less reliable."]
	},
	{
		id: "lamotrigine",
		generic: "Lamotrigine",
		brands: ["Lamictal"],
		aliases: ["lamictal", "seizure"],
		classes: ["anticonvulsant"],
		bucket: "Mood & sleep",
		plain: "Used for seizures and bipolar depression. The serious risk is a rash if the dose climbs too fast.",
		usedFor: "Seizures and bipolar disorder",
		watch: ["Any new rash needs urgent advice. Don’t start at a high dose.", "Estrogen-containing birth control can cut the level roughly in half."]
	},
	{
		id: "amoxicillin",
		generic: "Amoxicillin",
		brands: ["Amoxil"],
		aliases: ["antibiotic", "penicillin"],
		classes: ["penicillin", "antibiotic"],
		bucket: "Infection",
		plain: "A common penicillin antibiotic. Stomach upset and rash are the usual problems, not a long interaction list.",
		usedFor: "Bacterial infections such as ear, sinus, and strep throat",
		watch: ["A short course does not, by current evidence, cancel combined birth control pills.", "A rash with mono, or hives and trouble breathing, is a different problem — get care."]
	},
	{
		id: "azithromycin",
		generic: "Azithromycin",
		brands: ["Zithromax", "Z-Pak"],
		aliases: [
			"z pack",
			"zpak",
			"antibiotic"
		],
		classes: [
			"macrolide",
			"qt_risk",
			"antibiotic"
		],
		bucket: "Infection",
		plain: "A short-course antibiotic. It interacts with fewer cholesterol medicines than clarithromycin. It can still affect heart rhythm in susceptible people.",
		usedFor: "Bacterial respiratory and some other infections",
		watch: ["It is easier on simvastatin than clarithromycin is. That does not make it automatically fine with warfarin or QT-sensitive drugs."]
	},
	{
		id: "clarithromycin",
		generic: "Clarithromycin",
		brands: ["Biaxin"],
		aliases: ["antibiotic", "biaxin"],
		classes: [
			"macrolide",
			"macrolide_strong",
			"qt_risk",
			"antibiotic"
		],
		bucket: "Infection",
		plain: "An antibiotic that strongly blocks the enzyme clearing many common drugs. It is a frequent cause of serious interactions.",
		usedFor: "Bacterial infections, including some stomach-ulcer regimens",
		watch: ["Tell every prescriber, including dentists, that you are on it.", "Simvastatin, lovastatin, and colchicine are particularly poor partners."]
	},
	{
		id: "ciprofloxacin",
		generic: "Ciprofloxacin",
		brands: ["Cipro"],
		aliases: [
			"cipro",
			"antibiotic",
			"fluoroquinolone"
		],
		classes: [
			"fq",
			"qt_risk",
			"antibiotic"
		],
		bucket: "Infection",
		plain: "A fluoroquinolone antibiotic. Tendons, nerves, and the QT interval are the reasons it isn’t a casual first choice anymore.",
		usedFor: "Selected bacterial infections, including some urine infections",
		watch: ["Separate calcium, iron, magnesium, zinc, and antacids by several hours or it may not be absorbed. Those minerals are wasted in the same sitting.", "New tendon pain, especially with steroid pills, needs a call and rest."]
	},
	{
		id: "levofloxacin",
		generic: "Levofloxacin",
		brands: ["Levaquin"],
		aliases: ["antibiotic", "fluoroquinolone"],
		classes: [
			"fq",
			"qt_risk",
			"antibiotic"
		],
		bucket: "Infection",
		plain: "A fluoroquinolone, similar cautions to ciprofloxacin: tendons, rhythm, and binding to calcium, iron, magnesium, and zinc.",
		usedFor: "Selected serious bacterial infections",
		watch: ["Separate from antacids, calcium, iron, magnesium, and zinc.", "Steroid pills raise tendon-injury risk."]
	},
	{
		id: "doxycycline",
		generic: "Doxycycline",
		brands: ["Vibramycin"],
		aliases: ["antibiotic", "tetracycline"],
		classes: ["tetracycline", "antibiotic"],
		bucket: "Infection",
		plain: "A tetracycline antibiotic. Sunburn is easier, and calcium, iron, magnesium, or zinc in the stomach can block it — those minerals don’t absorb well either.",
		usedFor: "Infections, acne, rosacea, and malaria prevention",
		watch: ["Sit up with a full glass of water so it doesn’t irritate the esophagus.", "It does not have the strong birth-control warning that rifampin and carbamazepine do."]
	},
	{
		id: "smx-tmp",
		generic: "Sulfamethoxazole-trimethoprim",
		brands: ["Bactrim", "Septra"],
		aliases: [
			"bactrim",
			"septra",
			"sulfa",
			"tmp-smx"
		],
		classes: ["sulfa", "antibiotic"],
		bucket: "Infection",
		plain: "A sulfa antibiotic combination. It is famous for making warfarin too strong and for colliding with methotrexate.",
		usedFor: "Urine infections, skin infections, and some pneumonias",
		watch: ["Drink enough water unless you were told to limit fluids.", "Rash can rarely be severe — new widespread rash or mouth sores need urgent care."]
	},
	{
		id: "metronidazole",
		generic: "Metronidazole",
		brands: ["Flagyl"],
		aliases: ["flagyl", "antibiotic"],
		classes: ["nitroimidazole", "antibiotic"],
		bucket: "Infection",
		plain: "An antibiotic and antiparasitic. The label says not to drink alcohol during treatment and for a few days after.",
		usedFor: "Certain gut, pelvic, and dental infections",
		watch: ["Alcohol can cause flushing, vomiting, and a pounding heart. Skip it until a clinician says the drug has cleared — often about three days after the last dose.", "It can make warfarin too strong."]
	},
	{
		id: "rifampin",
		generic: "Rifampin",
		brands: ["Rifadin"],
		aliases: ["rifampicin", "antibiotic"],
		classes: ["inducer", "antibiotic"],
		bucket: "Infection",
		plain: "An antibiotic for tuberculosis and a few other serious infections. It speeds the liver so hard that birth-control pills, warfarin, and many others can fail.",
		usedFor: "Tuberculosis and selected serious infections",
		watch: ["This is one of the few antibiotics that really can cancel combined birth control.", "Urine, sweat, and tears can turn orange. Soft contacts can stain."]
	},
	{
		id: "omeprazole",
		generic: "Omeprazole",
		brands: ["Prilosec"],
		aliases: [
			"ppi",
			"acid reflux",
			"prilosec"
		],
		classes: ["ppi", "ppi_2c19"],
		bucket: "Stomach",
		plain: "A proton-pump inhibitor. It shuts down stomach acid. It also blocks an enzyme needed to activate clopidogrel and to clear citalopram.",
		usedFor: "Reflux, ulcers, and heartburn",
		watch: ["Long courses can lower magnesium and B12 and slightly raise fracture risk. Use the shortest course that helps unless you were told to stay on it.", "If you take Plavix, ask whether pantoprazole is a better acid pill."]
	},
	{
		id: "esomeprazole",
		generic: "Esomeprazole",
		brands: ["Nexium"],
		aliases: ["ppi", "nexium"],
		classes: ["ppi", "ppi_2c19"],
		bucket: "Stomach",
		plain: "A close cousin of omeprazole with the same clopidogrel caution.",
		usedFor: "Reflux and ulcers",
		watch: ["Same long-term PPI cautions as omeprazole: magnesium, B12, and whether you still need it."]
	},
	{
		id: "pantoprazole",
		generic: "Pantoprazole",
		brands: ["Protonix"],
		aliases: ["ppi", "protonix"],
		classes: ["ppi"],
		bucket: "Stomach",
		plain: "A PPI often chosen when someone also takes clopidogrel, because it blocks the relevant enzyme less than omeprazole.",
		usedFor: "Reflux and ulcers",
		watch: ["It is not interaction-free — it can still reduce levothyroxine absorption a bit — but it is the usual PPI with Plavix."]
	},
	{
		id: "levothyroxine",
		generic: "Levothyroxine",
		brands: ["Synthroid", "Levoxyl"],
		aliases: ["synthroid", "thyroid"],
		classes: ["thyroid"],
		bucket: "Thyroid, hormones & bone",
		plain: "Thyroid hormone replacement. Absorption is fussy: coffee, calcium, iron, and food timing all change the dose that gets in.",
		usedFor: "Hypothyroidism",
		watch: ["Take it the same way every day, usually on an empty stomach.", "Separate calcium and iron by about four hours."]
	},
	{
		id: "prednisone",
		generic: "Prednisone",
		brands: ["Deltasone"],
		aliases: ["steroid", "corticosteroid"],
		classes: ["corticosteroid"],
		bucket: "Thyroid, hormones & bone",
		plain: "A steroid pill that calms inflammation. It raises blood sugar, thins sleep, and is hard on the stomach lining when paired with NSAIDs.",
		usedFor: "Flares of asthma, arthritis, allergic reactions, and many inflammatory illnesses",
		watch: ["Don’t stop a long course suddenly. The body needs a taper.", "Mood and sleep can swing. Blood sugar rises, even in people without diabetes."]
	},
	{
		id: "combined-pill",
		generic: "Combined birth control pill",
		brands: ["Many estrogen-plus-progestin brands"],
		aliases: [
			"the pill",
			"birth control",
			"oral contraceptive",
			"yaz",
			"yasmin",
			"sprintec"
		],
		classes: ["coc"],
		bucket: "Thyroid, hormones & bone",
		plain: "A pill with estrogen and a progestin. This entry does not stand in for an IUD, implant, shot, or progestin-only mini-pill.",
		usedFor: "Contraception and cycle regulation",
		watch: ["Most ordinary antibiotics, including amoxicillin, do not cancel it. Rifampin, some seizure medicines, and St John’s wort can.", "Vomiting or a bad diarrhea day can also mean a missed dose. Check the packet rules."]
	},
	{
		id: "alendronate",
		generic: "Alendronate",
		brands: ["Fosamax"],
		aliases: ["fosamax", "bisphosphonate"],
		classes: ["bisphosphonate"],
		bucket: "Thyroid, hormones & bone",
		plain: "A weekly or daily osteoporosis pill that only absorbs if the stomach is empty — and can irritate the esophagus if you lie down.",
		usedFor: "Osteoporosis",
		watch: ["Take with plain water on an empty stomach. Stay upright at least 30 minutes. No coffee, food, calcium, or other pills in that window."]
	},
	{
		id: "albuterol",
		generic: "Albuterol",
		brands: [
			"Ventolin",
			"ProAir",
			"Proventil"
		],
		aliases: ["inhaler", "rescue inhaler"],
		classes: ["saba"],
		bucket: "Breathing & allergy",
		plain: "A rescue inhaler. It opens airways quickly. Shaky hands and a fast pulse are common and usually brief.",
		usedFor: "Asthma and COPD symptoms",
		watch: ["Needing it more days than not means the prevention plan needs a look — not that you should just refill the rescue."]
	},
	{
		id: "montelukast",
		generic: "Montelukast",
		brands: ["Singulair"],
		aliases: ["singulair", "allergy"],
		classes: ["ltra"],
		bucket: "Breathing & allergy",
		plain: "A once-daily pill for asthma and allergies. Mood and sleep changes are uncommon but are the warning on the label.",
		usedFor: "Asthma and allergic rhinitis",
		watch: ["New depression, agitation, or sleep changes should be reported. It is not a rescue medicine for an asthma attack."]
	},
	{
		id: "diphenhydramine",
		generic: "Diphenhydramine",
		brands: ["Benadryl"],
		aliases: [
			"benadryl",
			"antihistamine",
			"sleep aid"
		],
		classes: ["antihistamine", "sedating"],
		bucket: "Breathing & allergy",
		plain: "A sedating antihistamine. It is in many ‘PM’ pain and sleep products, not only pink allergy pills.",
		usedFor: "Allergies, itching, and short-term sleep",
		watch: ["It stacks with opioids, benzodiazepines, and alcohol.", "Older adults are more prone to confusion and falls. Non-drowsy antihistamines are often preferred."]
	},
	{
		id: "loratadine",
		generic: "Loratadine",
		brands: ["Claritin"],
		aliases: ["claritin", "antihistamine"],
		classes: ["antihistamine"],
		bucket: "Breathing & allergy",
		plain: "A non-drowsy antihistamine for most people. It has fewer interaction and sedation problems than diphenhydramine.",
		usedFor: "Allergies and hives",
		watch: ["You usually don’t need this plus Benadryl. If one isn’t enough, ask rather than stacking."]
	},
	{
		id: "pseudoephedrine",
		generic: "Pseudoephedrine",
		brands: ["Sudafed"],
		aliases: ["sudafed", "decongestant"],
		classes: ["decongestant"],
		bucket: "Breathing & allergy",
		plain: "A decongestant that shrinks nasal vessels. It can raise blood pressure and heart rate and keep you awake.",
		usedFor: "Stuffy nose",
		watch: ["People with high blood pressure should ask before using it.", "With an MAOI antidepressant it can cause a dangerous pressure spike."]
	},
	{
		id: "dextromethorphan",
		generic: "Dextromethorphan",
		brands: ["Robitussin DM", "Delsym"],
		aliases: [
			"dxm",
			"cough medicine",
			"robitussin"
		],
		classes: ["dxm"],
		bucket: "Breathing & allergy",
		plain: "The ‘DM’ in many cough syrups. It is mildly serotonergic. Multi-symptom syrups often hide other drugs too.",
		usedFor: "Cough",
		watch: ["Read the box. Nighttime syrups may also contain acetaminophen and a sedating antihistamine.", "High doses plus an SSRI or an MAOI are a serotonin problem, not a party trick."]
	},
	{
		id: "colchicine",
		generic: "Colchicine",
		brands: ["Colcrys", "Mitigare"],
		aliases: ["gout"],
		classes: ["colchicine"],
		bucket: "Joints & immune",
		plain: "A gout medicine with a narrow safe range. Clarithromycin and grapefruit can push it to toxic levels.",
		usedFor: "Gout flares and prevention",
		watch: ["Diarrhea is the early overdose signal. Stop and call if it becomes severe.", "Don’t repeat old ‘take until diarrhea’ advice. Today’s dosing is tighter."]
	},
	{
		id: "allopurinol",
		generic: "Allopurinol",
		brands: ["Zyloprim"],
		aliases: ["gout", "zyloprim"],
		classes: ["allopurinol"],
		bucket: "Joints & immune",
		plain: "Lowers uric acid to prevent gout. A new rash can rarely be severe, especially in the first months.",
		usedFor: "Gout prevention and high uric acid",
		watch: ["Any new rash needs a same-day call, and you should not take the next dose until someone advises you.", "It does not treat a flare already in progress by itself."]
	},
	{
		id: "methotrexate",
		generic: "Methotrexate",
		brands: ["Trexall"],
		aliases: ["mtx", "trexall"],
		classes: ["mtx"],
		bucket: "Joints & immune",
		plain: "For arthritis and psoriasis it is usually once a week, not daily. Daily dosing by mistake is an emergency. High doses used in cancer are a different regimen.",
		usedFor: "Rheumatoid arthritis, psoriasis, and some cancers",
		watch: ["Confirm the weekday. Folic acid is often prescribed alongside and is not the same pill.", "Bactrim and NSAIDs are the add-ons most likely to make it toxic."]
	},
	{
		id: "sildenafil",
		generic: "Sildenafil",
		brands: ["Viagra", "Revatio"],
		aliases: ["viagra", "erectile dysfunction"],
		classes: ["pde5"],
		bucket: "Other prescriptions",
		plain: "Opens blood vessels. Used for erections and, at a different dose, for pulmonary hypertension. Nitrates are the dangerous partner.",
		usedFor: "Erectile dysfunction and pulmonary hypertension",
		watch: ["Do not take with nitroglycerin or isosorbide. The unsafe window is about 24 hours.", "An erection lasting more than four hours, or sudden vision or hearing loss, is emergency care."]
	},
	{
		id: "tadalafil",
		generic: "Tadalafil",
		brands: ["Cialis"],
		aliases: ["cialis"],
		classes: ["pde5"],
		bucket: "Other prescriptions",
		plain: "A longer-lasting cousin of sildenafil. The nitrate gap is longer — about 48 hours.",
		usedFor: "Erectile dysfunction, urinary symptoms, and pulmonary hypertension",
		watch: ["Nitrates are contraindicated for about 48 hours.", "Daily low-dose tadalafil still counts. It is not ‘out of your system’ by evening."]
	},
	{
		id: "tamsulosin",
		generic: "Tamsulosin",
		brands: ["Flomax"],
		aliases: ["flomax", "prostate"],
		classes: ["alpha_blocker"],
		bucket: "Other prescriptions",
		plain: "Relaxes the prostate and bladder neck so urine flows. It also relaxes blood vessels, so standing up can make you lightheaded.",
		usedFor: "Prostate symptoms",
		watch: ["The first doses are when dizziness is most likely.", "Erectile medicines add to the blood-pressure drop."]
	},
	{
		id: "sumatriptan",
		generic: "Sumatriptan",
		brands: ["Imitrex"],
		aliases: [
			"imitrex",
			"triptan",
			"migraine"
		],
		classes: ["triptan"],
		bucket: "Other prescriptions",
		plain: "A migraine medicine that narrows swollen cranial vessels. Chest tightness can happen and is often not a heart attack — but true chest pain still needs emergency care.",
		usedFor: "Migraine attacks",
		watch: ["Don’t stack a second triptan.", "SSRIs are usually still prescribed together; serious serotonin reactions are uncommon but are why we flag the pair."]
	},
	{
		id: "ondansetron",
		generic: "Ondansetron",
		brands: ["Zofran"],
		aliases: ["zofran", "nausea"],
		classes: ["qt_risk"],
		bucket: "Other prescriptions",
		plain: "A nausea medicine. A single dose is common after surgery or with a stomach bug. Rhythm risk matters more if other QT-prolonging drugs are on board.",
		usedFor: "Nausea and vomiting",
		watch: ["Constipation is the ordinary side effect.", "Low potassium makes the rhythm caution more relevant."]
	},
	{
		id: "potassium",
		generic: "Potassium supplement",
		brands: ["Klor-Con", "K-Dur"],
		aliases: [
			"klor-con",
			"salt substitute",
			"potassium chloride"
		],
		classes: ["potassium"],
		bucket: "Food, drink & supplements",
		plain: "A mineral supplement, and also what many salt substitutes are made of. With certain blood-pressure pills it can climb too high.",
		usedFor: "Low potassium, or replacing what a water pill wastes",
		watch: ["High potassium doesn’t always cause symptoms before it affects the heart. That’s why labs exist.", "If a water pill already spares potassium, you may not need this at all."]
	},
	{
		id: "ferrous-sulfate",
		generic: "Ferrous sulfate",
		brands: ["Iron supplement"],
		aliases: ["iron", "ferrous"],
		classes: ["iron", "polyvalent"],
		bucket: "Food, drink & supplements",
		plain: "Iron. It binds to several medicines in the stomach — thyroid hormone, some antibiotics — and blocks their absorption.",
		usedFor: "Iron deficiency",
		watch: ["Separate from levothyroxine, ciprofloxacin, and doxycycline by a few hours.", "Dark stools are expected. Constipation is common. Black tarry stools with weakness are not ‘just iron’ — that’s bleeding until proven otherwise."]
	},
	{
		id: "calcium-carbonate",
		generic: "Calcium carbonate",
		brands: ["Tums", "Caltrate"],
		aliases: [
			"calcium",
			"tums",
			"antacid"
		],
		classes: ["calcium", "polyvalent"],
		bucket: "Food, drink & supplements",
		plain: "A calcium supplement and a simple antacid. It grabs onto thyroid medicine, some antibiotics, and alendronate.",
		usedFor: "Calcium intake, heartburn, and phosphate binding",
		watch: ["Four hours away from levothyroxine is the usual ask.", "Don’t take it in the same swallow as Fosamax."]
	},
	{
		id: "vitamin-d",
		generic: "Vitamin D",
		brands: ["Cholecalciferol"],
		aliases: ["cholecalciferol", "d3"],
		classes: ["vitamin_d"],
		bucket: "Food, drink & supplements",
		plain: "A vitamin most adults are told to consider. Ordinary doses rarely show up as a drug interaction in this checker.",
		usedFor: "Low vitamin D and bone health",
		watch: ["Very high doses, especially with extra calcium, can raise blood calcium. More is not better once you’re replete."]
	},
	{
		id: "fish-oil",
		generic: "Fish oil",
		brands: ["Omega-3"],
		aliases: ["omega-3", "omega 3"],
		classes: ["fishoil"],
		bucket: "Food, drink & supplements",
		plain: "An omega-3 supplement. At high doses it can add a little extra bleeding tendency on top of blood thinners.",
		usedFor: "Triglycerides, or as a general supplement",
		watch: ["Prescription-strength doses matter more than a single small capsule. Tell your clinician the dose."]
	},
	{
		id: "ginkgo",
		generic: "Ginkgo",
		brands: ["Ginkgo biloba"],
		aliases: ["ginkgo biloba"],
		classes: ["ginkgo"],
		bucket: "Food, drink & supplements",
		plain: "An herbal supplement marketed for memory. Case reports link it to extra bleeding with blood thinners and antiplatelet drugs.",
		usedFor: "Supplement, often for memory",
		watch: ["Evidence for memory is weak. Bleeding reports are why it belongs on a medication list."]
	},
	{
		id: "st-johns-wort",
		generic: "St John's wort",
		brands: ["Hypericum"],
		aliases: [
			"st johns wort",
			"hypericum",
			"saint johns wort"
		],
		classes: ["stjohns", "inducer"],
		bucket: "Food, drink & supplements",
		plain: "An herbal product used for mood. It both raises serotonin and speeds up the liver, so it collides with antidepressants, birth control, warfarin, and some statins.",
		usedFor: "Supplement, often for low mood",
		watch: ["Don’t add it to an antidepressant.", "It can make combined birth control and warfarin less effective."]
	},
	{
		id: "alcohol",
		generic: "Alcohol",
		brands: [],
		aliases: [
			"beer",
			"wine",
			"liquor",
			"drinking"
		],
		classes: ["alcohol"],
		bucket: "Food, drink & supplements",
		plain: "Not a medicine. Added here because it changes bleeding, breathing, blood sugar, and how several drugs feel.",
		usedFor: "Everyday extra people forget to mention",
		watch: ["With opioids, benzodiazepines, or sleep medicines it can slow or stop breathing.", "A ‘couple of drinks’ still counts. You don’t need to be intoxicated for the interaction."]
	},
	{
		id: "grapefruit",
		generic: "Grapefruit",
		brands: [],
		aliases: ["grapefruit juice"],
		classes: ["grapefruit"],
		bucket: "Food, drink & supplements",
		plain: "A food that blocks the enzyme some drugs need in order to be cleared. The effect can last into the next day, not just the hour you drink it.",
		usedFor: "Everyday extra",
		watch: ["Simvastatin and lovastatin are the statins that care the most. Pravastatin and rosuvastatin much less so.", "Seville oranges and pomelos can act similarly. Ordinary sweet oranges usually do not."]
	},
	{
		id: "vitamin-c",
		generic: "Vitamin C",
		brands: ["Ascorbic acid", "Emergen-C"],
		aliases: [
			"ascorbic acid",
			"emergen-c",
			"vitamin c"
		],
		classes: ["vitamin_c"],
		bucket: "Food, drink & supplements",
		plain: "An everyday vitamin. It is not the supplement that binds to antibiotics. It does help iron get absorbed, which is useful or too much depending on the dose.",
		usedFor: "Low vitamin C, or as a general supplement",
		watch: ["Short antibiotic courses have not been shown to block vitamin C the way doxycycline and Cipro block iron, calcium, magnesium, and zinc.", "Very high doses can upset the stomach and, in some people, raise the chance of kidney stones."]
	},
	{
		id: "magnesium",
		generic: "Magnesium",
		brands: [
			"Magnesium oxide",
			"Magnesium citrate",
			"Magnesium glycinate"
		],
		aliases: [
			"mag",
			"magnesium oxide",
			"magnesium citrate",
			"magnesium glycinate"
		],
		classes: ["magnesium", "polyvalent"],
		bucket: "Food, drink & supplements",
		plain: "A mineral supplement used for constipation, sleep, or low magnesium. In the stomach it binds ciprofloxacin, levofloxacin, and doxycycline.",
		usedFor: "Low magnesium, constipation, or as a general supplement",
		watch: ["Separate it from those antibiotics by several hours or both are poorly absorbed.", "Loose stools are common, especially with citrate or oxide. Kidney disease changes whether extra magnesium is safe."]
	},
	{
		id: "zinc",
		generic: "Zinc",
		brands: ["Zinc sulfate", "Zinc gluconate"],
		aliases: ["zinc sulfate", "zinc lozenge"],
		classes: ["zinc", "polyvalent"],
		bucket: "Food, drink & supplements",
		plain: "A mineral in cold lozenges and immune supplements. It chelates the same antibiotics calcium and iron do.",
		usedFor: "Low zinc, or short-term cold lozenges",
		watch: ["Take it several hours away from Cipro, levofloxacin, or doxycycline.", "Long high doses can crowd out copper. Stomach upset is common on an empty stomach."]
	},
	{
		id: "multivitamin",
		generic: "Multivitamin",
		brands: ["Centrum", "One A Day"],
		aliases: [
			"multi vitamin",
			"centrum",
			"one a day",
			"prenatal vitamin"
		],
		classes: [
			"polyvalent",
			"calcium",
			"iron",
			"magnesium",
			"zinc"
		],
		bucket: "Food, drink & supplements",
		plain: "A combination pill. The letter vitamins are rarely the problem. The minerals inside — calcium, iron, magnesium, zinc — are what block certain antibiotics, thyroid hormone, and alendronate.",
		usedFor: "General supplementation",
		watch: ["Treat it like an iron-plus-calcium pill when you time other medicines.", "Prenatal vitamins are included here because they usually contain iron."]
	},
	{
		id: "probiotic",
		generic: "Probiotic",
		brands: [
			"Culturelle",
			"Align",
			"Florastor"
		],
		aliases: [
			"culturelle",
			"align",
			"florastor",
			"lactobacillus",
			"acidophilus",
			"s boulardii"
		],
		classes: ["probiotic"],
		bucket: "Food, drink & supplements",
		plain: "Live bacteria or yeast sold to support the gut. Antibiotics can kill bacterial probiotics if you swallow them together. The antibiotic still works; the supplement may not.",
		usedFor: "Gut flora during or after antibiotics, or as a general supplement",
		watch: ["Separate bacterial probiotics from the antibiotic by at least two hours.", "Yeast products such as Florastor are less affected by antibiotics. Live-bacteria products are usually avoided when the immune system is severely suppressed."]
	},
	{
		id: "vitamin-k",
		generic: "Vitamin K",
		brands: ["Phytonadione", "Mephyton"],
		aliases: [
			"phytonadione",
			"vitamin k1",
			"vitamin k2",
			"menaquinone"
		],
		classes: ["vitamin_k"],
		bucket: "Food, drink & supplements",
		plain: "The vitamin the body uses to build clotting factors. A supplement is a much bigger, steadier dose than a serving of spinach — and it works directly against warfarin.",
		usedFor: "Low vitamin K, or a prescribed warfarin antidote plan",
		watch: ["Don’t start or stop it on your own if you take warfarin. The INR moves.", "K1 and K2 both count. Food vitamin K is usually fine if the amount stays steady."]
	},
	{
		id: "vitamin-b12",
		generic: "Vitamin B12",
		brands: ["Cyanocobalamin", "Methylcobalamin"],
		aliases: [
			"b12",
			"cobalamin",
			"cyanocobalamin",
			"methylcobalamin"
		],
		classes: ["vitamin_b12"],
		bucket: "Food, drink & supplements",
		plain: "A B vitamin. Metformin and long-term acid-blocking pills can lower B12 over months. A supplement is often how people replace it — the level still needs checking.",
		usedFor: "Low B12",
		watch: ["This is a slow drain, not a same-hour block like iron and Cipro.", "Short antibiotic courses are not a proven reason B12 pills stop working."]
	},
	{
		id: "kratom",
		generic: "Kratom",
		brands: [],
		aliases: [
			"mitragyna",
			"mitragynine",
			"7-oh",
			"7 hydroxymitragynine"
		],
		classes: ["kratom"],
		bucket: "Food, drink & supplements",
		plain: "A plant product with opioid-like effects, and stimulant effects at lower doses. Potency varies widely, including concentrated 7-hydroxymitragynine products. It is not an approved medicine.",
		usedFor: "Supplement people often leave off the medication list",
		watch: ["Do not mix it with opioids, benzodiazepines, sleep medicines, or alcohol — breathing can slow.", "Stopping regular use can cause withdrawal. Products are not dose-standardized, so one bag is not the next bag."]
	},
	{
		id: "methadone",
		generic: "Methadone",
		brands: ["Methadose", "Dolophine"],
		aliases: [
			"methadose",
			"dolophine",
			"opioid"
		],
		classes: [
			"opioid",
			"qt_risk",
			"methadone",
			"full_agonist"
		],
		bucket: "Pain",
		plain: "A long-acting opioid used for pain and for opioid addiction treatment. It lingers for days, can affect heart rhythm, and a dose that was fine last month can become too strong if another medicine changes.",
		usedFor: "Severe pain, or opioid use disorder in a treatment program",
		watch: ["Breathing risk is the same family as other opioids: alcohol, benzodiazepines, and sleep medicines are the dangerous add-ons.", "Do not stop or start it on your own. The clinic dose is not a pain-pill dose you adjust at home."]
	},
	{
		id: "fentanyl",
		generic: "Fentanyl",
		brands: ["Duragesic"],
		aliases: ["duragesic", "opioid"],
		classes: ["opioid", "full_agonist"],
		bucket: "Pain",
		plain: "A very strong opioid, often as a patch. Heat, a damaged patch, or chewing a patch can release a dangerous amount at once.",
		usedFor: "Severe pain when other opioids are already in use",
		watch: ["Do not use a patch with alcohol, benzodiazepines, or sleep medicines.", "A patch still holds medicine after you take it off. Fold it and keep it away from children."]
	},
	{
		id: "hydromorphone",
		generic: "Hydromorphone",
		brands: ["Dilaudid", "Exalgo"],
		aliases: ["dilaudid", "opioid"],
		classes: ["opioid", "full_agonist"],
		bucket: "Pain",
		plain: "A strong opioid. Milligram for milligram it is much stronger than morphine, so a ‘small’ dose is not a small effect.",
		usedFor: "Severe pain",
		watch: ["Breathing risk with alcohol, benzodiazepines, and gabapentinoids is the same as other strong opioids."]
	},
	{
		id: "codeine",
		generic: "Codeine",
		brands: ["Tylenol with codeine"],
		aliases: [
			"opioid",
			"tylenol 3",
			"tylenol with codeine"
		],
		classes: ["opioid", "full_agonist"],
		bucket: "Pain",
		plain: "A weaker opioid that the body has to convert before it works. Some people convert a lot, some almost none. Combination tablets also contain acetaminophen.",
		usedFor: "Mild to moderate pain, and cough in some products",
		watch: ["Count the acetaminophen if the tablet is a combination.", "Children and teenagers are a special risk group. Do not share a leftover prescription."]
	},
	{
		id: "buprenorphine",
		generic: "Buprenorphine",
		brands: [
			"Subutex",
			"Belbuca",
			"Butrans"
		],
		aliases: [
			"subutex",
			"belbuca",
			"butrans",
			"bupe"
		],
		classes: ["opioid", "buprenorphine"],
		bucket: "Pain",
		plain: "A partial opioid. It treats pain and opioid dependence. It is not a milder version you can stack on oxycodone or methadone — it can knock those off the receptor.",
		usedFor: "Pain, or opioid use disorder",
		watch: ["Benzodiazepines and alcohol still slow breathing. Partial does not mean safe to mix.", "Films and patches are not interchangeable. Do not cut a patch unless the label says you can."]
	},
	{
		id: "buprenorphine-naloxone",
		generic: "Buprenorphine / naloxone",
		brands: ["Suboxone", "Zubsolv"],
		aliases: [
			"suboxone",
			"zubsolv",
			"bupe",
			"naloxone"
		],
		classes: ["opioid", "buprenorphine"],
		bucket: "Pain",
		plain: "Buprenorphine plus a dose of naloxone, usually a film. Swallowed or dissolved as prescribed, the naloxone does little. Injected, the naloxone can trigger withdrawal. The buprenorphine is still an opioid.",
		usedFor: "Opioid use disorder",
		watch: ["Do not place it on top of methadone, oxycodone, or fentanyl the same day unless a clinic is managing the switch.", "The naloxone in this product is not a substitute for Narcan kept for an overdose."]
	},
	{
		id: "naloxone",
		generic: "Naloxone",
		brands: ["Narcan", "Kloxxado"],
		aliases: [
			"narcan",
			"kloxxado",
			"naloxone spray"
		],
		classes: ["opioid_antagonist"],
		bucket: "Pain",
		plain: "The emergency spray or injection that reverses an opioid overdose. It is not a pain medicine, and it is not the naloxone inside a Suboxone film.",
		usedFor: "Opioid overdose",
		watch: ["Give it if breathing is slow or the person will not wake, then call for help. Withdrawal afterward is unpleasant and expected.", "It wears off. Stay with the person. A second dose is sometimes needed."]
	},
	{
		id: "naltrexone",
		generic: "Naltrexone",
		brands: ["Vivitrol", "Revia"],
		aliases: [
			"vivitrol",
			"revia",
			"opioid blocker"
		],
		classes: ["opioid_antagonist"],
		bucket: "Pain",
		plain: "A long-acting opioid blocker, as a daily pill or a monthly shot. It is not naloxone. It is taken to prevent opioid effect, not to reverse an overdose in the moment.",
		usedFor: "Opioid use disorder and alcohol use disorder",
		watch: ["Starting it while an opioid is still in the body causes precipitated withdrawal.", "Ordinary opioid pain medicines will not work while it is active. Tell every clinician you are on it before any procedure."]
	},
	{
		id: "semaglutide",
		generic: "Semaglutide",
		brands: [
			"Ozempic",
			"Wegovy",
			"Rybelsus"
		],
		aliases: [
			"ozempic",
			"wegovy",
			"rybelsus",
			"glp-1",
			"glp1"
		],
		classes: ["glp1"],
		bucket: "Peptides",
		plain: "A GLP-1 medicine that slows the stomach and lowers blood sugar and appetite. The pen and the tablet are the same drug family. It is an approved medicine, unlike most items in this section.",
		usedFor: "Type 2 diabetes and weight loss",
		watch: ["Nausea and a stomach that empties slowly are expected, especially after a dose increase.", "Severe belly pain that does not stop needs a same-day call — that is the pancreatitis warning, not ordinary nausea."]
	},
	{
		id: "tirzepatide",
		generic: "Tirzepatide",
		brands: ["Mounjaro", "Zepbound"],
		aliases: [
			"mounjaro",
			"zepbound",
			"glp-1",
			"glp1"
		],
		classes: ["glp1", "tirzepatide"],
		bucket: "Peptides",
		plain: "A weekly shot that acts on two gut hormones. Like semaglutide, it slows the stomach. The label also warns that it can make birth-control pills less reliable when you start or raise the dose.",
		usedFor: "Type 2 diabetes and weight loss",
		watch: ["Use a backup birth-control method for 4 weeks after you start and after each dose increase if you rely on the pill.", "Gallbladder pain and severe vomiting are reasons to call, not to ‘wait out’ the next injection."]
	},
	{
		id: "bpc-157",
		generic: "BPC-157",
		brands: [],
		aliases: [
			"bpc",
			"bpc157",
			"body protection compound"
		],
		classes: ["peptide", "peptide_bleed"],
		bucket: "Peptides",
		plain: "A research peptide sold for healing. It is not an FDA-approved drug, and almost all interaction evidence is from animals, not people. Vial strength is not standardized.",
		usedFor: "Research product people add to a medication list",
		watch: ["Tell a surgeon or dentist you are using it before a procedure.", "If you take a blood thinner, this is a conversation, not a silent add-on."]
	},
	{
		id: "tb-500",
		generic: "TB-500",
		brands: [],
		aliases: [
			"tb500",
			"thymosin beta-4",
			"thymosin"
		],
		classes: ["peptide", "peptide_bleed"],
		bucket: "Peptides",
		plain: "A fragment related to thymosin beta-4, sold as a research chemical for tissue repair. Human drug-interaction studies are basically absent. Treat bleeding risk as ‘not proven, not nothing.’",
		usedFor: "Research product people add to a medication list",
		watch: ["Not an approved medicine. Purity of research vials varies.", "Mention it before surgery or if you already bruise or bleed easily."]
	},
	{
		id: "melanotan",
		generic: "Melanotan II",
		brands: [],
		aliases: [
			"melanotan",
			"mt2",
			"mt-2",
			"tanning peptide"
		],
		classes: [
			"peptide",
			"melanotan",
			"melanocortin"
		],
		bucket: "Peptides",
		plain: "An unapproved tanning peptide. It can cause flushing, nausea, and blood-pressure swings, and new or changing moles are a reason to stop and get them looked at.",
		usedFor: "Research product people use for tanning",
		watch: ["Not the same as the approved implant afamelanotide, which is a medical product for a rare porphyria.", "Spontaneous erections and darkening of moles are known effects. A mole that changes needs a clinician, not another vial."]
	},
	{
		id: "sermorelin",
		generic: "Sermorelin",
		brands: [],
		aliases: [
			"growth hormone peptide",
			"ghrh",
			"sermorelin acetate"
		],
		classes: ["peptide", "ghs"],
		bucket: "Peptides",
		plain: "A peptide that tells the pituitary to release growth hormone. Steroid pills can blunt that signal. Growth hormone itself can push blood sugar up.",
		usedFor: "Sometimes prescribed; also sold as a research product",
		watch: ["Steroid pills can blunt the growth-hormone pulse. Blood sugar can drift up.", "Ipamorelin, CJC-1295, and tesamorelin are separate entries. Don’t type one and assume it stands for all of them."]
	},
	{
		id: "bremelanotide",
		generic: "Bremelanotide",
		brands: ["Vyleesi"],
		aliases: [
			"pt-141",
			"pt141",
			"vyleesi"
		],
		classes: [
			"peptide",
			"pt141",
			"melanocortin"
		],
		bucket: "Peptides",
		plain: "An approved shot for low sexual desire in premenopausal women. For a few hours it can raise blood pressure and slow the pulse. Unapproved ‘PT-141’ vials are not the same product as the pharmacy pen.",
		usedFor: "Hypoactive sexual desire disorder",
		watch: ["Skip it if blood pressure is uncontrolled or you have serious heart disease — that limit is on the label.", "Do not use it more than directed. Extra doses do not make it safer with blood-pressure pills or erection medicines."]
	},
	{
		id: "liraglutide",
		generic: "Liraglutide",
		brands: ["Victoza", "Saxenda"],
		aliases: [
			"victoza",
			"saxenda",
			"glp-1",
			"glp1"
		],
		classes: ["glp1"],
		bucket: "Peptides",
		plain: "A daily GLP-1 shot for diabetes or weight. It slows the stomach and lowers appetite, the same family as semaglutide.",
		usedFor: "Type 2 diabetes and weight loss",
		watch: ["Nausea is common while the dose climbs.", "Severe, steady belly pain is a reason to call the same day."]
	},
	{
		id: "dulaglutide",
		generic: "Dulaglutide",
		brands: ["Trulicity"],
		aliases: [
			"trulicity",
			"glp-1",
			"glp1"
		],
		classes: ["glp1"],
		bucket: "Peptides",
		plain: "A weekly GLP-1 shot. It lowers blood sugar and slows the stomach.",
		usedFor: "Type 2 diabetes",
		watch: ["Stomach upset usually eases after the first weeks.", "A thyroid mass or trouble swallowing needs a clinician, not another dose."]
	},
	{
		id: "exenatide",
		generic: "Exenatide",
		brands: ["Byetta", "Bydureon"],
		aliases: [
			"byetta",
			"bydureon",
			"glp-1",
			"glp1"
		],
		classes: ["glp1"],
		bucket: "Peptides",
		plain: "An older GLP-1 medicine, as a twice-daily shot or a weekly form. Kidney function matters more with this one than with some newer GLP-1s.",
		usedFor: "Type 2 diabetes",
		watch: ["Not for people with severe kidney disease.", "Nausea and a slower stomach are expected."]
	},
	{
		id: "ipamorelin",
		generic: "Ipamorelin",
		brands: [],
		aliases: [
			"ipamorelin acetate",
			"growth hormone peptide",
			"gh peptide"
		],
		classes: ["peptide", "ghs"],
		bucket: "Peptides",
		plain: "A research peptide that mimics ghrelin and asks the pituitary for a growth-hormone pulse. It is not an approved drug, and vial strength is not standardized.",
		usedFor: "Research product people use for recovery or body composition",
		watch: ["Water retention, tingling in the hands, and higher blood sugar are the practical effects.", "Steroid pills can blunt the pulse it is trying to create."]
	},
	{
		id: "cjc-1295",
		generic: "CJC-1295",
		brands: [],
		aliases: [
			"cjc",
			"cjc1295",
			"mod grf",
			"growth hormone peptide"
		],
		classes: ["peptide", "ghs"],
		bucket: "Peptides",
		plain: "A research growth-hormone-releasing peptide, often paired with ipamorelin. The ‘with DAC’ and ‘without DAC’ versions are not the same length of action.",
		usedFor: "Research product people stack with other growth-hormone peptides",
		watch: ["Flushing and a warm face right after a dose are commonly described.", "Stacking several growth-hormone peptides multiplies the sugar and swelling effects."]
	},
	{
		id: "tesamorelin",
		generic: "Tesamorelin",
		brands: ["Egrifta"],
		aliases: ["egrifta", "ghrh"],
		classes: ["peptide", "ghs"],
		bucket: "Peptides",
		plain: "An approved growth-hormone-releasing shot used for excess belly fat in people with HIV. Research vials sold under the same name are not the pharmacy product.",
		usedFor: "HIV-related abdominal fat; also sold as a research product",
		watch: ["It can worsen glucose control.", "Injection-site redness and joint aches are common."]
	},
	{
		id: "ghrp-2",
		generic: "GHRP-2",
		brands: [],
		aliases: ["ghrp2", "growth hormone releasing peptide"],
		classes: ["peptide", "ghs"],
		bucket: "Peptides",
		plain: "A research ghrelin-mimic peptide. It pushes growth hormone, and it also tends to raise hunger, prolactin, and cortisol more than ipamorelin.",
		usedFor: "Research product",
		watch: ["Hunger after a dose is expected.", "It is not a milder version of ipamorelin."]
	},
	{
		id: "ghrp-6",
		generic: "GHRP-6",
		brands: [],
		aliases: ["ghrp6"],
		classes: ["peptide", "ghs"],
		bucket: "Peptides",
		plain: "A research ghrelin-mimic known for a strong hunger surge. The growth-hormone effect comes with that appetite hit.",
		usedFor: "Research product",
		watch: ["A sudden appetite spike is the effect people notice first.", "Water retention and higher blood sugar can follow repeated use."]
	},
	{
		id: "hexarelin",
		generic: "Hexarelin",
		brands: [],
		aliases: ["examorelin"],
		classes: ["peptide", "ghs"],
		bucket: "Peptides",
		plain: "A strong research growth-hormone peptide. The pulse can fade if it is used continuously, and cortisol and prolactin rise more than with ipamorelin.",
		usedFor: "Research product",
		watch: ["Flushing, hunger, and water retention are common descriptions.", "Do not stack it with several other growth-hormone peptides and assume the effects stay small."]
	},
	{
		id: "igf-1",
		generic: "IGF-1",
		brands: ["Increlex"],
		aliases: [
			"igf1",
			"igf-1 lr3",
			"lr3",
			"increlex",
			"mecasermin"
		],
		classes: ["peptide", "igf"],
		bucket: "Peptides",
		plain: "Insulin-like growth factor. Increlex is an approved drug for a rare deficiency. ‘IGF-1 LR3’ vials sold online are not that product and can drop blood sugar.",
		usedFor: "Severe primary IGF-1 deficiency; research vials are a different product",
		watch: ["Low blood sugar is the danger, especially with insulin.", "Jaw pain, swelling, and joint aches show up with longer use."]
	},
	{
		id: "aod-9604",
		generic: "AOD-9604",
		brands: [],
		aliases: [
			"aod",
			"aod9604",
			"fat loss peptide"
		],
		classes: ["peptide", "lipolytic"],
		bucket: "Peptides",
		plain: "A fragment based on growth hormone, sold for fat loss. It is not an approved drug. Human evidence that it burns fat safely on top of other medicines is thin.",
		usedFor: "Research product people use for fat loss",
		watch: ["Injection-site irritation is the effect most often described.", "Do not treat it as a proven partner for a GLP-1 pen."]
	},
	{
		id: "frag-176",
		generic: "Fragment 176-191",
		brands: [],
		aliases: [
			"hgh frag",
			"frag 176",
			"fat loss peptide"
		],
		classes: ["peptide", "lipolytic"],
		bucket: "Peptides",
		plain: "A research fragment of growth hormone marketed for fat loss. It does not replace growth hormone, and it is not an approved medicine.",
		usedFor: "Research product",
		watch: ["Evidence in people is weak.", "Stacking it with a GLP-1 or with insulin is unstudied."]
	},
	{
		id: "thymosin-alpha-1",
		generic: "Thymosin alpha-1",
		brands: ["Zadaxin"],
		aliases: [
			"ta1",
			"thymalfasin",
			"zadaxin"
		],
		classes: ["peptide", "immune_peptide"],
		bucket: "Peptides",
		plain: "An immune-signaling peptide. It is approved in some countries, not as a general wellness shot in the U.S. It is meant to stimulate immunity, which matters if you take drugs that suppress it.",
		usedFor: "Some chronic infections and as an immune adjuvant where it is approved",
		watch: ["Injection-site redness and fatigue are the common complaints.", "Do not add it on top of a transplant or chemotherapy plan without that specialist."]
	},
	{
		id: "ghk-cu",
		generic: "GHK-Cu",
		brands: [],
		aliases: [
			"ghk",
			"copper peptide",
			"ghk copper"
		],
		classes: ["peptide", "copper_peptide"],
		bucket: "Peptides",
		plain: "A copper-binding peptide used in creams and, less often, as a research injection. Skin use and injection are not the same exposure.",
		usedFor: "Skin products; sometimes injected as a research product",
		watch: ["Creams irritate some skin. Injections are a different risk.", "Large zinc supplements compete with copper in the body."]
	},
	{
		id: "kpv",
		generic: "KPV",
		brands: [],
		aliases: ["lysine proline valine"],
		classes: ["peptide"],
		bucket: "Peptides",
		plain: "A short research peptide taken from a hormone fragment, sold for inflammation. Human drug-interaction studies are essentially absent.",
		usedFor: "Research product",
		watch: ["Purity and dose of research vials vary.", "Do not assume it is safe to add to a steroid or an immune drug."]
	},
	{
		id: "ll-37",
		generic: "LL-37",
		brands: [],
		aliases: ["cathelicidin"],
		classes: ["peptide", "immune_peptide"],
		bucket: "Peptides",
		plain: "An antimicrobial peptide the body already makes. Research vials are not an approved antibiotic and can irritate tissue.",
		usedFor: "Research product",
		watch: ["Injection-site reactions are common in descriptions.", "It is not a substitute for a prescribed antibiotic."]
	},
	{
		id: "setmelanotide",
		generic: "Setmelanotide",
		brands: ["Imcivree"],
		aliases: ["imcivree"],
		classes: ["peptide", "melanocortin"],
		bucket: "Peptides",
		plain: "An approved melanocortin shot for a few rare genetic causes of obesity. It darkens skin and can affect mood. It is not a tanning peptide.",
		usedFor: "Specific rare genetic obesity syndromes",
		watch: ["New or worsening depression and darkening of the skin are labeled effects.", "Spontaneous erections can occur."]
	},
	{
		id: "afamelanotide",
		generic: "Afamelanotide",
		brands: ["Scenesse"],
		aliases: ["scenesse"],
		classes: ["peptide", "melanocortin"],
		bucket: "Peptides",
		plain: "An approved implant for a rare porphyria that causes severe light pain. It is not Melanotan, and it is not a cosmetic tanning product.",
		usedFor: "Erythropoietic protoporphyria",
		watch: ["Nausea, headache, and darkening of moles are labeled effects.", "A mole that changes still needs a skin check."]
	},
	{
		id: "pramlintide",
		generic: "Pramlintide",
		brands: ["Symlin"],
		aliases: ["symlin", "amylin"],
		classes: ["peptide", "amylin"],
		bucket: "Peptides",
		plain: "An approved mealtime shot that slows the stomach, used with insulin. It is easy to drop blood sugar too far if the insulin dose is not reduced.",
		usedFor: "Type 1 and type 2 diabetes, alongside insulin",
		watch: ["Severe lows are the labeled danger, especially in type 1.", "Do not mix it in the same syringe as insulin."]
	},
	{
		id: "glucagon",
		generic: "Glucagon",
		brands: ["Baqsimi", "Gvoke"],
		aliases: [
			"baqsimi",
			"gvoke",
			"glucagen"
		],
		classes: ["peptide", "glucagon"],
		bucket: "Peptides",
		plain: "The rescue medicine for a severe low. A kit at home next to insulin is normal. It is not a daily partner you use to cancel a meal.",
		usedFor: "Severe hypoglycemia",
		watch: ["Nausea and vomiting after a rescue dose are common.", "After you use it, emergency care still matters. The low can return."]
	},
	{
		id: "desmopressin",
		generic: "Desmopressin",
		brands: ["DDAVP", "Nocdurna"],
		aliases: ["ddavp", "nocdurna"],
		classes: ["peptide", "desmopressin"],
		bucket: "Peptides",
		plain: "A hormone-like peptide that tells the kidneys to hold water. Too much water holding drops the blood sodium.",
		usedFor: "Diabetes insipidus, bedwetting, and some bleeding disorders",
		watch: ["Headache, confusion, or a seizure can be low sodium, not ‘just a headache.’", "Drinking a large amount of fluid on a dose night is part of how sodium crashes."]
	},
	{
		id: "octreotide",
		generic: "Octreotide",
		brands: ["Sandostatin"],
		aliases: ["sandostatin"],
		classes: ["peptide", "somatostatin"],
		bucket: "Peptides",
		plain: "A peptide that turns down several gut and pituitary hormones. Blood sugar can swing either way, and the gallbladder is a known trouble spot.",
		usedFor: "Acromegaly, carcinoid symptoms, and some severe diarrheas",
		watch: ["Gallstones and belly pain are labeled risks.", "It can change how diabetes medicines behave."]
	},
	{
		id: "teriparatide",
		generic: "Teriparatide",
		brands: ["Forteo"],
		aliases: ["forteo"],
		classes: ["peptide", "pth_analog"],
		bucket: "Peptides",
		plain: "A daily bone-building shot related to parathyroid hormone. Calcium in the blood can rise, which matters for the heart rhythm if you take digoxin.",
		usedFor: "Severe osteoporosis",
		watch: ["Use is limited to a defined course, not a forever shot.", "Leg cramps, dizziness after the injection, and high calcium are the effects to know."]
	},
	{
		id: "leuprolide",
		generic: "Leuprolide",
		brands: ["Lupron"],
		aliases: ["lupron", "gnrh"],
		classes: [
			"peptide",
			"gnrh",
			"qt_risk"
		],
		bucket: "Peptides",
		plain: "A hormone shot that first stirs, then shuts down, sex-hormone signals. It is used for prostate cancer, endometriosis, and some early puberty.",
		usedFor: "Prostate cancer, endometriosis, fibroids, and central precocious puberty",
		watch: ["Hot flashes, mood change, and bone loss over time are expected.", "The heart-rhythm warning matters if you already take a QT-prolonging medicine."]
	},
	{
		id: "oxytocin",
		generic: "Oxytocin",
		brands: ["Pitocin"],
		aliases: ["pitocin"],
		classes: ["peptide", "oxytocin"],
		bucket: "Peptides",
		plain: "The hospital hormone used to start or strengthen labor and to control bleeding after birth. Nasal or research products are not the same as a monitored Pitocin drip.",
		usedFor: "Labor induction and postpartum bleeding",
		watch: ["Too much can cause contractions that are too strong.", "Water retention can drop sodium if fluids are not watched."]
	},
	{
		id: "calcitonin",
		generic: "Calcitonin",
		brands: ["Miacalcin"],
		aliases: ["miacalcin", "salmon calcitonin"],
		classes: ["peptide", "calcitonin"],
		bucket: "Peptides",
		plain: "A peptide that lowers blood calcium, used as a nasal spray or injection for certain bone and calcium problems.",
		usedFor: "Osteoporosis and some high-calcium states",
		watch: ["Nasal irritation with the spray, and nausea with the injection, are common.", "A facial flush right after an injection can happen."]
	},
	{
		id: "linaclotide",
		generic: "Linaclotide",
		brands: ["Linzess"],
		aliases: ["linzess"],
		classes: ["peptide", "gcc_agonist"],
		bucket: "Peptides",
		plain: "An approved gut peptide for constipation and IBS-C. Diarrhea is the effect, not a surprise.",
		usedFor: "Chronic constipation and IBS with constipation",
		watch: ["Severe diarrhea and dizziness need a call.", "Not for children. The label warns of serious dehydration in the very young."]
	},
	{
		id: "kisspeptin",
		generic: "Kisspeptin",
		brands: [],
		aliases: ["kisspeptin-10", "kp-10"],
		classes: ["peptide", "kisspeptin"],
		bucket: "Peptides",
		plain: "A reproductive-hormone peptide studied for fertility. Research vials are not an approved fertility drug.",
		usedFor: "Research product; clinical studies in fertility",
		watch: ["It pushes the same hormone axis that Lupron-type medicines shut down.", "Human interaction data outside studies is thin."]
	},
	{
		id: "selank",
		generic: "Selank",
		brands: [],
		aliases: ["selank peptide"],
		classes: ["peptide", "nootropic_peptide"],
		bucket: "Peptides",
		plain: "A research peptide marketed for anxiety. It is not an approved substitute for a prescribed anxiety medicine, and combination studies are scarce.",
		usedFor: "Research product",
		watch: ["Fatigue and nasal irritation are the effects people describe.", "Do not stop a prescribed antidepressant or benzodiazepine because a vial ‘feels calming.’"]
	},
	{
		id: "semax",
		generic: "Semax",
		brands: [],
		aliases: ["semax peptide"],
		classes: ["peptide", "nootropic_peptide"],
		bucket: "Peptides",
		plain: "A research peptide marketed for focus. Evidence for mixing it with antidepressants or stimulants is weak, so the honest answer is ‘unstudied,’ not ‘safe.’",
		usedFor: "Research product",
		watch: ["Headache and irritability are described.", "It is not a proven add-on to an SSRI."]
	},
	{
		id: "epitalon",
		generic: "Epitalon",
		brands: [],
		aliases: ["epithalon", "epithalamin"],
		classes: ["peptide"],
		bucket: "Peptides",
		plain: "A research peptide sold for sleep and aging. Human trials are small. There is no solid interaction map with prescription drugs.",
		usedFor: "Research product",
		watch: ["Lack of a known interaction is not proof it is safe to stack.", "Vial contents may not match the label."]
	},
	{
		id: "mots-c",
		generic: "MOTS-c",
		brands: [],
		aliases: ["motsc", "mots c"],
		classes: ["peptide", "metabolic_peptide"],
		bucket: "Peptides",
		plain: "A mitochondrial peptide studied for metabolism. It is not an approved diabetes or weight drug, and stacking it with insulin or a GLP-1 is unstudied.",
		usedFor: "Research product",
		watch: ["Injection-site irritation is the common complaint.", "Treat blood-sugar changes as real until a clinician says otherwise."]
	}
];
var DRUG_BY_ID = new Map(DRUGS.map((drug) => [drug.id, drug]));
function drugsFromIds(ids) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const id of ids) {
		if (seen.has(id)) continue;
		const drug = DRUG_BY_ID.get(id);
		if (!drug) continue;
		seen.add(id);
		out.push(drug);
	}
	return out;
}
/** When the key rule has already fired, hide these noisier overlaps. */
var SUPPRESS_WHEN = {
	"triple-whammy": ["nsaid-pressure"],
	"k-stack": ["ace-spiro"],
	"alcohol-downer": ["opioid-downer"],
	"maoi-serotonin": [
		"ssri-serotonin-major",
		"ssri-serotonin-mod",
		"ssri-trazodone",
		"ssri-dup"
	],
	"sedating-downer": ["sedating-dup"],
	"kratom-maoi": ["kratom-serotonin"],
	"bupe-full": ["opioid-dup"]
};
var RULES = [
	{
		id: "nitrate-pde5",
		groups: [{ classes: ["nitrate"] }, { classes: ["pde5"] }],
		severity: "major",
		title: "Blood pressure can crash",
		plain: "{meds} together can drop blood pressure hard enough to cause fainting or shock. That includes a daily nitrate pill, not only the emergency chest spray.",
		why: "Both open blood vessels. Stacked, the effect is much stronger than either one alone.",
		whatToDo: "Do not combine them. After sildenafil the unsafe window is about 24 hours; after tadalafil it is about 48 hours. If chest pain happens in that window, emergency staff need to know what you took and when — some usual chest-pain treatments are unsafe then.",
		notice: "Sudden dizziness, fading vision, fainting, or a feeling that you might pass out when you stand.",
		howSure: "This is a hard stop on the labels, not a maybe."
	},
	{
		id: "alcohol-downer",
		groups: [{ classes: ["alcohol"] }, { classes: [
			"opioid",
			"benzo",
			"zd"
		] }],
		severity: "major",
		title: "Breathing can slow or stop",
		plain: "{meds} all slow the brain. Together — even without feeling very drunk — they can make breathing dangerously slow, especially during sleep.",
		why: "Alcohol, opioids, benzodiazepines, and sleep medicines like zolpidem depress the drive to breathe. The combination is more than additive.",
		whatToDo: "Don’t drink on top of these. If a clinician prescribed an opioid and a benzodiazepine together, don’t change them on your own tonight, but make sure they know about both, and don’t add extra doses. Emergency care if someone is hard to wake, breathing is slow, or lips look blue.",
		notice: "Hard to wake. Breathing that looks slow, shallow, or noisy. Blue or gray lips. A new loud snore.",
		howSure: "This is a well-known cause of overdose deaths. The warning is on the labels."
	},
	{
		id: "opioid-downer",
		groups: [{ classes: ["opioid"] }, { classes: ["benzo", "zd"] }],
		severity: "major",
		title: "A boxed warning for slowed breathing",
		plain: "{meds} are a known cause of fatal sedation. The opioid and the anxiety or sleep medicine reinforce each other.",
		why: "Both dampen the brainstem signals that keep breathing going. The FDA requires a boxed warning on this pairing.",
		whatToDo: "If both were prescribed, the prescribers should each know the full list. Don’t add alcohol. Don’t raise either dose to chase relief. Emergency care for slow breathing, blue lips, or someone who won’t wake.",
		notice: "Extreme sleepiness, slow breathing, blue lips, or a person who will not wake up.",
		howSure: "The FDA requires a boxed warning on opioid plus benzodiazepine or sleep-medicine pairings."
	},
	{
		id: "opioid-gaba",
		groups: [{ classes: ["opioid"] }, { classes: ["gabapentinoid"] }],
		severity: "major",
		title: "Extra sedation and slow breathing",
		plain: "{meds} together raise the chance of profound sleepiness and slowed breathing. This pairing has its own FDA warning.",
		why: "Gabapentin and pregabalin add to opioid sedation, especially in older adults or with lung disease.",
		whatToDo: "Don’t start or raise either one without the prescriber seeing the full list. Avoid alcohol. Get help urgently if breathing slows or the person can’t be woken."
	},
	{
		id: "opioid-dup",
		groups: [{ classes: ["opioid"] }, { classes: ["opioid"] }],
		severity: "major",
		title: "Two opioid pain medicines",
		plain: "{meds} are both opioids. Taking two stacks sedation, constipation, and the risk of slowed breathing.",
		why: "They act on the same receptors. A second opioid is not a safer add-on.",
		whatToDo: "This is rarely something to piece together yourself. Ask which one you should actually be on. Remember combination products like Percocet or Norco already contain an opioid."
	},
	{
		id: "sedative-dup",
		groups: [{ classes: ["benzo", "zd"] }, { classes: ["benzo", "zd"] }],
		severity: "moderate",
		title: "Two medicines that slow the brain",
		plain: "{meds} both sedate. Together, falls, confusion, and next-day impairment are more likely.",
		why: "Benzodiazepines and Z-drugs like zolpidem overlap in how they quiet the nervous system.",
		whatToDo: "Ask whether both are still needed. Don’t add alcohol. Don’t stop a regular benzodiazepine abruptly."
	},
	{
		id: "sedating-downer",
		groups: [{ classes: ["sedating"] }, { classes: [
			"opioid",
			"benzo",
			"zd"
		] }],
		severity: "moderate",
		title: "Drowsiness stacks",
		plain: "{meds} can make you much sleepier than either alone. Nighttime antihistamines and trazodone count, not only prescription sleep pills.",
		why: "Sedating antihistamines and trazodone add antihistamine or serotonin sedation on top of a drug that already slows the brain.",
		whatToDo: "Avoid driving until you know how the mix feels. Older adults are especially fall-prone. If an opioid is involved and breathing seems slow, treat that as urgent."
	},
	{
		id: "sedating-dup",
		groups: [{ classes: ["sedating"] }, { classes: ["sedating"] }],
		severity: "moderate",
		title: "Two sedating medicines",
		plain: "{meds} both make people drowsy. The hangover is easy to underestimate because each one felt mild alone.",
		why: "Their sedating effects add up, along with dry mouth, constipation, and confusion in older adults.",
		whatToDo: "You usually don’t need both. Ask which one to keep, especially if either is only for sleep."
	},
	{
		id: "dual-anticoag",
		groups: [{ classes: ["anticoagulant"] }, { classes: ["anticoagulant"] }],
		severity: "major",
		title: "Two blood thinners",
		plain: "{meds} are both anticoagulants. Outside a short, supervised hospital plan, doubling them is a serious bleeding risk.",
		why: "They block clotting by related paths. The bleed risk is not a small step up.",
		whatToDo: "Don’t take both unless a hospital team set a brief overlap on purpose. If you were switched from one to the other, confirm the old one was stopped."
	},
	{
		id: "anticoag-nsaid",
		groups: [{ classes: ["anticoagulant"] }, { classes: ["nsaid"] }],
		severity: "major",
		title: "Bleeding risk jumps",
		plain: "{meds} are a classic bad casual mix. The blood thinner stops clots; the pain pill irritates the stomach and makes platelets less sticky.",
		why: "NSAIDs (ibuprofen, naproxen, celecoxib) add gastrointestinal injury on top of impaired clotting.",
		whatToDo: "Ask before using this pain pill, even for a few days. Acetaminophen is often considered instead, but it has its own ceiling — and with warfarin, several days of higher doses can still move the INR. Urgent care for black stools, vomiting blood, or a sudden severe headache."
	},
	{
		id: "anticoag-antiplatelet",
		groups: [{ classes: ["anticoagulant"] }, { classes: ["antiplatelet"] }],
		severity: "major",
		title: "Two ways of slowing clots",
		plain: "{meds} slow clotting by different routes. Bleeding is meaningfully more likely. Sometimes a heart doctor wants exactly this pair after a stent or a valve — and sometimes it was never the plan.",
		why: "Anticoagulants and antiplatelet drugs (aspirin, clopidogrel) interrupt different steps. Together, plugs form less well.",
		whatToDo: "Don’t add aspirin or stop a prescribed pair on your own. Confirm with the prescriber that both are still intended. Extra NSAID pain pills on top are a separate, bigger problem."
	},
	{
		id: "dual-antiplatelet",
		groups: [{ classes: ["antiplatelet"] }, { classes: ["antiplatelet"] }],
		severity: "moderate",
		title: "Two antiplatelet medicines",
		plain: "{meds} both keep platelets from clumping. After a stent this pair is often deliberate for a set number of months. It is also easy to recreate by accident with over-the-counter aspirin.",
		why: "Dual antiplatelet therapy prevents stent clots, at the cost of easier bruising and bleeding.",
		whatToDo: "If a cardiologist prescribed both, don’t stop either for a procedure or a nosebleed without calling them. If aspirin was your own addition, ask before keeping it."
	},
	{
		id: "ssri-bleed",
		groups: [{ classes: ["ssri", "snri"] }, { classes: [
			"nsaid",
			"antiplatelet",
			"anticoagulant"
		] }],
		severity: "major",
		title: "Bleeding is more likely",
		plain: "{meds} raise bleeding risk, especially in the stomach. Antidepressants in the SSRI and SNRI families make platelets a little less effective, and the other medicine already affects clotting or the stomach lining.",
		why: "Platelets need serotonin to do their job. SSRIs and SNRIs lower platelet serotonin. NSAIDs, aspirin, clopidogrel, and anticoagulants each add their own hit.",
		whatToDo: "Low-dose aspirin plus an antidepressant is sometimes intentional. Don’t add ibuprofen or naproxen on top without asking. Urgent help for black stools, vomiting blood, or a sudden severe headache."
	},
	{
		id: "ssri-serotonin-major",
		groups: [{ classes: ["ssri", "snri"] }, { classes: ["opioid_serotonergic", "stjohns"] }],
		severity: "major",
		title: "Serotonin can build up",
		plain: "{meds} both push serotonin. With tramadol that also means a higher seizure risk. With St John’s wort it is not a gentle herbal add-on — it is a second antidepressant.",
		why: "Too much serotonin causes serotonin syndrome: agitation, sweating, tremor, diarrhea, and confusion. Tramadol lowers the seizure threshold as well.",
		whatToDo: "Don’t combine these on your own. If you already feel unusually agitated, shaky, feverish, or confused, get urgent care and bring the list. A prescriber who wants both should be the one managing it."
	},
	{
		id: "ssri-serotonin-mod",
		groups: [{ classes: ["ssri", "snri"] }, { classes: ["dxm", "triptan"] }],
		severity: "moderate",
		title: "A smaller serotonin overlap",
		plain: "{meds} both touch serotonin. Serious reactions are uncommon, especially with a normal dose of a migraine triptan, but cough syrup is easy to overdo.",
		why: "Triptans and dextromethorphan (the DM in cough medicine) have serotonergic activity on top of an antidepressant.",
		whatToDo: "Use the labeled dose, not extra. Skip ‘DM’ cough syrup if you can use something else, or ask a pharmacist. Get help for agitation, heavy sweating, tremor, or confusion."
	},
	{
		id: "ssri-trazodone",
		groups: [{ classes: ["ssri", "snri"] }, { ids: ["trazodone"] }],
		severity: "minor",
		title: "Often prescribed together for sleep",
		plain: "{meds} both raise serotonin a little. Clinicians commonly pair a daytime antidepressant with low-dose trazodone at night. Serious reactions are uncommon at usual sleep doses.",
		why: "Trazodone is mildly serotonergic. The overlap is real but usually tolerated.",
		whatToDo: "This one is a mention, not an alarm. Still report agitation, tremor, heavy sweating, or confusion. Don’t raise both doses at once without asking."
	},
	{
		id: "ssri-dup",
		groups: [{ classes: ["ssri", "snri"] }, { classes: ["ssri", "snri"] }],
		severity: "moderate",
		title: "Two antidepressants from the same shelf",
		plain: "{meds} overlap. Two SSRIs, or an SSRI plus an SNRI, raise serotonin and side effects without a clear everyday reason.",
		why: "They work through the same pathway. Duplicate therapy is usually a leftover from a switch that wasn’t finished.",
		whatToDo: "Ask which one is current. If you are mid-switch, confirm the taper rather than taking full doses of both."
	},
	{
		id: "maoi-serotonin",
		groups: [{ classes: ["maoi"] }, {
			classes: [
				"ssri",
				"snri",
				"opioid_serotonergic",
				"dxm",
				"triptan",
				"stjohns"
			],
			ids: ["trazodone"]
		}],
		severity: "major",
		title: "A dangerous serotonin mix",
		plain: "{meds} are not a safe combination. MAOIs plus other serotonergic medicines can cause serotonin syndrome, which can be severe.",
		why: "An MAOI stops serotonin from being broken down. Adding a drug that raises serotonin can overwhelm the system.",
		whatToDo: "Do not combine them or start one right after the other. Washout timing is a specialist decision — fluoxetine in particular lingers for weeks. Urgent care for high fever, confusion, rigid muscles, or dramatic swings in blood pressure."
	},
	{
		id: "maoi-decongestant",
		groups: [{ classes: ["maoi"] }, { classes: ["decongestant"] }],
		severity: "major",
		title: "Blood pressure can spike",
		plain: "{meds} can cause a sudden, severe rise in blood pressure. A stuffy-nose pill is not minor on an MAOI.",
		why: "MAOIs change how the body handles the stimulant effect of pseudoephedrine. The result can be a hypertensive crisis.",
		whatToDo: "Don’t take pseudoephedrine or similar decongestants. Ask a pharmacist for a non-decongestant option. Emergency care for a severe headache, chest pain, or a pounding heart after a cold pill."
	},
	{
		id: "bupropion-tramadol",
		groups: [{ ids: ["bupropion"] }, { ids: ["tramadol"] }],
		severity: "moderate",
		title: "Seizure risk goes up",
		plain: "{meds} each lower the seizure threshold. Together the risk is higher than with either one, especially above usual doses.",
		why: "Bupropion and tramadol both make seizures more likely. The problem is seizures more than serotonin.",
		whatToDo: "Don’t combine them unless a prescriber chose that knowingly. Skip extra doses. Alcohol binges push the same risk."
	},
	{
		id: "vka-boosters",
		groups: [{ ids: ["warfarin"] }, { ids: [
			"metronidazole",
			"smx-tmp",
			"ciprofloxacin",
			"levofloxacin",
			"clarithromycin",
			"amiodarone"
		] }],
		severity: "major",
		title: "Warfarin can become too strong",
		plain: "{meds} can push the INR up — that is the blood test that measures warfarin — and bleeding follows. The antibiotic or heart medicine is often the new piece.",
		why: "These drugs slow warfarin’s clearance or, with some antibiotics, also disturb vitamin K–producing gut bacteria.",
		whatToDo: "The prescriber who manages warfarin needs to know before or as soon as the other drug starts. Dose changes and extra INR checks are common. Don’t adjust warfarin yourself. Watch for unusual bleeding."
	},
	{
		id: "vka-azithro",
		groups: [{ ids: ["warfarin"] }, { ids: ["azithromycin"] }],
		severity: "moderate",
		title: "The INR can drift",
		plain: "{meds} sometimes raise warfarin’s effect. It is less predictable than with clarithromycin or Bactrim, but it is not zero.",
		why: "Azithromycin is a milder enzyme interaction than clarithromycin, yet INR bumps are still reported.",
		whatToDo: "Tell the warfarin clinic you started a Z-Pak. Ask whether an extra INR check is wanted."
	},
	{
		id: "vka-doxy",
		groups: [{ ids: ["warfarin"] }, { classes: ["tetracycline"] }],
		severity: "moderate",
		title: "Warfarin may run a bit strong",
		plain: "{meds} can nudge the INR upward. Not everyone is affected, which is why a lab check beats guessing.",
		why: "Some antibiotics, doxycycline included, are associated with higher INR readings.",
		whatToDo: "Let the anticoagulation clinic know. Don’t change the warfarin dose on your own."
	},
	{
		id: "vka-steroid",
		groups: [{ ids: ["warfarin"] }, { classes: ["corticosteroid"] }],
		severity: "moderate",
		title: "Steroid pills can move the INR",
		plain: "{meds} don’t have one simple direction. The INR can rise or fall when prednisone starts or stops.",
		why: "Corticosteroids change warfarin response in both directions in different people.",
		whatToDo: "If prednisone is more than a day or two, ask for an INR plan. Mention when the steroid stops, too — that swing matters."
	},
	{
		id: "vka-apap",
		groups: [{ ids: ["warfarin"] }, { ids: ["acetaminophen"] }],
		severity: "moderate",
		title: "Several days of acetaminophen can raise the INR",
		plain: "{meds} are often paired on purpose because acetaminophen doesn’t irritate the stomach the way ibuprofen does. A catch: higher doses for several days can still strengthen warfarin.",
		why: "Regular acetaminophen, especially above occasional low doses, is associated with INR increases.",
		whatToDo: "Occasional labeled doses are the usual advice, not standing high doses. If you need it most days, tell the warfarin clinic. Count hidden acetaminophen in cold and opioid combos."
	},
	{
		id: "vka-inducer",
		groups: [{ ids: ["warfarin"] }, { classes: ["inducer"] }],
		severity: "major",
		title: "Warfarin can become too weak",
		plain: "{meds} can make warfarin wear off faster, so clots become more likely. If the other product is later stopped, warfarin can suddenly become too strong.",
		why: "These drugs induce liver enzymes that clear warfarin. St John’s wort, carbamazepine, and rifampin are the ones in this list.",
		whatToDo: "Don’t start or stop these without the anticoagulation clinic. INR checks and dose changes go in both directions. This is the opposite problem from antibiotics that make warfarin too strong."
	},
	{
		id: "statin-clarithro-high",
		groups: [{ classes: ["macrolide_strong"] }, { classes: ["statin_3a4_high"] }],
		severity: "major",
		title: "Muscle breakdown risk",
		plain: "{meds} are a poor combination. Simvastatin and lovastatin levels can soar with clarithromycin, and muscles can break down.",
		why: "Clarithromycin blocks CYP3A4, the enzyme that clears these particular statins. Muscle injury can release a protein that harms the kidneys.",
		whatToDo: "Do not keep taking simvastatin or lovastatin during clarithromycin unless a prescriber gave a specific hold-or-switch plan. Azithromycin is often chosen instead precisely to avoid this. Dark urine, severe weakness, or muscle pain needs urgent care."
	},
	{
		id: "statin-clarithro-mod",
		groups: [{ classes: ["macrolide_strong"] }, { classes: ["statin_3a4_mod"] }],
		severity: "moderate",
		title: "The statin level can rise",
		plain: "{meds} — clarithromycin can raise atorvastatin. The risk is real but more manageable than with simvastatin.",
		why: "Atorvastatin also uses CYP3A4, just not as exclusively, so the jump is smaller than with simvastatin or lovastatin.",
		whatToDo: "Ask whether to pause atorvastatin for the antibiotic course. Don’t add grapefruit on top. Report severe muscle pain."
	},
	{
		id: "statin-nondhp-high",
		groups: [{ classes: ["ccb_nondhp"] }, { classes: ["statin_3a4_high"] }],
		severity: "major",
		title: "The statin dose has a hard ceiling",
		plain: "{meds} together mean simvastatin or lovastatin must stay at a low dose, or be switched. Higher doses have caused serious muscle injury.",
		why: "Diltiazem and verapamil block CYP3A4 enough to matter for these statins. Labels set maximum statin doses for the pair.",
		whatToDo: "Don’t raise the statin on your own. Ask if the current dose is within the allowed cap, or whether rosuvastatin or pravastatin would be simpler."
	},
	{
		id: "statin-nondhp-mod",
		groups: [{ classes: ["ccb_nondhp"] }, { classes: ["statin_3a4_mod"] }],
		severity: "moderate",
		title: "Atorvastatin may run higher",
		plain: "{meds} can raise atorvastatin levels. Many people still take a pair like this, at a moderated dose.",
		why: "Verapamil and diltiazem partially block the enzyme that clears atorvastatin.",
		whatToDo: "Make sure one clinician sees both. Report new muscle pain rather than pushing through it."
	},
	{
		id: "statin-amio-high",
		groups: [{ ids: ["amiodarone"] }, { classes: ["statin_3a4_high"] }],
		severity: "major",
		title: "Amiodarone limits the statin dose",
		plain: "{meds} require a low simvastatin or lovastatin dose. Amiodarone sticks around for months, so the interaction does too.",
		why: "Amiodarone inhibits the enzyme that clears these statins. The combination has caused muscle breakdown.",
		whatToDo: "Confirm the statin dose is within the cap, or ask about a switch to a statin that cares less (pravastatin or rosuvastatin). Muscle pain or dark urine needs a call."
	},
	{
		id: "statin-amlodipine",
		groups: [{ ids: ["amlodipine"] }, { classes: ["statin_3a4_high"] }],
		severity: "moderate",
		title: "Simvastatin has a dose cap here",
		plain: "{meds} are commonly prescribed together, but simvastatin usually should not go above 20 mg when amlodipine is on board.",
		why: "Amlodipine raises simvastatin levels modestly. The label answers with a dose limit, not a ban.",
		whatToDo: "Check the simvastatin strength. Don’t increase it without asking. Lovastatin has a similar caution."
	},
	{
		id: "grapefruit-statin-high",
		groups: [{ classes: ["grapefruit"] }, { classes: ["statin_3a4_high"] }],
		severity: "major",
		title: "Grapefruit and this statin don’t mix",
		plain: "{meds} — grapefruit can markedly raise simvastatin or lovastatin and has been tied to muscle injury.",
		why: "Grapefruit blocks CYP3A4 in the gut. These two statins depend on that enzyme. The block can last into the next day.",
		whatToDo: "Avoid grapefruit and grapefruit juice on these statins. Ordinary oranges are fine. Pravastatin and rosuvastatin are the ones less affected — a switch is a clinician decision, not a DIY one."
	},
	{
		id: "grapefruit-statin-mod",
		groups: [{ classes: ["grapefruit"] }, { classes: ["statin_3a4_mod"] }],
		severity: "moderate",
		title: "Large amounts of grapefruit matter",
		plain: "{meds} — a lot of grapefruit can raise atorvastatin. A rare small glass is a different scale than daily big glasses.",
		why: "Atorvastatin is partly cleared by the enzyme grapefruit blocks, so the rise is moderate rather than extreme.",
		whatToDo: "Avoid daily grapefruit juice. Mention your actual habit at the next visit rather than guessing a safe volume."
	},
	{
		id: "statin-inducer",
		groups: [{ classes: ["inducer"] }, { classes: ["statin_3a4_high", "statin_3a4_mod"] }],
		severity: "moderate",
		title: "The cholesterol medicine may not work as well",
		plain: "{meds} — the inducer speeds clearance of simvastatin, lovastatin, or atorvastatin, so the cholesterol effect can shrink.",
		why: "Carbamazepine, rifampin, and St John’s wort induce CYP3A4. Less statin stays in the blood.",
		whatToDo: "Don’t be reassured by a ‘natural’ product if your LDL was finally controlled. Ask whether the statin should change. Stopping the inducer later can suddenly raise the statin level."
	},
	{
		id: "statin-dup",
		groups: [{ classes: ["statin"] }, { classes: ["statin"] }],
		severity: "moderate",
		title: "Two statins",
		plain: "{meds} are the same kind of cholesterol medicine. You should not need both. Side effects add, benefit doesn’t double.",
		why: "Duplicate statin therapy increases muscle toxicity without a standard indication.",
		whatToDo: "Confirm which bottle is current. Combination pills sometimes hide a statin you also take separately."
	},
	{
		id: "triple-whammy",
		groups: [
			{ classes: ["acei", "arb"] },
			{ classes: ["thiazide", "loop"] },
			{ classes: ["nsaid"] }
		],
		severity: "major",
		title: "A trio that can injure the kidneys",
		plain: "{meds} are the ‘triple whammy’: a blood-pressure medicine that protects the kidney’s pressure system, a water pill, and an NSAID pain pill. Together they can cause sudden kidney injury, especially in older adults or when you’re dry.",
		why: "ACE inhibitors and ARBs change kidney blood flow, diuretics shrink volume, and NSAIDs block the prostaglandins kidneys use when stressed. All three at once remove the backup plan.",
		whatToDo: "Don’t add the pain pill on your own. If you are already on all three, ask whether that is still intended and whether kidney labs are being watched. Drink normally unless you were told to limit fluids, and pause to ask during a stomach bug."
	},
	{
		id: "nsaid-pressure",
		groups: [{ classes: ["nsaid"] }, { classes: [
			"acei",
			"arb",
			"thiazide",
			"loop"
		] }],
		severity: "moderate",
		title: "The pain pill can fight the blood-pressure pill",
		plain: "{meds} — NSAIDs can raise blood pressure, make water pills less effective, and strain kidneys. The risk is highest if you are also dehydrated.",
		why: "Prostaglandins help the kidney and support the effect of these blood-pressure medicines. NSAIDs block them.",
		whatToDo: "A short course may be fine for some people and a bad idea for others. Ask, especially if you already have kidney disease. Adding a water pill later turns this into a more serious trio."
	},
	{
		id: "nsaid-dup",
		groups: [{ classes: ["nsaid"] }, { classes: ["nsaid"] }],
		severity: "moderate",
		title: "Two anti-inflammatory pain pills",
		plain: "{meds} are both NSAIDs. Taking two does not add clean relief. It does add stomach, kidney, and blood-pressure risk.",
		why: "They share a mechanism. The ceiling for pain relief arrives before the ceiling for harm.",
		whatToDo: "Pick one. If pain is not controlled, that is a reason to reassess, not to add Aleve on top of Advil."
	},
	{
		id: "aspirin-nsaid",
		groups: [{ ids: ["aspirin"] }, { classes: ["nsaid"] }],
		severity: "moderate",
		title: "Pain pills can crowd low-dose aspirin",
		plain: "{meds} together raise the chance of a stomach bleed. If ibuprofen is one of them, it can also block the clot-prevention job of low-dose aspirin when the doses are close together.",
		why: "NSAIDs injure the stomach lining and affect platelets. Ibuprofen can occupy the same platelet spot aspirin needs in order to work for the heart.",
		whatToDo: "Ask before using this combination. If a clinician wants both, they often have you take aspirin first and wait, or they pick a different pain medicine. Acetaminophen does not block aspirin’s heart effect the way ibuprofen can."
	},
	{
		id: "prednisone-nsaid",
		groups: [{ classes: ["corticosteroid"] }, { classes: ["nsaid"] }],
		severity: "major",
		title: "A setup for stomach ulcers",
		plain: "{meds} together are much harder on the stomach than either alone. Ulcers and bleeding are the concern.",
		why: "Steroids and NSAIDs each impair the stomach’s defenses. The combination multiplies ulcer risk.",
		whatToDo: "Don’t add ibuprofen or naproxen to a prednisone course without asking. If both are required, a clinician may add a stomach-protection medicine. Black stools or vomiting blood is urgent."
	},
	{
		id: "lithium-nsaid",
		groups: [{ classes: ["lithium"] }, { classes: ["nsaid"] }],
		severity: "major",
		title: "Lithium can rise to a toxic level",
		plain: "{meds} — NSAIDs can make the kidneys hold onto lithium. Toxicity looks like tremor, confusion, slurred speech, and heavy diarrhea.",
		why: "NSAIDs reduce lithium clearance. The level can climb over days, not months.",
		whatToDo: "Don’t start a standing NSAID without the lithium prescriber. If you already took some and feel newly shaky or confused, get a same-day level. Acetaminophen is the pain option usually discussed instead."
	},
	{
		id: "lithium-thiazide",
		groups: [{ classes: ["lithium"] }, { classes: ["thiazide"] }],
		severity: "major",
		title: "This water pill can spike lithium",
		plain: "{meds} are a textbook interaction. Hydrochlorothiazide can raise lithium into the toxic range.",
		why: "Thiazide diuretics increase lithium reabsorption in the kidney. Loop water pills are less predictable; thiazides are the classic problem.",
		whatToDo: "Don’t add or stop the water pill without a lithium level plan. Dehydration and low-salt diets push the same direction. Same-day care for confusion, worsening tremor, or vomiting."
	},
	{
		id: "lithium-raas",
		groups: [{ classes: ["lithium"] }, { classes: ["acei", "arb"] }],
		severity: "major",
		title: "Blood-pressure pills can raise lithium",
		plain: "{meds} can slowly increase the lithium level, particularly in older adults or when you get dehydrated.",
		why: "ACE inhibitors and ARBs reduce lithium excretion. The rise may show up over weeks.",
		whatToDo: "Starting either medicine should come with a lithium level check. A stomach bug is a reason to call, not to push fluids blindly if you were given different sick-day rules."
	},
	{
		id: "lithium-metro",
		groups: [{ classes: ["lithium"] }, { ids: ["metronidazole"] }],
		severity: "moderate",
		title: "Lithium levels can creep up",
		plain: "{meds} have been linked to higher lithium levels. It is less famous than the NSAID interaction and still worth a check.",
		why: "Metronidazole is reported to reduce lithium clearance in some people.",
		whatToDo: "Tell the lithium prescriber you are starting metronidazole. Ask if a level is due. Watch for new tremor or confusion."
	},
	{
		id: "mtx-nsaid",
		groups: [{ classes: ["mtx"] }, { classes: ["nsaid"] }],
		severity: "major",
		title: "Methotrexate toxicity",
		plain: "{meds} can raise methotrexate to a toxic level — mouth sores, low blood counts, kidney strain. Some people with arthritis are prescribed both on purpose, with monitoring. Adding an NSAID yourself is different.",
		why: "NSAIDs reduce methotrexate clearance. The danger is greatest with the high doses used in cancer, but low weekly doses are not automatically exempt.",
		whatToDo: "Don’t add ibuprofen or naproxen without the prescriber who manages methotrexate. Confirm you are on a weekly schedule, not daily. Fever, mouth ulcers, or unusual bruising need a prompt call."
	},
	{
		id: "mtx-bactrim",
		groups: [{ classes: ["mtx"] }, { ids: ["smx-tmp"] }],
		severity: "major",
		title: "A bone-marrow combination to avoid",
		plain: "{meds} together can crash blood counts. This is one of the antibiotic pairings rheumatology teams try hard to avoid.",
		why: "Both interfere with folate metabolism. The bone marrow can stop making cells.",
		whatToDo: "Do not take Bactrim with methotrexate unless a specialist is explicitly managing it. If it was just prescribed, call before you take it. Fever or a bad sore throat on methotrexate is already a reason to call."
	},
	{
		id: "digoxin-amio",
		groups: [{ ids: ["digoxin"] }, { ids: ["amiodarone"] }],
		severity: "major",
		title: "Digoxin can double",
		plain: "{meds} — amiodarone commonly doubles the digoxin level. The digoxin dose is often cut in half when amiodarone starts.",
		why: "Amiodarone blocks transporters and kidneys pathways that clear digoxin. Amiodarone also lasts for months.",
		whatToDo: "Don’t start either without the cardiologist adjusting digoxin. Nausea, halos around lights, confusion, or a very slow pulse can be toxicity — same-day care."
	},
	{
		id: "digoxin-clarithro",
		groups: [{ ids: ["digoxin"] }, { ids: ["clarithromycin"] }],
		severity: "major",
		title: "The antibiotic can cause digoxin toxicity",
		plain: "{meds} — clarithromycin can raise digoxin quickly. People have been hospitalized for this.",
		why: "Clarithromycin inhibits P-glycoprotein, which helps clear digoxin, and may also change gut bacteria that normally inactivate some of it.",
		whatToDo: "The prescriber should pick a different antibiotic or plan a digoxin check. Don’t wait for a routine visit if you feel nauseated, confused, or notice visual halos."
	},
	{
		id: "digoxin-azithro",
		groups: [{ ids: ["digoxin"] }, { ids: ["azithromycin"] }],
		severity: "moderate",
		title: "Digoxin can tick upward",
		plain: "{meds} have been linked to higher digoxin levels, less dramatically than with clarithromycin.",
		why: "Azithromycin can still affect digoxin transport in some people.",
		whatToDo: "Mention the Z-Pak to whoever manages digoxin. New nausea or visual changes deserve a level, not a wait."
	},
	{
		id: "digoxin-k-wasting",
		groups: [{ ids: ["digoxin"] }, { classes: ["k_wasting"] }],
		severity: "moderate",
		title: "Low potassium makes digoxin dangerous",
		plain: "{meds} — water pills that waste potassium don’t raise digoxin directly. They make a normal digoxin level act toxic.",
		why: "The heart is much more sensitive to digoxin when potassium or magnesium is low.",
		whatToDo: "Don’t skip potassium checks. Leg cramps, muscle weakness, or a suddenly slower pulse are reasons to call. Replacing potassium is a dose, not a guess."
	},
	{
		id: "digoxin-nondhp",
		groups: [{ ids: ["digoxin"] }, { classes: ["ccb_nondhp"] }],
		severity: "moderate",
		title: "Digoxin levels and heart rate both fall",
		plain: "{meds} can raise digoxin and slow the heart further. Verapamil is the louder of the two.",
		why: "Verapamil and diltiazem reduce digoxin clearance and also slow conduction through the same heart node.",
		whatToDo: "This pairing needs one clinician watching the rate and the level. Report dizziness or a pulse that feels too slow."
	},
	{
		id: "bb-nondhp",
		groups: [{ classes: ["beta_blocker"] }, { classes: ["ccb_nondhp"] }],
		severity: "major",
		title: "The heart rate can fall too far",
		plain: "{meds} both slow the heart’s electrical gate. Together they can cause a very slow pulse or a block that makes people faint.",
		why: "Beta blockers and non-dihydropyridine calcium blockers (verapamil, diltiazem) depress the same AV node. Amlodipine does not do this the same way.",
		whatToDo: "Don’t combine verapamil or diltiazem with a beta blocker unless a cardiologist is driving. A pulse under the range you were given, or fainting, needs urgent care."
	},
	{
		id: "k-stack",
		groups: [{ classes: ["potassium"] }, { classes: [
			"acei",
			"arb",
			"k_sparing"
		] }],
		severity: "major",
		title: "Potassium can climb too high",
		plain: "{meds} both raise potassium. High potassium can disturb the heart’s rhythm before you feel anything. Salt substitutes count as potassium.",
		why: "ACE inhibitors, ARBs, and spironolactone reduce potassium excretion. A supplement adds more in.",
		whatToDo: "Don’t start potassium or a salt substitute unless a clinician who sees your labs told you to. If you were told to take both, keep the lab schedule. New weakness or skipped heartbeats deserve a call."
	},
	{
		id: "ace-spiro",
		groups: [{ classes: ["acei", "arb"] }, { classes: ["k_sparing"] }],
		severity: "moderate",
		title: "A common pair that needs lab checks",
		plain: "{meds} are often prescribed together in heart failure. The point of the visits is potassium. It can rise even without a potassium pill.",
		why: "Both reduce potassium loss. The benefit in heart failure is real; so is hyperkalemia if nobody is looking.",
		whatToDo: "Don’t skip bloodwork. Don’t add potassium, salt substitute, or an NSAID on the side. Hold questions during a dehydrating illness should go to the clinic, not to guesswork."
	},
	{
		id: "ace-arb",
		groups: [{ classes: ["acei"] }, { classes: ["arb"] }],
		severity: "moderate",
		title: "Two blood-pressure families you usually don’t stack",
		plain: "{meds} work on the same hormone system. Using both raises potassium and kidney risk without better everyday blood-pressure control.",
		why: "Dual blockade of the renin-angiotensin system failed in trials: more harm, little added benefit.",
		whatToDo: "Ask if one of them is a leftover. Don’t restart an old ACE inhibitor on top of a newer ARB."
	},
	{
		id: "pde5-alpha",
		groups: [{ classes: ["pde5"] }, { classes: ["alpha_blocker"] }],
		severity: "moderate",
		title: "Blood pressure can sag when you stand",
		plain: "{meds} both relax vessels. Dizziness on standing is the usual problem, not the nitrate-level crash.",
		why: "Alpha blockers and PDE5 inhibitors have additive blood-pressure effects. Tamsulosin is a frequent real-world pair.",
		whatToDo: "If you use both, they are often started apart, at low doses, not on the same evening for the first time. Sit or lie down if you feel faint. This is different from the absolute ban with nitrates."
	},
	{
		id: "clopi-ppi",
		groups: [{ ids: ["clopidogrel"] }, { classes: ["ppi_2c19"] }],
		severity: "moderate",
		title: "This acid pill can weaken clopidogrel",
		plain: "{meds} — omeprazole and esomeprazole can stop clopidogrel from turning into its active form. Pantoprazole is the acid medicine usually swapped in.",
		why: "Clopidogrel needs the CYP2C19 enzyme to activate. Omeprazole and esomeprazole block that enzyme. Pantoprazole does so much less.",
		whatToDo: "Don’t pick Prilosec or Nexium off the shelf if you take Plavix. Ask about pantoprazole, or whether you still need an acid pill at all."
	},
	{
		id: "qt-pair",
		groups: [{ classes: ["qt_risk"] }, { classes: ["qt_risk"] }],
		severity: "moderate",
		title: "Two medicines that can stretch the heart’s rhythm",
		plain: "{meds} can add to each other’s effect on the QT interval — a measurement of the heart’s electrical reset. In uncommon cases that becomes a dangerous rhythm. Citalopram is the antidepressant in this list where the warning is strongest.",
		why: "Drugs that prolong QT do it more when combined, when potassium is low, or when doses are high.",
		whatToDo: "Tell the prescriber, especially if you have a history of long QT, fainting, or low potassium. Don’t stack extra doses. A fainting spell or a racing collapse is emergency care."
	},
	{
		id: "ssri-qt-ppi",
		groups: [{ ids: ["citalopram", "escitalopram"] }, { classes: ["ppi_2c19"] }],
		severity: "moderate",
		title: "The acid pill can raise this antidepressant",
		plain: "{meds} — omeprazole or esomeprazole can increase citalopram or escitalopram. Higher levels matter because of the heart-rhythm warning, especially with citalopram.",
		why: "Those PPIs block CYP2C19, which helps clear both antidepressants.",
		whatToDo: "Ask whether the antidepressant dose is still right, or whether pantoprazole should replace the acid pill. Don’t increase the antidepressant to chase effect."
	},
	{
		id: "fq-steroid",
		groups: [{ classes: ["fq"] }, { classes: ["corticosteroid"] }],
		severity: "moderate",
		title: "Tendon injury is more likely",
		plain: "{meds} together raise the chance of tendonitis or tendon rupture, particularly the Achilles, and particularly over age 60.",
		why: "Fluoroquinolones already carry a tendon warning. Systemic steroids multiply it.",
		whatToDo: "Stop strenuous loading and call if a tendon hurts, swells, or you feel a pop. Ask whether a different antibiotic was an option before you start, if you haven’t taken it yet."
	},
	{
		id: "levo-cations",
		groups: [{ classes: ["thyroid"] }, { classes: [
			"calcium",
			"iron",
			"magnesium",
			"zinc",
			"polyvalent"
		] }],
		severity: "moderate",
		title: "The thyroid pill may not get absorbed",
		plain: "{meds} in the same sitting means less levothyroxine gets in. People slowly become under-replaced and think the dose ‘stopped working.’ A multivitamin counts.",
		why: "Calcium, iron, magnesium, and zinc bind levothyroxine in the gut. Separation by about four hours avoids most of it.",
		whatToDo: "Take levothyroxine on an empty stomach, and park calcium, iron, magnesium, zinc, and multivitamins at the other end of the day. If you have been taking them together, don’t change the thyroid dose until a clinician sees a lab — the level may rebound once you separate them."
	},
	{
		id: "levo-ppi",
		groups: [{ classes: ["thyroid"] }, { classes: ["ppi"] }],
		severity: "moderate",
		title: "Less stomach acid, less thyroid absorption",
		plain: "{meds} — long-term acid suppression can reduce how much levothyroxine you absorb. The dose sometimes needs to go up, then come back down if the acid pill stops.",
		why: "Levothyroxine dissolves better in an acidic stomach. PPIs raise the pH.",
		whatToDo: "Mention both at lab time. Don’t adjust the thyroid dose because you feel different for a week."
	},
	{
		id: "abx-cations",
		groups: [{ classes: ["fq", "tetracycline"] }, { classes: ["polyvalent"] }],
		severity: "moderate",
		title: "Neither the antibiotic nor the mineral gets absorbed",
		plain: "{meds} bind to each other in the stomach. The antibiotic may not work, and the iron, calcium, magnesium, or zinc mostly goes to waste too. Vitamin C is not this problem — the minerals are.",
		why: "Ciprofloxacin, levofloxacin, and doxycycline grab onto these minerals (chelation). The clump doesn’t pass into the blood. A multivitamin counts, and so do antacids.",
		whatToDo: "Separate them by several hours. A common instruction is the antibiotic 2 hours before or 6 hours after the mineral — use the timing on your bottle. Don’t stop the antibiotic. Amoxicillin and azithromycin are not in this chelation group."
	},
	{
		id: "alendronate-calcium",
		groups: [{ ids: ["alendronate"] }, { classes: ["polyvalent"] }],
		severity: "moderate",
		title: "Minerals block the osteoporosis pill",
		plain: "{meds} at the same time means the alendronate doesn’t absorb. Calcium is the usual culprit; iron, magnesium, zinc, and multivitamins do it too.",
		why: "Alendronate already absorbs poorly. Polyvalent minerals bind what’s left.",
		whatToDo: "Alendronate first, plain water only, upright, empty stomach, at least 30 minutes before food or any other pill — including calcium, iron, magnesium, zinc, and vitamins."
	},
	{
		id: "inducer-oc",
		groups: [{ classes: ["inducer"] }, { classes: ["coc"] }],
		severity: "major",
		title: "Birth control pills can fail",
		plain: "{meds} — this is one of the real cases where another medicine makes combined birth control less reliable. Most ordinary antibiotics do not do this. These do.",
		why: "Carbamazepine, rifampin, and St John’s wort induce enzymes that clear contraceptive hormones. Breakthrough bleeding can be a clue, but pregnancy can happen without it.",
		whatToDo: "Use a backup method or a different contraceptive that your clinician says is unaffected. Don’t rely on the pill alone while the inducer is on board, and ask how long to keep the backup after it stops."
	},
	{
		id: "lamotrigine-oc",
		groups: [{ ids: ["lamotrigine"] }, { classes: ["coc"] }],
		severity: "moderate",
		title: "The pill can cut lamotrigine levels",
		plain: "{meds} — estrogen in combined birth control can drop lamotrigine by about half. Seizure control or mood stability can slip. The pill week off can then make the level jump.",
		why: "Estrogen induces the pathway that clears lamotrigine. The interaction is on the seizure medicine more than on the contraceptive.",
		whatToDo: "The prescriber often adjusts the lamotrigine dose and times it around pill packs. Don’t change either dose because you feel off — call. This entry is not a progestin-only pill or an IUD."
	},
	{
		id: "lamotrigine-cbz",
		groups: [{ ids: ["lamotrigine"] }, { ids: ["carbamazepine"] }],
		severity: "moderate",
		title: "Carbamazepine lowers lamotrigine",
		plain: "{meds} — carbamazepine speeds clearance of lamotrigine, so the lamotrigine dose that worked alone may be too low.",
		why: "Carbamazepine induces glucuronidation, the route that clears lamotrigine.",
		whatToDo: "Dose changes belong to the prescriber, with a titration that still respects rash risk. Don’t double lamotrigine to compensate."
	},
	{
		id: "colchicine-clarithro",
		groups: [{ classes: ["colchicine"] }, { classes: ["macrolide_strong"] }],
		severity: "major",
		title: "Colchicine toxicity, including fatal cases",
		plain: "{meds} can make colchicine levels dangerous. Severe diarrhea, weakness, and low blood counts have led to deaths.",
		why: "Clarithromycin blocks both CYP3A4 and P-glycoprotein, the two exits colchicine uses.",
		whatToDo: "Do not take this antibiotic with colchicine unless a specialist rewrote the plan. If you already did, call promptly — especially if diarrhea is severe. Azithromycin is not in this same contraindicated bucket."
	},
	{
		id: "colchicine-statin",
		groups: [{ classes: ["colchicine"] }, { classes: ["statin"] }],
		severity: "moderate",
		title: "Muscle injury is more likely",
		plain: "{meds} together add muscle toxicity. Many people take both for gout and cholesterol, with a clear warning to report muscle pain.",
		why: "Colchicine and statins can each injure muscle. The overlap is pharmacologic and, for some statins, also about shared clearance.",
		whatToDo: "Report unexplained muscle pain, weakness, or dark urine. Don’t raise either dose without asking."
	},
	{
		id: "colchicine-grapefruit",
		groups: [{ classes: ["colchicine"] }, { classes: ["grapefruit"] }],
		severity: "moderate",
		title: "Grapefruit raises colchicine",
		plain: "{meds} — grapefruit can increase colchicine exposure. With a drug this narrow, that is worth skipping the fruit.",
		why: "Grapefruit inhibits the gut enzyme and transporters that limit how much colchicine gets in.",
		whatToDo: "Avoid grapefruit while you take colchicine. Ordinary oranges are a fine substitute."
	},
	{
		id: "alcohol-metro",
		groups: [{ classes: ["alcohol"] }, { ids: ["metronidazole"] }],
		severity: "major",
		title: "The label says do not drink",
		plain: "{meds} can cause flushing, nausea, vomiting, and a pounding heart. The warning covers the whole course and a few days after the last dose.",
		why: "Metronidazole is labeled for a disulfiram-like reaction with alcohol. Reports vary, and the instruction does not.",
		whatToDo: "Skip alcohol until about three days after the last dose, unless your own clinician gave a different window. Mouthwash and some liquid medicines contain alcohol — a pharmacist can check those."
	},
	{
		id: "alcohol-metformin",
		groups: [{ classes: ["alcohol"] }, { ids: ["metformin"] }],
		severity: "moderate",
		title: "Heavy drinking is the problem, not a sip",
		plain: "{meds} — binge drinking on metformin raises a rare but serious risk called lactic acidosis, and it also swings blood sugar.",
		why: "Alcohol and metformin both touch lactate metabolism. The risk is concentrated in heavy drinking, dehydration, and kidney disease — not in a single drink with dinner for most people.",
		whatToDo: "Be honest about the amount. Binges and drinking while dehydrated or acutely ill are the pattern to stop. If you drink most days, ask how that fits the medicine."
	},
	{
		id: "alcohol-hypo",
		groups: [{ classes: ["alcohol"] }, { classes: ["insulin", "sulfonylurea"] }],
		severity: "moderate",
		title: "Alcohol can push blood sugar too low",
		plain: "{meds} — alcohol blocks the liver from releasing sugar, so insulin or a sulfonylurea can overshoot into a low.",
		why: "The liver is busy clearing alcohol and won’t do its usual glucose rescue. The low can show up hours later, including overnight.",
		whatToDo: "Don’t drink on an empty stomach if you use these medicines. Know your low-sugar plan. A bedtime snack is sometimes advised after drinking — ask what fits your doses."
	},
	{
		id: "alcohol-warfarin",
		groups: [{ classes: ["alcohol"] }, { ids: ["warfarin"] }],
		severity: "moderate",
		title: "Alcohol makes warfarin unpredictable",
		plain: "{meds} — a binge can raise bleeding risk, and day-to-day swings in drinking make the INR harder to stabilize.",
		why: "Alcohol affects warfarin metabolism and, when heavy, the liver that makes clotting factors. Falls while anticoagulated add head-bleed risk.",
		whatToDo: "Keep intake steady and modest if you drink at all, and tell the clinic the real number. A fall with a hit to the head needs urgent evaluation."
	},
	{
		id: "alcohol-nsaid",
		groups: [{ classes: ["alcohol"] }, { classes: ["nsaid"] }],
		severity: "moderate",
		title: "Both irritate the stomach",
		plain: "{meds} together make a stomach bleed more likely than either alone.",
		why: "Alcohol and NSAIDs each damage the mucosal barrier. Together they are a common cause of ulcer bleeding.",
		whatToDo: "Skip the combination when you can. If you need a pain pill after drinking, ask a pharmacist rather than doubling the NSAID."
	},
	{
		id: "alcohol-apap",
		groups: [{ classes: ["alcohol"] }, { ids: ["acetaminophen"] }],
		severity: "moderate",
		title: "Liver risk when both are heavy",
		plain: "{meds} — daily heavy drinking plus higher doses of acetaminophen is what stresses the liver. A single labeled dose is a different situation.",
		why: "Chronic alcohol use depletes the backup pathway the liver uses to detoxify acetaminophen.",
		whatToDo: "Stay inside the daily maximum, and lower if you drink heavily — ask a pharmacist for the number that fits you. Count combination cold and pain products."
	},
	{
		id: "alcohol-ssri",
		groups: [{ classes: ["alcohol"] }, { classes: ["ssri", "snri"] }],
		severity: "minor",
		title: "Alcohol can blunt the reason you take this",
		plain: "{meds} — alcohol can worsen drowsiness and make mood and sleep harder to judge. It is not a hard chemical ban for most people.",
		why: "The interaction is mostly additive sedation and the effect of alcohol on depression itself, not a single dangerous metabolite.",
		whatToDo: "If mood is why you take the medicine, the drinking pattern belongs in the visit. Don’t drive if the mix makes you foggy."
	},
	{
		id: "cyp2d6-bb",
		groups: [{ classes: ["cyp2d6_strong"] }, { ids: ["metoprolol", "carvedilol"] }],
		severity: "moderate",
		title: "The beta blocker can become too strong",
		plain: "{meds} — fluoxetine and paroxetine can raise metoprolol or carvedilol. A very slow pulse, fatigue, or cold hands can be the clue.",
		why: "Those two SSRIs strongly block CYP2D6, a main route for these beta blockers. Sertraline is not in this strong group.",
		whatToDo: "If the antidepressant is new and the pulse has dropped, call. Dose changes are common. Don’t stop the beta blocker suddenly to ‘fix’ it."
	},
	{
		id: "insulin-su",
		groups: [{ classes: ["insulin"] }, { classes: ["sulfonylurea"] }],
		severity: "moderate",
		title: "Low blood sugar is more likely",
		plain: "{meds} both lower blood sugar actively. Together, lows are a planned risk, not a surprise you should discover overnight.",
		why: "Sulfonylureas force insulin release and injected insulin adds more. There is no extra brake.",
		whatToDo: "Know the low-sugar symptoms and treatment you were taught. If lows are recurring, that is a dose conversation, not a reason to eat through it forever."
	},
	{
		id: "bb-hypo",
		groups: [{ classes: ["beta_blocker"] }, { classes: ["insulin", "sulfonylurea"] }],
		severity: "moderate",
		title: "A low can be quieter than usual",
		plain: "{meds} — beta blockers can hide a fast heartbeat, one of the usual alarms for low blood sugar. Sweating can still happen.",
		why: "The warning signs of hypoglycemia are partly adrenaline. Beta blockers blunt those signs. They can also slightly change how a low recovers.",
		whatToDo: "Learn the signs that still show up for you, especially sweating and confusion. Check a glucose rather than waiting to ‘feel’ a low if you are unsure."
	},
	{
		id: "ginkgo-bleed",
		groups: [{ classes: ["ginkgo"] }, { classes: ["anticoagulant", "antiplatelet"] }],
		severity: "moderate",
		title: "Extra bleeding reports",
		plain: "{meds} — ginkgo has been tied, in case reports, to extra bleeding when combined with blood thinners or antiplatelet drugs.",
		why: "Ginkgo may inhibit platelet activating factor. The evidence is not a large trial, and the consequence of being wrong is a bleed.",
		whatToDo: "Tell the prescriber you take it. Stopping a supplement is usually simpler than adjusting a blood thinner around it."
	},
	{
		id: "fishoil-bleed",
		groups: [{ classes: ["fishoil"] }, { classes: ["anticoagulant", "antiplatelet"] }],
		severity: "minor",
		title: "High-dose fish oil adds a little bleed risk",
		plain: "{meds} — a standard small capsule is a minor note. Prescription-strength omega-3 doses are the ones that matter more.",
		why: "High-dose omega-3s can impair platelets slightly. Food portions of fish are not the same as concentrated capsules.",
		whatToDo: "Say the dose out loud at your next visit, in milligrams. Don’t stack several ‘heart health’ products that all claim a blood effect."
	},
	{
		id: "ppi-dup",
		groups: [{ classes: ["ppi"] }, { classes: ["ppi"] }],
		severity: "minor",
		title: "Two acid-blocking pills",
		plain: "{meds} are the same kind of medicine. A prescription PPI plus an over-the-counter one is a common accidental double.",
		why: "More acid suppression isn’t more healing once you’re on a full dose. It does add long-term downsides.",
		whatToDo: "Check bottles for omeprazole, esomeprazole, and pantoprazole hiding under brand names. Keep one, unless a clinician split the timing on purpose."
	},
	{
		id: "antihistamine-dup",
		groups: [{ classes: ["antihistamine"] }, { classes: ["antihistamine"] }],
		severity: "minor",
		title: "Two allergy antihistamines",
		plain: "{meds} usually don’t both need to be on the daily list. Diphenhydramine is the one that sedates.",
		why: "They compete for the same histamine receptors. Sedation and anticholinergic effects are what you gain from adding Benadryl.",
		whatToDo: "Pick the non-drowsy one for the day unless a clinician told you to use diphenhydramine for a specific reason, like a bad itch at night."
	},
	{
		id: "abx-probiotic",
		groups: [{ classes: ["antibiotic"] }, { classes: ["probiotic"] }],
		severity: "moderate",
		title: "The antibiotic can wipe out the probiotic",
		plain: "{meds} taken together means the antibiotic can kill the live bacteria in the supplement before they do anything. The antibiotic itself still works. This is one of the real cases where an antibiotic blocks a supplement.",
		why: "Bacterial probiotics have to survive the gut to matter. An antibiotic in the same swallow is built to kill bacteria. Yeast probiotics such as Florastor are less affected.",
		whatToDo: "Separate them by at least two hours. Don’t skip antibiotic doses to ‘protect’ the probiotic. Severely suppressed immune systems are a reason to ask before using live bacteria at all."
	},
	{
		id: "vka-vitk",
		groups: [{ ids: ["warfarin"] }, { classes: ["vitamin_k"] }],
		severity: "major",
		title: "Vitamin K can cancel warfarin",
		plain: "{meds} pull in opposite directions. Vitamin K is what the body uses to make the clotting factors warfarin is trying to slow down. A supplement is a much bigger change than a salad.",
		why: "Warfarin blocks the recycling of vitamin K. Extra vitamin K, especially K1 or K2 pills, can drop the INR and let clots form.",
		whatToDo: "Don’t start, stop, or change a vitamin K supplement unless the anticoagulation clinic is in on it. If it was prescribed as a reversal plan, that is a specific dose — not an everyday add-on. Leafy greens can stay if the weekly amount is steady."
	},
	{
		id: "b12-depleters",
		groups: [{ classes: ["vitamin_b12"] }, { classes: ["biguanide", "ppi"] }],
		severity: "moderate",
		title: "These medicines can lower vitamin B12",
		plain: "{meds} — metformin and long-term acid-blocking pills reduce B12 absorption over months, mostly from food. A B12 pill is often part of the fix, not something you have to avoid.",
		why: "Stomach acid helps release B12 from food. Metformin interferes with absorption in the last part of the small intestine. Short antibiotic courses are not the same issue.",
		whatToDo: "If you have been on metformin or a daily PPI for a long time, ask whether a B12 level is due. Don’t stop either medicine because of this note."
	},
	{
		id: "vitc-iron",
		groups: [{ classes: ["vitamin_c"] }, { classes: ["iron"] }],
		severity: "minor",
		title: "Vitamin C helps iron get in",
		plain: "{meds} — vitamin C increases iron absorption. That can be the point of taking them together, and it can also mean more stomach upset or more iron than you meant.",
		why: "Ascorbic acid keeps iron in the form the gut absorbs more easily.",
		whatToDo: "If a clinician told you to pair them, this is expected. If iron levels are already high, or the iron is only inside a multivitamin you didn’t realize you were doubling, mention the vitamin C dose."
	},
	{
		id: "vitc-warfarin",
		groups: [{ classes: ["vitamin_c"] }, { ids: ["warfarin"] }],
		severity: "minor",
		title: "Very high doses of vitamin C occasionally move the INR",
		plain: "{meds} — ordinary dietary vitamin C is not a warfarin problem. Grams-per-day supplement doses have occasionally been reported to change the INR.",
		why: "Evidence is thin and not one-directional. It is a mention, not a ban.",
		whatToDo: "Tell the warfarin clinic if you take high-dose vitamin C every day. You do not need to avoid fruit."
	},
	{
		id: "kratom-opioid",
		groups: [{ classes: ["kratom"] }, { classes: ["opioid"] }],
		severity: "major",
		title: "Kratom stacks with opioid pain medicines",
		plain: "{meds} can slow breathing the way two opioids can. Kratom is not an approved pain medicine, and products vary, including concentrated 7-hydroxymitragynine.",
		why: "Mitragynine and 7-hydroxymitragynine act on opioid receptors. Adding a prescription opioid multiplies sedation and respiratory depression.",
		whatToDo: "Don’t combine them. If someone is hard to wake, breathing slowly, or blue at the lips, that is emergency care — tell responders both were taken. Don’t stop a prescribed opioid on your own tonight; do make sure the prescriber knows about the kratom."
	},
	{
		id: "kratom-cns",
		groups: [{ classes: ["kratom"] }, { classes: [
			"benzo",
			"zd",
			"alcohol",
			"gabapentinoid"
		] }],
		severity: "major",
		title: "Kratom plus sedatives can slow breathing",
		plain: "{meds} all depress the nervous system. With benzodiazepines, sleep medicines, gabapentin or pregabalin, or alcohol, the risk is slowed breathing and profound sedation — not just feeling sleepy.",
		why: "Kratom has opioid-like effects. Those add to other drugs that already slow the drive to breathe.",
		whatToDo: "Don’t mix them. Emergency care if breathing slows or the person can’t be woken. Regular kratom use can also cause withdrawal if stopped abruptly — that is a clinician conversation, not a same-night cold stop piled on top of other sedatives without advice."
	},
	{
		id: "kratom-sedating",
		groups: [{ classes: ["kratom"] }, { classes: ["sedating"] }],
		severity: "moderate",
		title: "Extra drowsiness with kratom",
		plain: "{meds} — sedating antihistamines and trazodone add sleepiness on top of kratom. Falls and next-day fog are the usual result.",
		why: "Kratom is already sedating in many doses. Diphenhydramine and trazodone add to that.",
		whatToDo: "Avoid driving until you know the mix. Don’t add alcohol or an opioid on top."
	},
	{
		id: "kratom-serotonin",
		groups: [{ classes: ["kratom"] }, { classes: [
			"ssri",
			"snri",
			"dxm",
			"triptan",
			"opioid_serotonergic",
			"stjohns"
		] }],
		severity: "moderate",
		title: "Kratom and serotonin don’t sit quietly",
		plain: "{meds} — case reports describe serotonin toxicity and, with tramadol, seizures when kratom is added to serotonergic medicines. This is less mapped than St John’s wort, and still not something to experiment with.",
		why: "Kratom has serotonergic activity besides its opioid-like effect. Tramadol adds seizure risk on top.",
		whatToDo: "Don’t add kratom to an antidepressant, a triptan, dextromethorphan, or tramadol on your own. Agitation, heavy sweating, tremor, confusion, or a seizure needs urgent care. Bring the product with you."
	},
	{
		id: "kratom-maoi",
		groups: [{ classes: ["kratom"] }, { classes: ["maoi"] }],
		severity: "major",
		title: "Kratom and an MAOI are a bad mix",
		plain: "{meds} can cause serotonin toxicity or blood-pressure swings. An MAOI already has a strict list. Kratom is not a safe exception.",
		why: "MAOIs block serotonin breakdown. Kratom has both serotonergic and stimulant-like activity.",
		whatToDo: "Do not combine them. A severe headache, chest pain, high fever, rigid muscles, or confusion is emergency care. The washout rules for an MAOI are a specialist decision."
	},
	{
		id: "kratom-warfarin",
		groups: [{ classes: ["kratom"] }, { ids: ["warfarin"] }],
		severity: "moderate",
		title: "Kratom can make warfarin unpredictable",
		plain: "{meds} — kratom has been reported to push warfarin’s effect around, including a higher INR. Products aren’t standardized, so the effect isn’t either.",
		why: "Lab and case reports suggest kratom can inhibit liver enzymes that clear warfarin, including CYP2C9. That is not the same as a measured dose in a tablet.",
		whatToDo: "Tell the anticoagulation clinic before you take it, or as soon as you already have. Don’t adjust warfarin yourself. Watch for unusual bleeding."
	},
	{
		id: "kratom-bupropion",
		groups: [{ classes: ["kratom"] }, { ids: ["bupropion"] }],
		severity: "moderate",
		title: "Seizure risk goes up",
		plain: "{meds} each lower the seizure threshold. Together the risk is higher, and kratom dose is rarely what the label implies.",
		why: "Bupropion is dose-limited because of seizures. Kratom has also been tied to seizures, especially with other at-risk drugs.",
		whatToDo: "Don’t combine them on your own. A seizure is emergency care."
	},
	{
		id: "kratom-decongestant",
		groups: [{ classes: ["kratom"] }, { classes: ["decongestant"] }],
		severity: "moderate",
		title: "Both can raise blood pressure and heart rate",
		plain: "{meds} — pseudoephedrine and kratom can each make the pulse and blood pressure climb. Together that is more than a stuffy-nose fix.",
		why: "Kratom has stimulant effects at many doses. Decongestants add a second stimulant.",
		whatToDo: "Skip the decongestant, or ask a pharmacist for a non-stimulant option. Chest pain or a severe headache is emergency care."
	},
	{
		id: "methadone-inducer",
		groups: [{ ids: ["methadone"] }, { classes: ["inducer"] }],
		severity: "major",
		title: "Methadone can crash, then rebound too strong",
		plain: "{meds} — carbamazepine, rifampin, and St John’s wort speed up the liver and can strip methadone out. People go into withdrawal. If that other drug is then stopped, the same methadone dose can suddenly be an overdose.",
		why: "Methadone is cleared by liver enzymes those drugs turn up. The danger runs in both directions, days apart, not only on the day you swallow them together.",
		whatToDo: "Do not start or stop the enzyme-speeding drug without the methadone prescriber in the plan. Do not raise methadone on your own to chase withdrawal. Emergency care for slow breathing after any of these change.",
		notice: "Yawns, sweating, aches, and diarrhea if methadone drops. Then, later, heavy sedation if the other drug stops and methadone piles up.",
		howSure: "This is a standard methadone teaching point from the label and clinic guides."
	},
	{
		id: "methadone-3a4",
		groups: [{ ids: ["methadone"] }, { classes: ["macrolide_strong", "grapefruit"] }],
		severity: "moderate",
		title: "Methadone levels can climb",
		plain: "{meds} can slow how methadone is cleared. More methadone means more sedation and a higher chance the heart’s rhythm stretches, which methadone can already do on its own.",
		why: "Clarithromycin blocks CYP3A4 strongly. Grapefruit blocks it more mildly, and the effect can last into the next day. Methadone also prolongs the QT interval.",
		whatToDo: "Tell whoever prescribes methadone before you start clarithromycin. Daily grapefruit is worth mentioning too — a one-time glass is a smaller issue than a pitcher every morning. Fainting or a racing collapse is emergency care.",
		notice: "More sleepy than your usual methadone dose. Dizzy. A fainting spell.",
		howSure: "Enzyme blocking is real. How much one glass of grapefruit moves a given methadone dose varies."
	},
	{
		id: "methadone-2d6",
		groups: [{ ids: ["methadone"] }, { ids: [
			"fluoxetine",
			"paroxetine",
			"bupropion"
		] }],
		severity: "moderate",
		title: "These can raise the methadone level",
		plain: "{meds} — fluoxetine, paroxetine, and bupropion can block a liver path methadone uses. The methadone you already take can start to feel like a bigger dose.",
		why: "They inhibit CYP2D6. Methadone is broken down by more than one enzyme, so the bump is real but not identical for every person.",
		whatToDo: "The methadone clinic should know you are on one of these before the dose stays where it is. Don’t add extra methadone because you feel off. Watch for heavier sedation over the first week or two.",
		notice: "Sleepier days, slower thinking, or nausea that was not there on the old combination.",
		howSure: "On interaction lists as a level-raising pair. It is not the same emergency as methadone plus a benzodiazepine."
	},
	{
		id: "glp1-hypo",
		groups: [{ classes: ["glp1"] }, { classes: ["insulin", "sulfonylurea"] }],
		severity: "major",
		title: "Low blood sugar becomes much more likely",
		plain: "{meds} — a GLP-1 medicine plus insulin or a sulfonylurea such as glipizide can drive sugar down too far. Metformin alone usually does not do this. Insulin and glipizide do.",
		why: "GLP-1 medicines lower glucose, and they also make you eat less. Insulin and sulfonylureas push sugar down whether or not you have eaten.",
		whatToDo: "Do not ‘figure out’ a new insulin dose from a blog. The prescriber often lowers insulin or the sulfonylurea when the GLP-1 starts. Carry fast sugar if you were told to. A low you cannot treat, or confusion, is emergency care.",
		notice: "Shaking, sweating, sudden hunger, confusion, or feeling too sleepy to eat.",
		howSure: "This warning is on the Ozempic, Wegovy, Mounjaro, and Zepbound labels."
	},
	{
		id: "tirzepatide-oc",
		groups: [{ classes: ["tirzepatide"] }, { classes: ["coc"] }],
		severity: "moderate",
		title: "The pill can miss while the stomach slows",
		plain: "{meds} — tirzepatide can make combined birth-control pills less reliable right after you start and after each dose increase. Semaglutide does not carry this same label warning.",
		why: "The stomach empties more slowly, so the pill’s hormones may not be absorbed on the usual schedule.",
		whatToDo: "Use a backup method, or switch methods, for 4 weeks after the first dose and for 4 weeks after every dose increase. Don’t assume the pill ‘catches up’ by the next morning.",
		notice: "No symptom proves the pill failed. Spotting can happen, and so can pregnancy without spotting.",
		howSure: "This is a labeled instruction for Mounjaro and Zepbound, not a rumor."
	},
	{
		id: "ghs-steroid",
		groups: [{ classes: ["ghs"] }, { classes: ["corticosteroid"] }],
		severity: "moderate",
		title: "The steroid can shut the peptide’s signal down",
		plain: "{meds} — prednisone and other steroid pills blunt the growth-hormone pulse that sermorelin and similar peptides are trying to trigger. You can be taking both and mostly getting the steroid.",
		why: "Glucocorticoids suppress growth-hormone release. That is a known hormone effect, not a guess from a forum.",
		whatToDo: "If a clinician prescribed both, ask whether the timing still makes sense. Don’t raise the peptide dose to ‘beat’ the steroid. Don’t stop a prescribed steroid course early.",
		notice: "Often nothing you can feel. The interaction is the peptide doing less, not a dramatic crash.",
		howSure: "Steroids suppressing growth hormone is established. Exact human data for every research vial is not."
	},
	{
		id: "ghs-sugar",
		groups: [{ classes: ["ghs"] }, { classes: ["insulin", "sulfonylurea"] }],
		severity: "moderate",
		title: "Growth-hormone signals can push sugar up",
		plain: "{meds} pull blood sugar in a messy direction. The peptide encourages growth hormone, which tends to raise sugar. Insulin and glipizide are trying to lower it. Lows and highs both get harder to predict.",
		why: "Growth hormone opposes insulin. Secretagogue peptides are not identical to injecting growth hormone, but the sugar caution is the practical one.",
		whatToDo: "Check sugar more often if you start the peptide, and tell the diabetes prescriber. Don’t chase a high or a low by changing insulin alone overnight.",
		notice: "Sugars that used to be steady start swinging. Sweating and shakiness still mean a low until proven otherwise.",
		howSure: "The direction is biologically solid. Large trials of this exact stack do not exist."
	},
	{
		id: "peptide-bleed",
		groups: [{ classes: ["peptide_bleed"] }, { classes: ["anticoagulant", "antiplatelet"] }],
		severity: "moderate",
		title: "Bleeding is the question mark",
		plain: "{meds} — BPC-157 and TB-500 have animal data suggesting they can change bleeding time. That is not proof they protect you, and it is not proof they make warfarin safer. It means the mix is unstudied in people who already bleed more easily.",
		why: "A rat study found BPC-157 shortened bleeding time after heparin or warfarin. Humans were not in that study. TB-500 is grouped here because healing peptides and clotting are the same unanswered question.",
		whatToDo: "Tell the anticoagulation clinic or the surgeon before you use either peptide. Don’t stop warfarin or clopidogrel to ‘make room’ for a research vial. Unusual bruising, nosebleeds, or black stools need a call.",
		notice: "Bruises that spread, bleeding that is slow to stop, black or tarry stool.",
		howSure: "Animal research only. We flag it because being wrong about bleeding is costly, not because a human trial proved the pair."
	},
	{
		id: "melanotan-pde5",
		groups: [{ classes: ["melanotan"] }, { classes: ["pde5"] }],
		severity: "moderate",
		title: "Flushing, pressure swings, and erections that last too long",
		plain: "{meds} — melanotan already causes flushing, nausea, and spontaneous erections. Sildenafil or tadalafil add a second push on blood vessels and on erections.",
		why: "Both affect blood flow. Melanotan II is unapproved, so there is no label that tested this pair. The practical problems are a pressure drop and an erection that does not go down.",
		whatToDo: "Don’t combine them the same day. An erection lasting more than four hours is emergency care, whether or not you also took an approved erection medicine.",
		notice: "Heavy flushing, pounding heart, fainting, or an erection that will not settle.",
		howSure: "Case reports and known effects of each drug, not a controlled trial of the combination."
	},
	{
		id: "melanotan-bp",
		groups: [{ classes: ["melanotan"] }, { classes: [
			"acei",
			"arb",
			"ccb_dhp",
			"ccb_nondhp",
			"beta_blocker"
		] }],
		severity: "moderate",
		title: "Blood pressure can swing",
		plain: "{meds} — melanotan can make you flushed and lightheaded while your blood-pressure medicine is already lowering pressure. Standing up is when people notice.",
		why: "Unapproved tanning peptides are reported to cause flushing and blood-pressure changes. Adding a daily pressure pill stacks that uncertainty.",
		whatToDo: "Don’t start melanotan if your pressure is already hard to control. Sit or lie down if you gray out. Chest pain or fainting is emergency care.",
		notice: "Flushing, nausea, spots in your vision, or nearly fainting when you stand.",
		howSure: "Reports and the way the peptide behaves, not a dosing study with lisinopril."
	},
	{
		id: "pt141-bp",
		groups: [{ classes: ["pt141"] }, { classes: [
			"acei",
			"arb",
			"ccb_dhp",
			"ccb_nondhp",
			"beta_blocker"
		] }],
		severity: "moderate",
		title: "This shot can raise blood pressure for a few hours",
		plain: "{meds} — bremelanotide (Vyleesi, and unapproved PT-141 vials) temporarily raises blood pressure and slows the pulse. Your pressure pill does not erase that bump.",
		why: "The approved label warns about a short-lived rise in blood pressure. Uncontrolled high blood pressure and known heart disease are reasons not to use it.",
		whatToDo: "If your pressure runs high, this is a prescriber decision, not a research-vial decision. Don’t take an extra dose the same day. Chest pain, a severe headache, or fainting is emergency care.",
		notice: "A pounding or slow pulse, headache, flushing, or pressure that feels higher than usual for a few hours.",
		howSure: "The blood-pressure rise is on the Vyleesi label. Street ‘PT-141’ vials are not that labeled product."
	},
	{
		id: "pt141-pde5",
		groups: [{ classes: ["pt141"] }, { classes: ["pde5"] }],
		severity: "moderate",
		title: "Don’t stack the sexual-function drugs",
		plain: "{meds} both change blood flow for sexual function. Together they make blood-pressure swings and a prolonged erection more likely than either one alone.",
		why: "Bremelanotide raises pressure briefly. PDE5 inhibitors lower it in the vessels they open. The body is being pulled two ways.",
		whatToDo: "Use one approach, not both the same day, unless a clinician who knows both products told you otherwise. An erection lasting more than four hours is emergency care.",
		notice: "Flushing, dizziness, a racing or slow pulse, or an erection that does not go down.",
		howSure: "Each drug’s effects are known. The combination itself is a caution, not a large trial."
	},
	{
		id: "naloxone-opioid",
		groups: [{ ids: ["naloxone"] }, { classes: ["opioid"] }],
		severity: "major",
		title: "Naloxone pulls the opioid off, on purpose",
		plain: "{meds} — naloxone is the overdose rescue drug. In someone who depends on an opioid it causes sudden withdrawal. That is expected. It is not a reason to skip naloxone when breathing has stopped.",
		why: "Naloxone sits on the same receptors and knocks the opioid off within minutes. Pain medicines, methadone, and buprenorphine all lose their effect for a while.",
		whatToDo: "If someone will not wake or is barely breathing, give naloxone and call emergency services. Do not use it to cancel a dose so another opioid can be taken. After it wears off, the opioid can return — stay with the person.",
		notice: "Within minutes: yawning, sweating, vomiting, aches, anxiety, and a racing heart. Breathing should get deeper if this was an overdose.",
		howSure: "This is how naloxone is designed to work. It is on the Narcan label."
	},
	{
		id: "naltrexone-opioid",
		groups: [{ ids: ["naltrexone"] }, { classes: ["opioid"] }],
		severity: "major",
		title: "Naltrexone blocks opioids and can trigger withdrawal",
		plain: "{meds} — naltrexone is a blocker, not a painkiller. An opioid taken with it either does nothing or, if the person is dependent, throws them into withdrawal. It will not ‘take the edge off’ the opioid.",
		why: "Naltrexone occupies the opioid receptor for a long time, including the monthly shot. Pain medicines and buprenorphine cannot attach properly while it is there.",
		whatToDo: "Do not start naltrexone until a clinician has confirmed opioids are already out of the system. Do not add an opioid for pain on your own while taking it. Emergency care for severe withdrawal or for pain you cannot control.",
		notice: "Sudden sweating, vomiting, cramps, and agitation if an opioid is still in the body when naltrexone starts.",
		howSure: "This blockade is the reason the drug is prescribed. It is not a theoretical interaction."
	},
	{
		id: "bupe-full",
		groups: [{ classes: ["buprenorphine"] }, { classes: ["full_agonist"] }],
		severity: "major",
		title: "Buprenorphine can knock the other opioid off",
		plain: "{meds} — buprenorphine, including Suboxone, sticks harder than methadone, oxycodone, hydrocodone, morphine, or fentanyl. If one of those is already active, adding buprenorphine can cause sudden withdrawal instead of more relief.",
		why: "It is a partial opioid. It displaces a full opioid from the receptor and then only partly activates it. The result is withdrawal plus, later, two sedating drugs if both are continued.",
		whatToDo: "Do not add Suboxone, Subutex, or another buprenorphine product on top of a full opioid to ‘boost’ it. Switching is a clinic plan, not a same-day mix. Emergency care for collapse, severe vomiting, or slow breathing.",
		notice: "Sudden sweating, shaking, vomiting, and pain — withdrawal, not a better high. Sedation if both are kept going.",
		howSure: "This displacement is standard opioid pharmacology and a reason induction is supervised."
	},
	{
		id: "glp1-dup",
		groups: [{ classes: ["glp1"] }, { classes: ["glp1"] }],
		severity: "moderate",
		title: "Two GLP-1 medicines is one too many",
		plain: "{meds} do the same job. Two of them means more nausea, a stomach that empties even slower, and a higher chance of a low if insulin or glipizide is also in the picture.",
		why: "Ozempic, Wegovy, Mounjaro, Zepbound, Trulicity, Victoza, and exenatide are one family. The labels say not to combine GLP-1 products.",
		whatToDo: "Use one GLP-1 medicine, not two. Don’t overlap pens during a switch unless the prescriber wrote an exact stop date.",
		notice: "Worse nausea, vomiting, or constipation than on a single pen. Belly pain that does not stop needs a same-day call.",
		howSure: "Combining GLP-1 receptor agonists is advised against on the product labels."
	},
	{
		id: "ghs-stack",
		groups: [{ classes: ["ghs"] }, { classes: ["ghs"] }],
		severity: "moderate",
		title: "Two growth-hormone peptides stack the same signal",
		plain: "{meds} both ask the body for growth hormone. Together that means more water retention, more tingling in the hands, and a bigger push on blood sugar than either one alone.",
		why: "Sermorelin, tesamorelin, CJC-1295, ipamorelin, GHRP-2, GHRP-6, and hexarelin all raise growth hormone, even though the trigger differs.",
		whatToDo: "If a clinician is supervising one of them, don’t add a second research vial. Don’t raise the dose to chase a feeling. Swelling, severe headache, or sugars that won’t come down need a call.",
		notice: "Puffy hands, numb fingers, deeper sleepiness, or thirst and urination if sugar is rising.",
		howSure: "The hormone direction is real. Exact human trials of each research stack are not."
	},
	{
		id: "ghs-igf",
		groups: [{ classes: ["ghs"] }, { classes: ["igf"] }],
		severity: "moderate",
		title: "Growth hormone and IGF-1 amplify each other",
		plain: "{meds} — growth-hormone peptides raise IGF-1, and adding an IGF-1 product stacks that signal. Swelling, jaw and joint pain, and low blood sugar all become more likely.",
		why: "Growth hormone’s main messenger is IGF-1. Supplying both is not a small add-on.",
		whatToDo: "Don’t combine a research IGF-1 vial with a growth-hormone peptide on your own. Lows are treated with fast sugar. Confusion or a low you cannot treat is emergency care.",
		notice: "Shaking and sweating from a low, or swollen hands and joint pain over days.",
		howSure: "The pathway is standard endocrinology. Research-vial doses are not the Increlex label."
	},
	{
		id: "glp1-ghs",
		groups: [{ classes: ["glp1"] }, { classes: ["ghs"] }],
		severity: "moderate",
		title: "One peptide lowers sugar, the other can raise it",
		plain: "{meds} pull metabolism in opposite directions. The GLP-1 lowers appetite and blood sugar. The growth-hormone peptide tends to raise sugar and hold water.",
		why: "GLP-1 receptor agonists and growth hormone oppose each other on glucose. Research growth-hormone peptides are close enough that the clash still matters.",
		whatToDo: "Tell the diabetes prescriber before you add a growth-hormone peptide. Don’t ‘correct’ the scale by stacking both. Check sugar if you already monitor it.",
		notice: "Nausea from the GLP-1 plus puffy hands, or sugars that swing after the peptide starts.",
		howSure: "The glucose directions are established. A trial of this exact stack is not."
	},
	{
		id: "igf-insulin",
		groups: [{ classes: ["igf"] }, { classes: ["insulin"] }],
		severity: "major",
		title: "IGF-1 plus insulin can crash blood sugar",
		plain: "{meds} both move sugar into cells. Together the low can come on faster than insulin alone.",
		why: "IGF-1 uses pathways that overlap insulin. Increlex’s label warns about hypoglycemia. Research ‘LR3’ vials are not safer.",
		whatToDo: "Do not add IGF-1 to insulin without the diabetes clinician. Carry fast sugar. A low with confusion or a seizure is emergency care.",
		notice: "Sweating, shaking, sudden hunger, blurred vision, or sleepiness you cannot shake.",
		howSure: "Hypoglycemia is a labeled risk of mecasermin. The research analogs are an extra unknown, not a free pass."
	},
	{
		id: "igf-glp1",
		groups: [{ classes: ["igf"] }, { classes: ["glp1"] }],
		severity: "moderate",
		title: "Both can drop blood sugar and appetite",
		plain: "{meds} — a GLP-1 already lowers appetite and glucose. IGF-1 adds another hypoglycemia risk, especially if insulin is in the background.",
		why: "Different receptors, same practical result: less food in, more sugar pushed into tissues.",
		whatToDo: "Don’t stack a research IGF-1 product onto a GLP-1 pen. If sugar is monitored, check it more often for the first days.",
		notice: "Nausea plus shaking, sweating, or feeling too weak to eat.",
		howSure: "Each effect is known. The combination is an inference, not a labeled pair."
	},
	{
		id: "melanocortin-dup",
		groups: [{ classes: ["melanocortin"] }, { classes: ["melanocortin"] }],
		severity: "moderate",
		title: "Two melanocortin peptides stack nausea and pressure changes",
		plain: "{meds} hit the same receptor family. Nausea, flushing, blood-pressure swings, darkening of the skin, and spontaneous erections are more likely together than with one.",
		why: "Melanotan II, bremelanotide, setmelanotide, and afamelanotide are all melanocortin agonists, even though only some are approved and they are not interchangeable.",
		whatToDo: "Use one, not two. Don’t add Melanotan to Vyleesi, Imcivree, or Scenesse. An erection lasting more than four hours, chest pain, or fainting is emergency care.",
		notice: "Heavy nausea, flushing, a pounding or slow pulse, darkened moles, or an erection that will not settle.",
		howSure: "Shared receptor effects are real. These products were not studied as a stack."
	},
	{
		id: "healing-stack",
		groups: [{ classes: ["peptide_bleed"] }, { classes: ["peptide_bleed"] }],
		severity: "minor",
		title: "Two healing peptides, and clotting is still a question mark",
		plain: "{meds} are often stacked for recovery. Both have animal hints about bleeding time and almost no human studies. Together does not make the evidence stronger.",
		why: "BPC-157 and TB-500 are research chemicals. A rat finding is not a dosing guide for someone on warfarin, and it is not proof the pair is harmless.",
		whatToDo: "Tell a surgeon before a procedure. If you already bruise or bleed easily, don’t add both. Unusual bruising or black stools need a call.",
		notice: "Injection-site soreness is common. Spreading bruises are not something to ignore.",
		howSure: "This is a caution about missing evidence, not a proven clash."
	},
	{
		id: "amylin-insulin",
		groups: [{ classes: ["amylin"] }, { classes: ["insulin"] }],
		severity: "major",
		title: "Pramlintide plus insulin can cause a severe low",
		plain: "{meds} — pramlintide is taken with insulin on purpose, and the insulin dose usually has to come down. Leaving the old insulin dose in place is how severe lows happen.",
		why: "Pramlintide slows the stomach and lowers glucose after meals. The Symlin label requires an insulin reduction at the start.",
		whatToDo: "Don’t start it by copying a dose from the internet. Don’t mix it in the same syringe as insulin. Carry fast sugar. A low you cannot treat is emergency care.",
		notice: "Shaking, sweating, confusion, or nausea with a low that feels harder to correct because food is sitting in the stomach.",
		howSure: "This is a boxed-style warning on the pramlintide label."
	},
	{
		id: "amylin-glp1",
		groups: [{ classes: ["amylin"] }, { classes: ["glp1"] }],
		severity: "moderate",
		title: "Both slow the stomach",
		plain: "{meds} each delay stomach emptying. Together nausea is worse, and mealtime insulin becomes harder to time.",
		why: "Amylin analogs and GLP-1 medicines overlap on gastric emptying. That stack is generally avoided.",
		whatToDo: "Don’t add pramlintide on top of a GLP-1 unless a diabetes clinician is driving. Severe vomiting or a low you cannot eat through needs help.",
		notice: "Fullness that tips into vomiting, or a low that snacks don’t fix quickly.",
		howSure: "The overlap is pharmacologic. Many clinicians simply do not combine them."
	},
	{
		id: "desmopressin-sodium",
		groups: [{ classes: ["desmopressin"] }, { classes: [
			"ssri",
			"thiazide",
			"nsaid",
			"loop"
		] }],
		severity: "moderate",
		title: "Blood sodium can fall",
		plain: "{meds} — desmopressin tells the kidneys to hold water. SSRIs, NSAIDs, and water pills can also move sodium. Together the sodium drop is easier to miss until headache or confusion shows up.",
		why: "Hyponatremia is the serious desmopressin risk. Drugs that affect sodium or fluid add to it.",
		whatToDo: "Don’t drink extra ‘to be safe’ on a desmopressin night. Tell the prescriber about the other medicine. Confusion, a bad headache, or a seizure is emergency care.",
		notice: "Headache, nausea, confusion, or muscle cramps.",
		howSure: "Low sodium is a labeled desmopressin risk. The add-on drugs are known sodium movers."
	},
	{
		id: "octreotide-sugar",
		groups: [{ classes: ["somatostatin"] }, { classes: [
			"insulin",
			"sulfonylurea",
			"glp1"
		] }],
		severity: "moderate",
		title: "Octreotide can swing blood sugar either way",
		plain: "{meds} — octreotide can raise or lower glucose, so an insulin, glipizide, or GLP-1 plan that was stable can stop being stable.",
		why: "Somatostatin analogs suppress insulin and glucagon. The net effect on a given day is not predictable from the outside.",
		whatToDo: "Check sugar more often when octreotide starts or the dose changes. Don’t rewrite insulin doses alone. Severe lows or highs that won’t move need urgent care.",
		notice: "Shaking and sweating, or thirst and fatigue, without a change you can explain.",
		howSure: "Glucose disturbance is on the octreotide label."
	},
	{
		id: "octreotide-pulse",
		groups: [{ classes: ["somatostatin"] }, { classes: ["beta_blocker"] }],
		severity: "moderate",
		title: "The pulse can run slow",
		plain: "{meds} can both slow the heart rate. Together the pulse may drop further than on the beta blocker alone.",
		why: "Octreotide is associated with bradycardia. Beta blockers are prescribed to lower heart rate.",
		whatToDo: "Mention both to the prescriber. Fainting, chest pain, or a pulse that feels far too slow is urgent care.",
		notice: "Dizziness when you stand, fatigue, or a very slow pulse.",
		howSure: "Bradycardia is a known octreotide effect. The combination is a reasonable caution."
	},
	{
		id: "pth-digoxin",
		groups: [{ classes: ["pth_analog"] }, { classes: ["cardiac_glycoside"] }],
		severity: "moderate",
		title: "High calcium makes digoxin more dangerous",
		plain: "{meds} — teriparatide can raise blood calcium, and digoxin is more toxic when calcium is high.",
		why: "Digoxin toxicity is worsened by hypercalcemia. Teriparatide transiently raises serum calcium.",
		whatToDo: "The prescriber who manages digoxin should know about the bone shot. Nausea, vision halos, or a racing irregular pulse on digoxin is urgent care.",
		notice: "Loss of appetite, confusion, yellow-tinged vision, or palpitations.",
		howSure: "This is a labeled caution for teriparatide with digitalis."
	},
	{
		id: "gnrh-qt",
		groups: [{ classes: ["gnrh"] }, { classes: ["qt_risk"] }],
		severity: "moderate",
		title: "Two medicines that can stretch the heart’s rhythm",
		plain: "{meds} — leuprolide can prolong the QT interval, and so can the other medicine. The risk is an abnormal rhythm, not a stomach upset.",
		why: "Androgen-deprivation therapy has a QT warning. Adding another QT-prolonging drug is the combination cardiology watches.",
		whatToDo: "Ask before combining them. Fainting or a racing collapse is emergency care.",
		notice: "Sudden dizziness, fainting, or a fluttering chest.",
		howSure: "QT prolongation is on the leuprolide label. The size of the added risk depends on the other drug."
	},
	{
		id: "kisspeptin-gnrh",
		groups: [{ classes: ["kisspeptin"] }, { classes: ["gnrh"] }],
		severity: "moderate",
		title: "One peptide drives the hormone axis the other shuts down",
		plain: "{meds} work against each other. Kisspeptin stimulates the reproductive hormone signal. Leuprolide is used to turn that signal off.",
		why: "Kisspeptin sits upstream of GnRH. A GnRH agonist, after the first flare, suppresses that axis.",
		whatToDo: "Don’t add a research kisspeptin vial to Lupron or a similar shot. Fertility and cancer plans are specialist decisions.",
		notice: "Often no obvious feeling. Cycle changes, hot flashes, or a return of symptoms the shot was controlling are the clues.",
		howSure: "The pathway is established. Research kisspeptin products are not approved add-ons."
	},
	{
		id: "glp1-thyroid-absorb",
		groups: [{ classes: ["glp1"] }, { classes: ["thyroid"] }],
		severity: "minor",
		title: "The thyroid pill may absorb less steadily",
		plain: "{meds} — a GLP-1 slows the stomach, so levothyroxine can absorb on a different schedule than it used to.",
		why: "Levothyroxine absorption is sensitive to timing and gut transit. Delayed gastric emptying is the GLP-1 effect that matters here.",
		whatToDo: "Keep taking the thyroid pill the same way, on an empty stomach. Ask for a lab check after the GLP-1 dose has been stable. Don’t change the thyroid dose on your own.",
		notice: "Often nothing at first. Fatigue, feeling cold, or a racing heart later can mean the thyroid level moved.",
		howSure: "A reasonable absorption caution. It is not the same emergency as a low from insulin."
	},
	{
		id: "immune-steroid",
		groups: [{ classes: ["immune_peptide"] }, { classes: ["corticosteroid"] }],
		severity: "moderate",
		title: "A steroid can cancel an immune peptide",
		plain: "{meds} — thymosin alpha-1 and LL-37 are used to push immune signaling. Prednisone is used to suppress it. You can be paying for a peptide the steroid is shutting down.",
		why: "Glucocorticoids are broadly immunosuppressive. Immune peptides have not been shown to override a steroid course.",
		whatToDo: "Don’t add an immune peptide to a transplant, autoimmune, or chemotherapy plan unless that specialist agrees. Don’t stop the steroid to ‘let the peptide work.’",
		notice: "Often no clear feeling. The risk is the steroid plan being undermined, or the peptide doing nothing.",
		howSure: "The steroid effect is certain. Human trials of these peptides plus prednisone are not."
	},
	{
		id: "copper-zinc",
		groups: [{ classes: ["copper_peptide"] }, { classes: ["zinc"] }],
		severity: "minor",
		title: "Zinc and copper compete",
		plain: "{meds} — high-dose zinc blocks copper absorption. A copper peptide does not reliably fix that if the zinc dose stays high.",
		why: "Zinc induces a gut protein that traps copper. Long courses of zinc can lower copper stores.",
		whatToDo: "Don’t take large zinc doses for weeks without a reason. Separate them from mineral supplements the way you would iron and calcium. Skin creams are a smaller issue than oral zinc plus injections.",
		notice: "Usually nothing acute. Numbness, anemia, or poor wound healing are later copper-deficiency clues.",
		howSure: "Zinc-induced copper deficiency is well described. A GHK-Cu cream is a milder exposure than an injection."
	},
	{
		id: "lipolytic-glp1",
		groups: [{ classes: ["lipolytic"] }, { classes: ["glp1"] }],
		severity: "minor",
		title: "A fat-loss peptide on top of a GLP-1 is unstudied",
		plain: "{meds} — AOD-9604 and fragment 176-191 are not approved partners for Ozempic, Mounjaro, or the other GLP-1 pens. The GLP-1 already reduces appetite. The fragment adds an unknown, not a proven boost.",
		why: "There is no clinical trial of these research fragments with GLP-1 medicines.",
		whatToDo: "Don’t stack them to lose faster. Severe vomiting, signs of a low, or belly pain that stays need a clinician, not another vial.",
		notice: "Injection-site soreness, or the GLP-1’s usual nausea feeling worse.",
		howSure: "This is an absence of evidence, stated plainly."
	},
	{
		id: "mots-sugar",
		groups: [{ classes: ["metabolic_peptide"] }, { classes: [
			"insulin",
			"glp1",
			"sulfonylurea"
		] }],
		severity: "moderate",
		title: "MOTS-c plus a diabetes medicine is an unstudied sugar mix",
		plain: "{meds} — MOTS-c is studied for metabolism and is not an approved diabetes drug. Adding it to insulin, a GLP-1, or glipizide can move blood sugar in a way nobody has mapped for you.",
		why: "Mitochondrial peptides can affect glucose handling in lab work. That is not a dosing guide.",
		whatToDo: "Don’t add it to a diabetes plan quietly. If you already did, check sugar more often and tell the prescriber. A severe low is emergency care.",
		notice: "Shaking, sweating, or sugars that don’t match your usual pattern.",
		howSure: "Laboratory signals only. Treat the uncertainty as the warning."
	},
	{
		id: "nootropic-ssri",
		groups: [{ classes: ["nootropic_peptide"] }, { classes: ["ssri", "snri"] }],
		severity: "minor",
		title: "Selank or Semax plus an antidepressant is unstudied",
		plain: "{meds} — these research peptides are marketed for mood and focus. They have not been shown to be safe add-ons to an SSRI or SNRI, and they are not a reason to stop the prescription.",
		why: "Published human interaction data is thin. ‘Calming’ on a forum is not a serotonin study.",
		whatToDo: "Don’t stop sertraline, escitalopram, venlafaxine, or a similar medicine to start a peptide. New agitation, severe headache, or a mood crash needs the prescriber.",
		notice: "Headache, irritability, or a mood change that does not match your usual pattern on the antidepressant.",
		howSure: "Honestly weak evidence. The caution is that the mix is unstudied."
	},
	{
		id: "linaclotide-glp1",
		groups: [{ classes: ["gcc_agonist"] }, { classes: ["glp1"] }],
		severity: "minor",
		title: "One speeds the gut, the other slows the stomach",
		plain: "{meds} work on different parts of the gut. Linaclotide causes diarrhea. A GLP-1 slows the stomach and often constipates. Together the result is unpredictable, not a tidy cancel.",
		why: "They are not opposites that neutralize. Diarrhea and delayed stomach emptying can happen in the same week.",
		whatToDo: "Don’t use one to cancel the other. Dizziness with ongoing diarrhea, or vomiting that won’t stop, needs a call.",
		notice: "Cramping, loose stools, or the GLP-1 nausea feeling different than before.",
		howSure: "A practical gut caution, not a labeled contraindication."
	},
	{
		id: "glucagon-insulin",
		groups: [{ classes: ["glucagon"] }, { classes: ["insulin"] }],
		severity: "minor",
		title: "Glucagon is the rescue for insulin, not a second daily drug",
		plain: "{meds} belong together in a diabetes plan. Glucagon is for a severe low, when the person cannot swallow sugar. It is not a way to eat more or to take extra insulin.",
		why: "Glucagon raises blood sugar by telling the liver to release stored glucose. That rescue is why the kit is prescribed with insulin.",
		whatToDo: "Keep the kit, and teach someone nearby how to use it. After a rescue dose, get emergency care. The low can return. Don’t use glucagon on ordinary days.",
		notice: "Nausea and vomiting after a rescue dose are common. A low that comes back is the danger.",
		howSure: "This is how glucagon is labeled to be used."
	},
	{
		id: "calcitonin-lithium",
		groups: [{ classes: ["calcitonin"] }, { ids: ["lithium"] }],
		severity: "minor",
		title: "Calcitonin can lower lithium levels",
		plain: "{meds} — calcitonin may reduce lithium concentrations. A mood stabilizer that quietly drops is still a problem.",
		why: "Lithium loss has been reported with calcitonin. Lithium has a narrow range, so a small move matters.",
		whatToDo: "The psychiatrist should know before calcitonin starts. Don’t change the lithium dose because you feel ‘fine.’ Level checks are the tool.",
		notice: "Often no early symptom. A mood shift later can be the lithium level, not a new illness.",
		howSure: "Reported, not a guarantee it happens to everyone."
	}
];
var SEVERITY_RANK = {
	major: 0,
	moderate: 1,
	minor: 2
};
function matches(drug, matcher) {
	if (matcher.ids?.includes(drug.id)) return true;
	if (matcher.classes?.some((name) => drug.classes.includes(name))) return true;
	return false;
}
function enumerateTuples(rule, drugs) {
	const found = [];
	const used = /* @__PURE__ */ new Set();
	function walk(groupIndex, acc) {
		if (groupIndex === rule.groups.length) {
			found.push([...acc]);
			return;
		}
		const group = rule.groups[groupIndex];
		if (!group) return;
		for (const drug of drugs) {
			if (used.has(drug.id)) continue;
			if (!matches(drug, group)) continue;
			used.add(drug.id);
			acc.push(drug);
			walk(groupIndex + 1, acc);
			acc.pop();
			used.delete(drug.id);
		}
	}
	walk(0, []);
	const seen = /* @__PURE__ */ new Set();
	const unique = [];
	for (const tuple of found) {
		const key = tuple.map((drug) => drug.id).sort().join("+");
		if (seen.has(key)) continue;
		seen.add(key);
		unique.push([...tuple].sort((a, b) => a.generic.localeCompare(b.generic)));
	}
	return unique;
}
function covers(keeper, drop) {
	const ids = new Set(keeper.map((drug) => drug.id));
	return drop.every((drug) => ids.has(drug.id));
}
function fillTuples(template, tuples) {
	if (tuples.length === 1) return fill(template, tuples[0] ?? []);
	return template.replaceAll("{meds}", tuples[0]?.length === 2 ? "These pairs" : "These combinations");
}
function checkInteractions(drugs) {
	const hits = RULES.map((rule) => ({
		rule,
		tuples: enumerateTuples(rule, drugs)
	})).filter((hit) => hit.tuples.length > 0);
	const byId = new Map(hits.map((hit) => [hit.rule.id, hit]));
	for (const [keeperId, dropIds] of Object.entries(SUPPRESS_WHEN)) {
		const keeper = byId.get(keeperId);
		if (!keeper) continue;
		for (const dropId of dropIds) {
			const drop = byId.get(dropId);
			if (!drop) continue;
			drop.tuples = drop.tuples.filter((tuple) => !keeper.tuples.some((kept) => covers(kept, tuple)));
		}
	}
	const findings = hits.filter((hit) => hit.tuples.length > 0).map((hit) => {
		const pairs = hit.tuples.map((tuple) => tuple.map((drug) => drug.id));
		const drugIds = [...new Set(pairs.flat())];
		return {
			id: hit.rule.id,
			severity: hit.rule.severity,
			title: hit.rule.title,
			plain: fillTuples(hit.rule.plain, hit.tuples),
			why: fillTuples(hit.rule.why, hit.tuples),
			whatToDo: fillTuples(hit.rule.whatToDo, hit.tuples),
			notice: hit.rule.notice ? fillTuples(hit.rule.notice, hit.tuples) : void 0,
			howSure: hit.rule.howSure,
			pairs,
			drugIds
		};
	}).sort((a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity] || a.title.localeCompare(b.title));
	const counts = {
		major: 0,
		moderate: 0,
		minor: 0
	};
	for (const finding of findings) counts[finding.severity] += 1;
	return {
		findings,
		counts,
		highest: findings[0]?.severity ?? null
	};
}
function joinNames(names) {
	if (names.length === 0) return "";
	if (names.length === 1) return names[0] ?? "";
	if (names.length === 2) return `${names[0]} and ${names[1]}`;
	return `${names.slice(0, -1).join(", ")}, and ${names[names.length - 1]}`;
}
function fill(template, drugs) {
	return template.replaceAll("{meds}", joinNames(drugs.map((drug) => drug.generic)));
}
function summaryText(drugs, report) {
	const lines = [
		"Rx Mix — plain-language interaction check",
		"Educational only. Not medical advice and not a complete interaction database.",
		"",
		"On the list:",
		...drugs.map((drug) => {
			const brand = drug.brands[0];
			return brand ? `- ${drug.generic} (${brand})` : `- ${drug.generic}`;
		}),
		""
	];
	if (report.findings.length === 0) {
		lines.push("No interactions from our curated list between these items.");
		lines.push("That is not proof the combination is safe.");
	} else for (const finding of report.findings) {
		const label = finding.severity === "major" ? "SERIOUS" : finding.severity === "moderate" ? "WORTH A CONVERSATION" : "SMALLER NOTE";
		lines.push(`${label}: ${finding.title}`);
		for (const pair of finding.pairs) {
			const names = pair.map((id) => DRUG_BY_ID.get(id)?.generic ?? id);
			lines.push(names.join(" + "));
		}
		lines.push(finding.plain);
		if (finding.notice) lines.push(`What you might notice: ${finding.notice}`);
		lines.push(`What to do: ${finding.whatToDo}`);
		if (finding.howSure) lines.push(`How solid this is: ${finding.howSure}`);
		lines.push("");
	}
	lines.push("Confirm with a pharmacist or the clinician who prescribes these before changing any medicine.");
	return lines.join("\n");
}
function norm(value) {
	return value.toLowerCase().replace(/['’.]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
}
var INDEX = DRUGS.map((drug) => {
	return {
		drug,
		generic: norm(drug.generic),
		brands: drug.brands.map(norm),
		aliases: drug.aliases.map(norm),
		hay: norm([
			drug.generic,
			drug.bucket,
			drug.usedFor,
			...drug.brands,
			...drug.aliases
		].join(" "))
	};
});
function searchDrugs(raw, limit = 8) {
	const query = norm(raw);
	if (!query) return [];
	return INDEX.map((row) => {
		let score = 0;
		if (row.generic === query) score = 100;
		else if (row.generic.startsWith(query)) score = 86;
		else if (row.brands.some((brand) => brand === query || brand.startsWith(query))) score = 80;
		else if (row.aliases.some((alias) => alias === query || alias.startsWith(query))) score = 74;
		else if (query.length >= 2 && row.generic.includes(query)) score = 64;
		else if (query.length >= 2 && row.brands.some((brand) => brand.includes(query))) score = 58;
		else if (query.length >= 2 && row.aliases.some((alias) => alias.includes(query))) score = 52;
		else if (query.length >= 3 && row.hay.includes(query)) score = 30;
		return {
			drug: row.drug,
			score
		};
	}).filter((row) => row.score > 0).sort((a, b) => b.score - a.score || a.drug.generic.localeCompare(b.drug.generic)).slice(0, limit).map((row) => row.drug);
}
var BY_ID = {
	methadone: [
		"Constipation, sweating, and sleepiness.",
		"A dose can feel stronger days later if another medicine changes how it is cleared.",
		"Serious: slow or stopped breathing, especially with alcohol, benzodiazepines, or sleep medicines.",
		"Serious: a stretched heart rhythm — fainting or a racing collapse.",
		"Itching and low testosterone with long use.",
		"Do not stop suddenly. Withdrawal is miserable and can be dangerous if you try to replace it on your own."
	],
	amiodarone: [
		"Nausea, sun sensitivity, and a blue-gray skin tint with long use.",
		"Thyroid tests can swing high or low.",
		"Serious: lung inflammation — cough or shortness of breath that is new.",
		"Serious: liver injury and a slowed or irregular heartbeat.",
		"Corneal deposits that usually do not change vision much.",
		"It stays in the body for months after the last dose."
	],
	digoxin: [
		"Nausea, loss of appetite, and fatigue.",
		"Visual halos or yellow-tinged vision.",
		"Serious: a slow or irregular pulse, confusion, or fainting — toxicity, especially if potassium is low.",
		"Kidney function changes the dose you can clear."
	],
	lithium: [
		"Thirst, extra urination, tremor, and nausea.",
		"Weight gain and acne or a dull hair texture.",
		"Thyroid and kidney tests need to be watched.",
		"Serious: toxicity — worsening tremor, confusion, vomiting, or a clumsy walk. Dehydration and NSAIDs make this easier."
	],
	methotrexate: [
		"Nausea, mouth sores, and fatigue after a dose.",
		"Sun sensitivity.",
		"Serious: bone-marrow suppression, liver injury, and lung inflammation.",
		"Folic acid is often prescribed with it. Extra folate from a multivitamin is not always the same plan.",
		"Serious: a rash with fever or trouble breathing."
	],
	warfarin: [
		"Bruising and bleeding from the gums or nose.",
		"Serious: black stools, vomiting blood, a sudden severe headache, or bleeding that will not stop.",
		"The INR moves with diet, antibiotics, and many other medicines.",
		"Vitamin K foods don’t have to be banned. They have to stay steady."
	],
	prednisone: [
		"Hunger, mood change, and broken sleep.",
		"Higher blood sugar and higher blood pressure.",
		"Stomach irritation, especially with an NSAID.",
		"Serious: don’t stop a long course suddenly. The body needs a taper.",
		"With weeks of use: thinner skin, easier bruising, and bone loss."
	],
	levothyroxine: [
		"If the dose is high: a racing heart, tremor, sweating, and poor sleep.",
		"If the dose is low: fatigue, feeling cold, and weight that creeps up.",
		"Absorption drops with coffee, calcium, iron, and some stomach medicines.",
		"Serious: chest pain or a heart rhythm that feels new, especially in older adults."
	],
	metformin: [
		"Loose stools, gas, and a metal taste, often early on.",
		"Nausea if it is taken without food.",
		"Serious: lactic acidosis is rare — deep fatigue, unusual muscle pain, and trouble breathing, mostly when the kidneys are failing or you are very dehydrated.",
		"Long use can lower vitamin B12."
	],
	bupropion: [
		"Dry mouth, insomnia, and headache.",
		"Appetite often drops.",
		"Serious: seizures, more likely at high doses or with an eating disorder or alcohol withdrawal.",
		"Anxiety can feel louder in the first weeks."
	],
	lamotrigine: [
		"Dizziness, headache, and double vision when the dose climbs fast.",
		"Serious: a rash that blisters or involves the mouth or eyes — stop and get urgent care. Slow dose increases are how that risk is reduced.",
		"Nausea."
	],
	carbamazepine: [
		"Dizziness, drowsiness, and nausea.",
		"Low sodium — headache and confusion.",
		"Serious: a severe rash, low blood counts, and liver injury.",
		"It speeds up the liver and can make many other medicines weaker."
	],
	naloxone: [
		"Sudden withdrawal if an opioid is on board: sweating, vomiting, aches, agitation.",
		"A racing heart and higher blood pressure for a short time.",
		"The opioid can return when naloxone wears off.",
		"Using it in an overdose is correct even though withdrawal follows."
	],
	naltrexone: [
		"Nausea, headache, and fatigue, especially early.",
		"Injection-site reactions with the monthly shot.",
		"Serious: precipitated withdrawal if an opioid is still in the body when it starts.",
		"Liver enzymes are sometimes watched.",
		"Ordinary opioid pain medicines will not work while it is active."
	],
	kratom: [
		"Nausea, constipation, and sweating.",
		"Stimulation at some doses and sedation at others.",
		"Serious: slowed breathing with opioids, benzodiazepines, or alcohol.",
		"Dependence and a withdrawal syndrome of its own.",
		"Products are not dose-standardized."
	],
	alcohol: [
		"Sleepiness, poor coordination, and nausea.",
		"Serious: slowed breathing with opioids, benzodiazepines, and sleep medicines.",
		"Stomach bleeding is easier with NSAIDs.",
		"Liver injury with daily heavy use, and a harder time with acetaminophen."
	],
	semaglutide: [
		"Nausea, vomiting, constipation, or diarrhea, worse after a dose increase.",
		"A stomach that feels full for hours.",
		"Serious: severe steady belly pain — pancreatitis or gallbladder disease until proven otherwise.",
		"Serious: a low if you also use insulin or a sulfonylurea.",
		"Injection-site redness.",
		"Rodent thyroid-tumor warning on the label. A neck mass or trouble swallowing needs a clinician."
	],
	tirzepatide: [
		"Nausea, diarrhea, constipation, and less appetite.",
		"Serious: gallbladder pain and pancreatitis symptoms — belly pain that stays.",
		"Serious: lows when combined with insulin or glipizide.",
		"Birth-control pills can be less reliable for 4 weeks after a start or a dose increase.",
		"Injection-site reactions."
	],
	liraglutide: [
		"Nausea and a slower stomach, especially while the daily dose climbs.",
		"Constipation or diarrhea.",
		"Serious: persistent severe belly pain.",
		"Serious: lows with insulin or a sulfonylurea.",
		"Injection-site redness."
	],
	dulaglutide: [
		"Nausea, diarrhea, and decreased appetite.",
		"Fatigue early on.",
		"Serious: severe abdominal pain, vomiting that will not stop.",
		"Serious: lows if insulin or glipizide is also used."
	],
	exenatide: [
		"Nausea, especially with the twice-daily form.",
		"Injection-site bumps with the weekly form.",
		"Serious: not for severe kidney disease. Vomiting and dehydration can worsen the kidneys.",
		"Serious: pancreatitis symptoms — pain that bores through to the back."
	],
	"bpc-157": [
		"Injection-site pain and redness. Oral products are a different unknown.",
		"Headache and dizziness are described, not proven rates.",
		"Serious: human side-effect studies are basically missing. Purity of research vials varies.",
		"Bleeding changes are an animal finding, not a human guarantee."
	],
	"tb-500": [
		"Injection-site irritation and fatigue are the reports people repeat.",
		"Head rush or lightheadedness in some descriptions.",
		"Serious: not an approved drug. Contamination and wrong dose are part of the risk.",
		"Effects on clotting in people are unknown."
	],
	ipamorelin: [
		"Water retention and tingling in the fingers.",
		"Hunger is usually milder than with GHRP-6.",
		"Flushing right after a dose.",
		"Higher blood sugar with ongoing use.",
		"Serious: research vials are not dose-standardized."
	],
	"cjc-1295": [
		"Flushing, warmth, and a head rush after injection.",
		"Water retention and deeper sleepiness.",
		"Tingling in the hands.",
		"Serious: stacking it with other growth-hormone peptides multiplies those effects."
	],
	tesamorelin: [
		"Injection-site redness and itching.",
		"Joint pain, muscle aches, and swelling in the legs.",
		"Serious: worse glucose control.",
		"Serious: allergic reactions, including rash."
	],
	"ghrp-2": [
		"A strong hunger surge.",
		"Flushing and water retention.",
		"Higher prolactin and cortisol than ipamorelin.",
		"Tingling hands and higher blood sugar with repeated use."
	],
	"ghrp-6": [
		"Intense hunger soon after a dose.",
		"Water retention and tingling.",
		"Flushing.",
		"Blood sugar can drift up.",
		"Serious: unapproved. Dose on the vial may be wrong."
	],
	hexarelin: [
		"Flushing, hunger, and a warm face.",
		"Water retention and cortisol rise.",
		"The growth-hormone pulse can fade if it is used every day for a long stretch.",
		"Serious: research chemical, not a pharmacy product."
	],
	sermorelin: [
		"Flushing, headache, and injection-site pain.",
		"Water retention and tingling in the hands.",
		"Blood sugar can rise.",
		"Serious: allergic reactions are possible with any peptide injection."
	],
	"igf-1": [
		"Serious: low blood sugar, including at night.",
		"Jaw pain, joint pain, and swelling.",
		"Injection-site reactions.",
		"Headache.",
		"Serious: research ‘LR3’ vials are not the approved Increlex product."
	],
	"aod-9604": [
		"Injection-site redness.",
		"Headache and fatigue in anecdotal reports.",
		"Serious: human safety data at the doses sold online are poor."
	],
	"frag-176": [
		"Injection-site pain.",
		"Fatigue.",
		"Serious: not an approved drug, and side-effect rates in people are not established."
	],
	"thymosin-alpha-1": [
		"Injection-site redness and fatigue.",
		"Muscle aches.",
		"Serious: do not assume it is neutral if your immune system is being deliberately suppressed."
	],
	"ghk-cu": [
		"Skin irritation or stinging with creams.",
		"Injection-site pain if it is injected.",
		"Serious: injected copper peptides are not the same risk as a face cream."
	],
	kpv: [
		"Injection or capsule side effects are not well measured in people.",
		"Local irritation.",
		"Serious: unknown purity and unknown interactions are the main risks."
	],
	"ll-37": [
		"Injection-site inflammation.",
		"Flushing.",
		"Serious: tissue irritation. It is not an approved antibiotic."
	],
	melanotan: [
		"Nausea, flushing, and yawning after a dose.",
		"Darkening of moles and new freckles.",
		"Spontaneous erections.",
		"Appetite loss.",
		"Serious: blood-pressure swings and a mole that changes shape or color.",
		"Serious: unapproved. Contamination is common in this market."
	],
	bremelanotide: [
		"Nausea, flushing, and headache.",
		"Injection-site reactions.",
		"A temporary rise in blood pressure and a slower pulse.",
		"Darkening of the gums and skin of the face with repeated use.",
		"Serious: not for uncontrolled high blood pressure or known heart disease."
	],
	setmelanotide: [
		"Injection-site reactions and nausea.",
		"Darkening of the skin.",
		"Spontaneous erections or sexual arousal.",
		"Serious: new or worsening depression and suicidal thoughts — on the label."
	],
	afamelanotide: [
		"Nausea, headache, and fatigue.",
		"Darkening of moles and freckles.",
		"Implant-site reactions.",
		"Serious: a changing mole still needs a skin exam."
	],
	pramlintide: [
		"Serious: severe hypoglycemia with insulin, especially in the first weeks.",
		"Nausea, vomiting, and less appetite.",
		"Headache.",
		"Injection-site redness.",
		"Do not mix in the same syringe as insulin."
	],
	glucagon: [
		"Nausea and vomiting after a rescue dose.",
		"Headache and a fast pulse.",
		"Higher blood sugar afterward, then a possible second low.",
		"Serious: it does not replace emergency care after a severe low."
	],
	desmopressin: [
		"Headache and nausea.",
		"Serious: low blood sodium — confusion, a severe headache, seizure.",
		"Stuffy nose with the nasal forms.",
		"Fluid retention and weight that jumps from water."
	],
	octreotide: [
		"Diarrhea, belly cramps, and gas, especially at the start.",
		"Gallstones and slow gallbladder emptying.",
		"Blood sugar up or down.",
		"Serious: a slow heartbeat.",
		"Injection-site pain."
	],
	teriparatide: [
		"Dizziness and a fast pulse in the minutes after the shot.",
		"Leg cramps and nausea.",
		"Serious: high blood calcium — thirst, constipation, confusion.",
		"Joint aches."
	],
	leuprolide: [
		"Hot flashes and sweating.",
		"Mood change, lower interest in sex, and headache.",
		"Bone loss with longer use.",
		"A short-term hormone flare when it starts.",
		"Serious: QT prolongation — fainting or a racing collapse.",
		"Injection-site reactions."
	],
	oxytocin: [
		"Nausea and vomiting.",
		"Serious: contractions that are too strong or too close together when used in labor.",
		"Water retention and low sodium if fluids are not watched.",
		"A fast or slow heart rate."
	],
	calcitonin: [
		"Nasal irritation, dryness, and nosebleeds with the spray.",
		"Nausea and flushing with the injection.",
		"Serious: allergic reactions, including with salmon calcitonin."
	],
	linaclotide: [
		"Diarrhea, often in the first weeks.",
		"Belly pain and gas.",
		"Serious: severe diarrhea with dizziness or dehydration.",
		"Not for young children."
	],
	kisspeptin: [
		"Flushing and a warm feeling in study settings.",
		"Headache.",
		"Serious: research products are not an approved fertility medicine. Hormone effects outside a study are unpredictable."
	],
	selank: [
		"Fatigue and nasal irritation with sprays.",
		"Drowsiness.",
		"Serious: not a proven replacement for a prescribed anxiety medicine."
	],
	semax: [
		"Headache and irritability.",
		"Nasal irritation.",
		"Serious: combination data with antidepressants are missing."
	],
	epitalon: [
		"Injection-site soreness.",
		"Sleep changes are claimed more often than they are measured.",
		"Serious: human side-effect rates are not established."
	],
	"mots-c": [
		"Injection-site redness.",
		"Fatigue.",
		"Serious: effects on blood sugar in people taking diabetes drugs are unstudied."
	],
	ondansetron: [
		"Headache and constipation.",
		"Fatigue.",
		"Serious: a stretched heart rhythm, more likely with higher doses or low potassium."
	],
	metronidazole: [
		"A metal taste and nausea.",
		"Dark urine.",
		"Serious: severe vomiting if you drink alcohol during treatment and for a few days after.",
		"Numbness in the hands or feet with long courses."
	],
	"smx-tmp": [
		"Nausea and sun sensitivity.",
		"Serious: rash — a blistering rash is emergency care.",
		"Higher potassium and lower blood counts.",
		"Kidney numbers can move if you are dehydrated."
	],
	rifampin: [
		"Orange-red urine, sweat, and tears. That part is expected.",
		"Nausea and flu-like feelings.",
		"Serious: liver injury.",
		"It makes many other medicines, including birth control, much weaker."
	]
};
var BY_CLASS = {
	acei: [
		"A dry cough that can start weeks in.",
		"Dizziness when you stand, especially after the first doses.",
		"Higher potassium.",
		"Serious: swelling of the face, tongue, or throat — stop and get emergency care.",
		"Not for pregnancy.",
		"Kidney numbers can move, especially if you are dehydrated or on an NSAID."
	],
	arb: [
		"Dizziness and fatigue.",
		"Higher potassium.",
		"Serious: kidney function can drop if you are dehydrated or also taking an NSAID.",
		"Not for pregnancy.",
		"Cough is less common than with lisinopril-type drugs, but not impossible."
	],
	ccb_dhp: [
		"Ankle swelling and flushing.",
		"Headache and a racing feeling.",
		"Gum tenderness with longer use.",
		"Dizziness."
	],
	ccb_nondhp: [
		"Constipation, more with verapamil.",
		"A slower pulse.",
		"Dizziness and swollen ankles.",
		"Serious: a pulse that is too slow, or worse heart failure symptoms."
	],
	beta_blocker: [
		"Fatigue, cold hands, and a slower pulse.",
		"Sleep changes and, with some of them, vivid dreams.",
		"Can hide a fast heartbeat that would have warned you of a low blood sugar.",
		"Serious: don’t stop suddenly. Chest pain can rebound.",
		"Wheezing in people with significant asthma."
	],
	thiazide: [
		"Extra urination, then thirst.",
		"Low potassium and low sodium.",
		"Higher uric acid — gout flares.",
		"Higher blood sugar and sun sensitivity.",
		"Dizziness on standing."
	],
	loop: [
		"Heavy urination soon after a dose.",
		"Low potassium, low magnesium, and cramps.",
		"Dizziness and dehydration.",
		"Serious: ringing in the ears at high doses.",
		"Gout flares."
	],
	k_sparing: [
		"Breast tenderness or enlargement.",
		"Higher potassium.",
		"Irregular periods.",
		"Dizziness.",
		"Serious: dangerous potassium levels if combined with ACE inhibitors, ARBs, or potassium supplements."
	],
	nitrate: [
		"Headache, flushing, and dizziness.",
		"A drop in blood pressure when you stand.",
		"Serious: collapse if combined with sildenafil, tadalafil, or similar erection medicines."
	],
	statin: [
		"Muscle aches.",
		"Headache and mild nausea.",
		"Serious: severe muscle pain with dark urine — a rare muscle breakdown.",
		"Liver enzymes sometimes rise.",
		"Blood sugar can creep up."
	],
	doac: [
		"Bruising and bleeding that lasts longer.",
		"Serious: black stools, vomiting blood, a sudden severe headache, or a fall with a blow to the head.",
		"Stomach upset with some of them.",
		"Kidney function changes the safe dose for several of these drugs."
	],
	antiplatelet: [
		"Easier bruising and nosebleeds.",
		"Stomach upset.",
		"Serious: bleeding in the gut or brain, especially with an NSAID or another blood thinner.",
		"Aspirin can worsen asthma in some people."
	],
	nsaid: [
		"Heartburn and stomach pain.",
		"Fluid retention and higher blood pressure.",
		"Serious: stomach bleeding — black stools or vomiting blood.",
		"Serious: kidney injury if you are dehydrated or on blood-pressure medicine.",
		"Higher clot risk with long daily use of some NSAIDs."
	],
	analgesic: [
		"Usually well tolerated at labeled doses.",
		"Serious: liver injury when the daily maximum is passed, including hidden doses in cold and opioid combination pills.",
		"A rash is uncommon but a reason to stop."
	],
	opioid: [
		"Constipation, nausea, and itch.",
		"Sleepiness and slowed thinking.",
		"Serious: slow or stopped breathing, especially with alcohol, benzodiazepines, or sleep medicines.",
		"Dependence and withdrawal if stopped suddenly after regular use.",
		"Low testosterone and low drive with long use."
	],
	biguanide: [
		"Diarrhea, gas, and nausea.",
		"A metallic taste.",
		"Serious: rare lactic acidosis when the kidneys are failing or you are severely dehydrated.",
		"Lower vitamin B12 over years."
	],
	sulfonylurea: [
		"Serious: low blood sugar — sweating, shaking, confusion.",
		"Hunger and weight gain.",
		"Nausea.",
		"A sulfa allergy does not always predict a reaction, but mention it."
	],
	insulin: [
		"Serious: low blood sugar — sweating, shaking, confusion, seizure.",
		"Weight gain.",
		"Injection-site lumps if you use the same spot.",
		"Low potassium at high doses."
	],
	ssri: [
		"Nausea, headache, and looser stools in the first weeks.",
		"Lower sex drive, delayed orgasm, and sleep change.",
		"More anxiety before it settles.",
		"Serious: new suicidal thoughts in younger people — the early weeks need a check-in.",
		"Serious: agitation, fever, and confusion if stacked with other serotonin drugs.",
		"Don’t stop suddenly. Dizziness and ‘brain zaps’ are common."
	],
	snri: [
		"Nausea, sweating, and a faster pulse.",
		"Higher blood pressure.",
		"Sexual side effects and insomnia.",
		"Serious: don’t stop suddenly. Withdrawal is often rougher than with SSRIs.",
		"Serious: serotonin toxicity if combined with an MAOI or other strong serotonin drugs."
	],
	ndri: [
		"Dry mouth, insomnia, and headache.",
		"Appetite loss.",
		"Serious: seizure risk at high doses.",
		"Anxiety can increase."
	],
	sari: [
		"Sleepiness and next-day grogginess.",
		"Dizziness and a dry mouth.",
		"Serious: a prolonged erection — emergency care if it lasts more than four hours.",
		"Nasal congestion."
	],
	benzo: [
		"Sleepiness, poor memory, and slower reflexes.",
		"Unsteady walking, especially in older adults.",
		"Serious: slowed breathing with opioids, alcohol, or sleep medicines.",
		"Dependence. Stopping suddenly after regular use can cause seizures."
	],
	zd: [
		"Sleepiness and a bitter taste.",
		"Doing things at night you don’t remember, including driving.",
		"Serious: slowed breathing with opioids or alcohol.",
		"Rebound insomnia if stopped abruptly."
	],
	gabapentinoid: [
		"Dizziness, swelling in the legs, and sleepiness.",
		"Weight gain and blurred vision.",
		"Serious: slowed breathing with opioids.",
		"Withdrawal — anxiety and insomnia — if stopped suddenly."
	],
	maoi: [
		"Dizziness, insomnia, and weight gain.",
		"Serious: a blood-pressure crisis with aged cheeses, cured meats, tap beer, and many decongestants.",
		"Serious: serotonin toxicity with SSRIs, and the washout gap is measured in weeks.",
		"Sexual side effects."
	],
	inducer: [
		"Dizziness and drowsiness.",
		"Nausea.",
		"Serious: it makes many other medicines, including birth control and some blood thinners, weaker.",
		"Low sodium and, with carbamazepine, a severe rash."
	],
	anticonvulsant: [
		"Dizziness, blurred vision, and headache.",
		"Nausea.",
		"Serious: rash — with lamotrigine a blistering rash is an emergency.",
		"Mood changes."
	],
	penicillin: [
		"Diarrhea and nausea.",
		"Yeast infections.",
		"Serious: rash, swelling, or trouble breathing — allergy. A rash is not always a true allergy, but it needs a clinician to sort out."
	],
	macrolide: [
		"Nausea, belly pain, and diarrhea.",
		"A metallic taste.",
		"Serious: a stretched heart rhythm with some of them, especially if you already take a QT medicine.",
		"Clarithromycin raises levels of many other drugs."
	],
	fluoroquinolone: [
		"Nausea and diarrhea.",
		"Serious: tendon pain or rupture, especially with steroids or in older adults.",
		"Serious: nerve pain, confusion, and blood-sugar swings.",
		"Sun sensitivity.",
		"Separate from calcium, iron, magnesium, and zinc or it will not absorb."
	],
	tetracycline: [
		"Stomach upset and heartburn if you lie down too soon.",
		"Sunburn much more easily.",
		"Serious: not for pregnancy or young children — tooth and bone staining.",
		"Separate from dairy, iron, calcium, and zinc."
	],
	antibiotic: [
		"Nausea and diarrhea.",
		"Yeast overgrowth.",
		"Serious: rash with fever, or trouble breathing.",
		"Some antibiotics make other medicines stronger or weaker. The pair result is the place to look."
	],
	ppi: [
		"Headache and diarrhea or constipation.",
		"Low magnesium with long use.",
		"Higher risk of gut infections and of fractures with years of use.",
		"Vitamin B12 can fall over a long stretch."
	],
	thyroid: [
		"Too much: tremor, racing heart, sweating, insomnia.",
		"Too little: fatigue, cold, constipation.",
		"Serious: chest pain or a new rhythm problem if the dose is high.",
		"Absorption is easy to block with minerals and coffee."
	],
	corticosteroid: [
		"Hunger, mood swings, and insomnia.",
		"Higher sugar and higher blood pressure.",
		"Stomach irritation.",
		"Serious: don’t stop a long course suddenly.",
		"Bone loss, thin skin, and easier infection with longer use."
	],
	coc: [
		"Nausea, breast tenderness, and spotting.",
		"Mood change and headache.",
		"Serious: blood clots, stroke, and higher blood pressure — risk is higher with smoking and migraine with aura.",
		"Not the same as a progestin-only pill."
	],
	bisphosphonate: [
		"Heartburn and esophagus irritation if it is not taken upright with plain water.",
		"Muscle and joint aches.",
		"Serious: jaw bone problems after dental surgery, rare, more with IV forms and cancer doses.",
		"Low calcium if vitamin D is missing."
	],
	saba: [
		"Tremor, a fast pulse, and nervousness.",
		"Throat irritation.",
		"Serious: needing it more and more means the asthma plan is failing, not that you need endless puffs."
	],
	ltra: [
		"Headache and stomach pain.",
		"Serious: mood and sleep changes, including agitation and suicidal thoughts — on the montelukast warning.",
		"Usually no daytime sleepiness."
	],
	antihistamine: [
		"Dry mouth and mild headache with the non-drowsy ones.",
		"The older ones: heavy sleepiness, confusion in older adults, and a next-day hangover.",
		"Trouble urinating if the prostate is enlarged, with diphenhydramine."
	],
	decongestant: [
		"A racing heart, higher blood pressure, and insomnia.",
		"Jitteriness.",
		"Serious: avoid with MAOIs. Chest pain or a severe headache is emergency care."
	],
	pde5: [
		"Headache, flushing, and a stuffy nose.",
		"Indigestion and a blue tinge to vision with sildenafil.",
		"Back pain with some of them.",
		"Serious: an erection lasting more than four hours.",
		"Serious: a dangerous pressure drop with nitrates."
	],
	alpha_blocker: [
		"Dizziness when you stand, especially the first dose.",
		"Stuffy nose and less semen at ejaculation.",
		"Serious: fainting if combined with an erection medicine too close together."
	],
	triptan: [
		"Chest or neck tightness that is often harmless but should be described to a clinician the first time.",
		"Tingling, dizziness, and drowsiness.",
		"Serious: don’t stack with an MAOI or with another triptan the same day.",
		"Serious: stroke symptoms — one-sided weakness or speech trouble — are emergency care, not a migraine to sleep off."
	],
	"5ht3": [
		"Constipation and headache.",
		"Fatigue.",
		"Serious: a stretched heart rhythm at higher doses, more likely if potassium is low or another QT drug is on board."
	],
	potassium: ["Nausea and stomach upset.", "Serious: too much potassium — weakness and a slow irregular pulse, especially with ACE inhibitors, ARBs, or spironolactone."],
	polyvalent: [
		"Stomach upset and constipation, depending on the mineral.",
		"Blocks absorption of ciprofloxacin, levofloxacin, and doxycycline if taken together.",
		"High doses of one mineral can crowd out another."
	],
	zinc: [
		"Nausea and a metal taste, especially on an empty stomach.",
		"Serious: weeks of high doses lower copper.",
		"Don’t take it in the same window as quinolone or tetracycline antibiotics."
	],
	vitamin: ["Usually tolerated at ordinary doses.", "High doses are not automatically safer and can interact — vitamin K with warfarin, vitamin C with kidney stones in some people."],
	glp1: [
		"Nausea, vomiting, constipation, or diarrhea.",
		"A stomach that stays full.",
		"Serious: severe belly pain that does not stop.",
		"Serious: low blood sugar if insulin or a sulfonylurea is also used.",
		"Injection-site redness."
	],
	ghs: [
		"Flushing and a warm face after a dose.",
		"Water retention and tingling in the hands.",
		"Hunger with the ghrelin-mimics.",
		"Blood sugar can rise.",
		"Serious: research vials are not pharmacy-grade unless the product is actually tesamorelin from a pharmacy."
	],
	peptide: [
		"Injection-site pain and redness.",
		"Headache and fatigue are commonly described.",
		"Serious: many of these are not approved drugs. Side-effect lists from forums are not a label."
	],
	fq: [
		"Nausea and diarrhea.",
		"Serious: tendon pain or rupture, especially with steroids or in older adults.",
		"Serious: nerve pain, confusion, and blood-sugar swings.",
		"Sun sensitivity.",
		"Separate from calcium, iron, magnesium, and zinc or it will not absorb."
	],
	sulfa: [
		"Nausea and sun sensitivity.",
		"Serious: rash, including rare blistering rashes.",
		"Higher potassium.",
		"Kidney irritation if fluid intake is poor."
	],
	nitroimidazole: [
		"Metallic taste and nausea.",
		"Serious: alcohol during treatment can cause severe flushing and vomiting.",
		"Headache."
	],
	dxm: [
		"Drowsiness and dizziness.",
		"Serious: agitation, fever, and confusion with antidepressants that raise serotonin, especially MAOIs.",
		"Not a ‘harmless’ high. High doses are dangerous."
	],
	fishoil: [
		"Fishy burps and loose stools.",
		"Mild extra bruising at high doses.",
		"Usually no dramatic effect at ordinary supplement doses."
	],
	ginkgo: [
		"Headache and stomach upset.",
		"Easier bleeding, which matters with warfarin, aspirin, or surgery.",
		"Serious: bleeding is the reason to stop it before a procedure."
	],
	stjohns: [
		"Stomach upset and sun sensitivity.",
		"Serious: it makes many prescriptions weaker, including birth control, transplant drugs, and some antidepressants.",
		"Serious: serotonin toxicity with SSRIs."
	],
	grapefruit: [
		"By itself, a serving is food.",
		"It can raise levels of some statins, calcium-channel blockers, and other drugs for more than a day.",
		"A one-time glass is a smaller issue than grapefruit every morning."
	],
	vitamin_c: [
		"Loose stools and cramps at high doses.",
		"Kidney stones are a concern for some people at very high doses.",
		"Ordinary dietary amounts are rarely a problem."
	],
	vitamin_d: ["Usually none at standard doses.", "Serious: too much raises calcium — thirst, constipation, confusion, kidney stones."],
	vitamin_k: ["Usually none at supplement doses.", "Serious: it reverses warfarin. The dose of vitamin K in a multivitamin still counts."],
	vitamin_b12: [
		"Usually none by mouth.",
		"Injection-site soreness if injected.",
		"Acne-like rash in some people on high doses."
	],
	probiotic: [
		"Gas and bloating at the start.",
		"Serious: people with central lines or severely weakened immunity can rarely get a bloodstream infection from live cultures.",
		"Antibiotics can kill the probiotic if you take them at the same moment."
	],
	iron: [
		"Constipation, dark stools, and nausea.",
		"Serious: overdose is dangerous, especially for children.",
		"Separate from thyroid medicine and from ciprofloxacin, levofloxacin, and doxycycline."
	],
	calcium: [
		"Constipation and a chalky taste.",
		"Serious: too much calcium — thirst, confusion, kidney stones.",
		"Blocks thyroid medicine and several antibiotics if taken together."
	],
	magnesium: [
		"Loose stools, especially oxide and citrate.",
		"Sleepiness at higher doses.",
		"Serious: too much is dangerous when the kidneys are failing.",
		"Separate from quinolone and tetracycline antibiotics."
	],
	qt_risk: ["Nausea or headache, depending on the drug.", "Serious: a stretched heart rhythm — fainting or a racing collapse, more likely if another QT medicine is added or potassium is low."],
	colchicine: ["Diarrhea, nausea, and cramps. Those are dose-limiting.", "Serious: muscle weakness and low blood counts, especially with clarithromycin or if the kidneys are weak."],
	allopurinol: [
		"A gout flare when it first starts.",
		"Nausea.",
		"Serious: a rash with fever or mouth sores — stop and get care. The severe reaction is more likely with certain genetics and with kidney disease."
	]
};
var PRIORITY = [
	"opioid",
	"ssri",
	"snri",
	"ndri",
	"sari",
	"benzo",
	"zd",
	"gabapentinoid",
	"maoi",
	"insulin",
	"sulfonylurea",
	"biguanide",
	"glp1",
	"ghs",
	"nitrate",
	"pde5",
	"statin",
	"doac",
	"vka",
	"anticoagulant",
	"antiplatelet",
	"nsaid",
	"acei",
	"arb",
	"beta_blocker",
	"ccb_nondhp",
	"ccb_dhp",
	"loop",
	"thiazide",
	"k_sparing",
	"fluoroquinolone",
	"fq",
	"tetracycline",
	"macrolide",
	"penicillin",
	"ppi",
	"thyroid",
	"corticosteroid",
	"coc",
	"bisphosphonate",
	"saba",
	"ltra",
	"decongestant",
	"antihistamine",
	"alpha_blocker",
	"triptan",
	"5ht3",
	"zinc",
	"polyvalent"
];
function sideEffectsFor(drug) {
	const specific = BY_ID[drug.id];
	if (specific) return specific;
	for (const name of PRIORITY) if (drug.classes.includes(name) && BY_CLASS[name]) return BY_CLASS[name];
	for (const name of drug.classes) {
		const list = BY_CLASS[name];
		if (list) return list;
	}
	if (drug.classes.includes("antibiotic")) return BY_CLASS.antibiotic;
	return drug.watch;
}
var STORAGE_KEY = "rxmix.pair.v1";
var EXAMPLES = [
	{
		id: "bleed",
		label: "Warfarin + ibuprofen",
		detail: "A common bleed",
		ids: ["warfarin", "ibuprofen"]
	},
	{
		id: "kidney",
		label: "Lisinopril + ibuprofen",
		detail: "Kidneys and pressure",
		ids: ["lisinopril", "ibuprofen"]
	},
	{
		id: "cns",
		label: "Oxycodone + Xanax",
		detail: "Breathing risk",
		ids: ["oxycodone", "alprazolam"]
	},
	{
		id: "nitrate",
		label: "Nitro + sildenafil",
		detail: "Pressure crash",
		ids: ["nitroglycerin", "sildenafil"]
	},
	{
		id: "quiet",
		label: "Lisinopril + metformin",
		detail: "Often quiet in our list",
		ids: ["lisinopril", "metformin"]
	},
	{
		id: "minerals",
		label: "Cipro + iron",
		detail: "Neither one absorbs",
		ids: ["ciprofloxacin", "ferrous-sulfate"]
	},
	{
		id: "kratom",
		label: "Kratom + oxycodone",
		detail: "Opioid-like stacking",
		ids: ["kratom", "oxycodone"]
	},
	{
		id: "methadone",
		label: "Methadone + Xanax",
		detail: "Breathing, plus it lingers",
		ids: ["methadone", "alprazolam"]
	},
	{
		id: "bupe",
		label: "Suboxone + oxycodone",
		detail: "Can trigger withdrawal",
		ids: ["buprenorphine-naloxone", "oxycodone"]
	},
	{
		id: "glp",
		label: "Ozempic + insulin",
		detail: "Low blood sugar",
		ids: ["semaglutide", "insulin"]
	},
	{
		id: "peptides",
		label: "Ipamorelin + CJC-1295",
		detail: "Same growth-hormone signal",
		ids: ["ipamorelin", "cjc-1295"]
	}
];
var SEVERITY_META = {
	major: {
		label: "Serious",
		hint: "Ask before combining",
		badge: "bg-terra-soft text-terra",
		banner: "bg-terra-soft",
		icon: TriangleAlert
	},
	moderate: {
		label: "Worth a conversation",
		hint: "Don’t ignore it",
		badge: "bg-amber-soft text-amber",
		banner: "bg-amber-soft",
		icon: Info
	},
	minor: {
		label: "Smaller note",
		hint: "Still mention it",
		badge: "bg-minor-soft text-minor",
		banner: "bg-minor-soft",
		icon: Info
	}
};
function brandLine(drug) {
	if (drug.brands.length === 0) return drug.usedFor;
	return drug.brands.slice(0, 2).join(", ");
}
function Checker() {
	if (typeof document !== "undefined") document.title = "Rx Mix";
	const [slotA, setSlotA] = (0, import_react.useState)(null);
	const [slotB, setSlotB] = (0, import_react.useState)(null);
	const [checked, setChecked] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [queryA, setQueryA] = (0, import_react.useState)("");
	const [queryB, setQueryB] = (0, import_react.useState)("");
	const [openSlot, setOpenSlot] = (0, import_react.useState)(null);
	const [highlight, setHighlight] = (0, import_react.useState)(0);
	const [bucket, setBucket] = (0, import_react.useState)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const listA = (0, import_react.useId)();
	const listB = (0, import_react.useId)();
	const inputA = (0, import_react.useRef)(null);
	const inputB = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (parsed && typeof parsed === "object") {
					const record = parsed;
					if (typeof record.a === "string" && DRUG_BY_ID.has(record.a)) setSlotA(record.a);
					if (typeof record.b === "string" && DRUG_BY_ID.has(record.b)) setSlotB(record.b);
				}
			}
		} catch {}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			a: slotA,
			b: slotB
		}));
	}, [
		slotA,
		slotB,
		ready
	]);
	const activeQuery = openSlot === "b" ? queryB : queryA;
	const matches = (0, import_react.useMemo)(() => searchDrugs(activeQuery, 8), [activeQuery]);
	const canCheck = Boolean(slotA && slotB && slotA !== slotB);
	const drugs = (0, import_react.useMemo)(() => checked && canCheck ? drugsFromIds([slotA, slotB]) : [], [
		checked,
		canCheck,
		slotA,
		slotB
	]);
	const report = (0, import_react.useMemo)(() => checkInteractions(drugs), [drugs]);
	const activeFilter = filter !== "all" && report.counts[filter] === 0 ? "all" : filter;
	const visibleFindings = report.findings.filter((finding) => activeFilter === "all" || finding.severity === activeFilter);
	const bucketDrugs = bucket ? DRUGS.filter((drug) => drug.bucket === bucket) : [];
	const drugA = slotA ? DRUG_BY_ID.get(slotA) : void 0;
	const drugB = slotB ? DRUG_BY_ID.get(slotB) : void 0;
	function assign(slot, id) {
		if (slot === "a") {
			if (id === slotB) return;
			setSlotA(id);
			setQueryA("");
		} else {
			if (id === slotA) return;
			setSlotB(id);
			setQueryB("");
		}
		setChecked(false);
		setOpenSlot(null);
		setHighlight(0);
	}
	function clearSlot(slot) {
		if (slot === "a") setSlotA(null);
		else setSlotB(null);
		setChecked(false);
	}
	function fillEmpty(id) {
		if (id === slotA || id === slotB) return;
		if (!slotA) assign("a", id);
		else if (!slotB) assign("b", id);
	}
	function loadExample(next) {
		setSlotA(next[0] ?? null);
		setSlotB(next[1] ?? null);
		setQueryA("");
		setQueryB("");
		setChecked(true);
		setFilter("all");
		setOpenSlot(null);
	}
	function onKeyDown(slot, event) {
		if (event.key === "ArrowDown") {
			event.preventDefault();
			setOpenSlot(slot);
			setHighlight((index) => Math.min(index + 1, Math.max(matches.length - 1, 0)));
		} else if (event.key === "ArrowUp") {
			event.preventDefault();
			setHighlight((index) => Math.max(index - 1, 0));
		} else if (event.key === "Escape") setOpenSlot(null);
		else if (event.key === "Enter") {
			event.preventDefault();
			const pick = matches[highlight] ?? matches[0];
			if (pick && openSlot === slot) assign(slot, pick.id);
		}
	}
	async function copySummary() {
		const text = summaryText(drugs, report);
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 2e3);
		} catch {
			setCopied(false);
		}
	}
	const summary = buildSummary(drugs.length, report.highest, report.counts);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "no-print sticky top-0 z-20 border-b border-line bg-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-xl bg-green font-sans text-lg font-bold leading-none tracking-tight text-card",
						"aria-hidden": "true",
						children: "RX"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-sans text-xl font-bold leading-none tracking-tight text-ink",
						children: "Rx Mix"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Medicines, in plain English"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden max-w-xs text-right text-sm text-muted sm:block",
					children: "A curated check. Not a diagnosis, and not a full database."
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 py-6 sm:py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl text-ink sm:text-4xl",
						children: "What happens when these two are taken together?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-lg text-muted",
						children: "Put one medicine, peptide, or supplement in each box. Press Interactions. The result is only that pair, in plain language, plus the side effects of each one on its own."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 max-w-3xl rounded-2xl border border-line bg-card px-4 py-3 text-sm text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: "Educational only."
					}), " This is not medical advice, not a complete interaction list, and not a reason to start, stop, or change a medicine. Emergencies — trouble breathing, blue lips, chest pain, vomiting blood, black stools, a sudden severe headache, a seizure, or a blistering rash — need emergency services, not this page."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid items-start gap-6 lg:grid-cols-[22rem_minmax(0,1fr)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "no-print rounded-3xl border border-line bg-card p-4 sm:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl text-ink",
								children: "Check a pair"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "One item in each box. The button runs the check."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-col gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairBox, {
									label: "First medicine, peptide, or supplement",
									inputId: "slot-a",
									listId: listA,
									selected: drugA,
									query: queryA,
									open: openSlot === "a" && queryA.trim().length > 0,
									matches: openSlot === "a" ? matches : [],
									highlight,
									inputRef: inputA,
									onQuery: (value) => {
										setQueryA(value);
										setOpenSlot("a");
										setHighlight(0);
									},
									onFocus: () => {
										setOpenSlot("a");
										setHighlight(0);
									},
									onKeyDown: (event) => onKeyDown("a", event),
									onPick: (id) => assign("a", id),
									onClear: () => clearSlot("a")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairBox, {
									label: "Second medicine, peptide, or supplement",
									inputId: "slot-b",
									listId: listB,
									selected: drugB,
									query: queryB,
									open: openSlot === "b" && queryB.trim().length > 0,
									matches: openSlot === "b" ? matches : [],
									highlight,
									inputRef: inputB,
									onQuery: (value) => {
										setQueryB(value);
										setOpenSlot("b");
										setHighlight(0);
									},
									onFocus: () => {
										setOpenSlot("b");
										setHighlight(0);
									},
									onKeyDown: (event) => onKeyDown("b", event),
									onPick: (id) => assign("b", id),
									onClear: () => clearSlot("b")
								})]
							}),
							slotA && slotB && slotA === slotB && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-terra",
								role: "status",
								children: "Pick two different items. The same medicine in both boxes is not a mix."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !canCheck,
								onClick: () => setChecked(true),
								className: "mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-green text-base font-bold text-card disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									className: "size-5",
									"aria-hidden": "true"
								}), "Interactions"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: canCheck ? "Both boxes are filled. Press Interactions to see this pair." : "Fill both boxes to run the check."
							}),
							(slotA || slotB) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setSlotA(null);
									setSlotB(null);
									setChecked(false);
									setQueryA("");
									setQueryB("");
								},
								className: "mt-2 inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Clear both"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-wide text-muted uppercase",
									children: "Quick add"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: QUICK_ADD.map((id) => {
										const drug = DRUG_BY_ID.get(id);
										if (!drug) return null;
										const added = id === slotA || id === slotB;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											disabled: added || Boolean(slotA && slotB),
											onClick: () => fillEmpty(id),
											className: "inline-flex min-h-11 items-center gap-1 rounded-full border border-line bg-paper px-3 text-sm font-semibold text-ink disabled:text-muted",
											children: [added ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
												className: "size-4 text-green",
												"aria-hidden": "true"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												"aria-hidden": "true",
												children: "+"
											}), drug.generic]
										}, id);
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-wide text-muted uppercase",
									children: "Load an example"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-col gap-2",
									children: EXAMPLES.map((example) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => loadExample(example.ids),
										className: "flex min-h-11 items-center justify-between gap-3 rounded-xl border border-line px-3 py-2 text-left",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-semibold text-ink",
											children: example.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm text-muted",
											children: example.detail
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
											className: "size-4 -rotate-90 text-muted",
											"aria-hidden": "true"
										})]
									}, example.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "mt-5 border-t border-line pt-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
										className: "flex min-h-11 items-center justify-between gap-3 text-sm font-semibold text-ink",
										children: ["Browse by type", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
											className: "size-4 text-muted",
											"aria-hidden": "true"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 flex flex-wrap gap-2",
										children: BUCKETS.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": bucket === name,
											onClick: () => setBucket((current) => current === name ? null : name),
											className: `min-h-11 rounded-full border px-3 text-sm font-semibold ${bucket === name ? "border-green bg-green text-card" : "border-line bg-paper text-ink"}`,
											children: name
										}, name))
									}),
									bucket && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-3 max-h-64 overflow-auto rounded-xl border border-line",
										children: bucketDrugs.map((drug) => {
											const added = drug.id === slotA || drug.id === slotB;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
												className: "border-b border-line last:border-b-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													disabled: added || Boolean(slotA && slotB),
													onClick: () => fillEmpty(drug.id),
													className: "flex min-h-11 w-full items-center justify-between gap-3 px-3 text-left disabled:text-muted",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "block font-semibold",
														children: drug.generic
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "block text-sm text-muted",
														children: brandLine(drug)
													})] }), added ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
														className: "size-4 text-green",
														"aria-hidden": "true"
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-sm",
														children: "Add"
													})]
												})
											}, drug.id);
										})
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						"aria-live": "polite",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `rounded-3xl border border-line px-4 py-4 sm:px-5 ${summary.panel}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-sm font-semibold ${canCheck && !checked ? "text-green-ink" : summary.kicker}`,
										children: canCheck && !checked ? "Ready" : summary.kickerText
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-1 text-3xl text-ink",
										children: canCheck && !checked ? "Press Interactions" : summary.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-ink",
										children: canCheck && !checked ? "The two boxes are filled. The check runs when you press the button, and only for that pair." : summary.body
									}),
									drugs.length >= 2 && report.findings.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 text-sm font-semibold text-muted tabular-nums",
										children: [
											report.counts.major,
											" serious · ",
											report.counts.moderate,
											" to discuss · ",
											report.counts.minor,
											" smaller"
										]
									})
								]
							}),
							drugs.length >= 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "no-print mt-4 flex flex-wrap gap-2",
								children: [[
									["all", "All"],
									["major", "Serious"],
									["moderate", "Conversation"],
									["minor", "Smaller"]
								].map(([key, label]) => {
									const count = key === "all" ? report.findings.length : report.counts[key];
									const selected = activeFilter === key;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-pressed": selected,
										disabled: count === 0,
										onClick: () => setFilter(key),
										className: `min-h-11 rounded-full border px-3 text-sm font-semibold disabled:opacity-40 ${selected ? "border-green bg-green text-card" : "border-line bg-card text-ink"}`,
										children: [
											label,
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "tabular-nums",
												children: count
											})
										]
									}, key);
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => void copySummary(),
									className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-card px-3 text-sm font-semibold text-ink",
									children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "size-4 text-green",
										"aria-hidden": "true"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
										className: "size-4",
										"aria-hidden": "true"
									}), copied ? "Copied" : "Copy for a pharmacist"]
								})]
							}),
							drugs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Intro, {}),
							drugs.length === 1 && drugs[0] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-sm text-muted",
								children: [
									"Add another item to check overlaps. Cautions for ",
									drugs[0].generic,
									" are below either way."
								]
							}),
							drugs.length >= 2 && report.findings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "mt-4 rounded-3xl border border-line bg-card p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-2xl text-ink",
									children: "What “nothing found” does and doesn’t mean"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-ink",
									children: "These items don’t hit a rule in our curated set. That set is common medicines and well-known overlaps — not every dose, gene, food, or new warning. A pharmacist with your full bottle list is still the right check."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex flex-col gap-4",
								children: visibleFindings.map((finding) => {
									const meta = SEVERITY_META[finding.severity];
									const Icon = meta.icon;
									const pairLines = finding.pairs.map((pair) => pair.map((id) => DRUG_BY_ID.get(id)?.generic ?? id).join(" + "));
									const pairHeading = finding.pairs.length > 1 ? "Each line is only that combination" : (finding.pairs[0]?.length ?? 0) > 2 ? "These medicines only" : "This pair only";
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "rounded-3xl border border-line bg-card p-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: `inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-semibold ${meta.badge}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
														className: "size-4",
														"aria-hidden": "true"
													}),
													meta.label,
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-medium",
														children: ["· ", meta.hint]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-3 text-2xl text-ink",
												children: finding.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs font-semibold tracking-wide text-muted uppercase",
														children: pairHeading
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
														className: "mt-1 flex flex-col gap-1",
														children: pairLines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
															className: "font-semibold text-ink",
															children: line
														}, line))
													}),
													finding.pairs.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-sm text-muted",
														children: "The explanation below is written once. It is not a new interaction, and it does not mean every medicine on your list is in one mix."
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 text-base text-ink",
												children: finding.plain
											}),
											finding.notice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold tracking-wide text-muted uppercase",
													children: "What you might notice"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-ink",
													children: finding.notice
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `mt-4 rounded-2xl px-4 py-3 ${meta.banner}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold tracking-wide text-muted uppercase",
													children: "What to do"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-ink",
													children: finding.whatToDo
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold tracking-wide text-muted uppercase",
													children: "Why this happens"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-sm text-ink",
													children: finding.why
												})]
											}),
											finding.howSure && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-3 text-sm text-muted",
												children: ["How solid this is: ", finding.howSure]
											})
										]
									}, finding.id);
								})
							}),
							drugs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex flex-col gap-4",
								children: drugs.map((drug) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-3xl border border-line bg-card p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold tracking-wide text-muted uppercase",
											children: "Side effects"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-1 text-2xl text-ink",
											children: drug.generic
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-muted",
											children: "Common effects and the serious ones to recognize. Not every rare effect on a label."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "mt-3 flex flex-col gap-2",
											children: sideEffectsFor(drug).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
												className: "text-sm text-ink",
												children: item
											}, item))
										})
									]
								}, drug.id))
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: "mt-10 max-w-3xl border-t border-line pt-6 text-sm text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Rx Mix checks one pair at a time: prescriptions, peptides, and common supplements. Blackout peptide and NAD+ are not in this list. Side effects here are the common and serious ones, not every rare reaction. It can miss dose-dependent, genetic, and newly discovered interactions. Wording is simplified from patterns described in drug labels and standard references. It is not those references, and it is not a substitute for a pharmacist, clinician, or emergency service." })
				})
			]
		})]
	});
}
function PairBox({ label, inputId, listId, selected, query, open, matches, highlight, inputRef, onQuery, onFocus, onKeyDown, onPick, onClear }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: inputId,
			className: "text-sm font-semibold text-ink",
			children: label
		}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex h-14 items-center justify-between gap-2 rounded-xl border border-green bg-green-soft px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate font-semibold text-ink",
					children: selected.generic
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-sm text-muted",
					children: brandLine(selected)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClear,
				"aria-label": `Clear ${selected.generic}`,
				className: "inline-flex size-11 shrink-0 items-center justify-center rounded-xl text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "pointer-events-none absolute top-[2.35rem] left-3 size-5 text-muted",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: inputId,
				ref: inputRef,
				role: "combobox",
				"aria-expanded": open,
				"aria-controls": listId,
				"aria-autocomplete": "list",
				value: query,
				placeholder: "Search a name or brand",
				className: "mt-1 h-14 w-full rounded-xl border border-line bg-paper pr-4 pl-11 text-base text-ink placeholder:text-muted",
				onChange: (event) => onQuery(event.target.value),
				onFocus,
				onKeyDown
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				id: listId,
				role: "listbox",
				className: "absolute z-30 mt-1 max-h-72 w-full overflow-auto rounded-xl border border-line bg-card",
				children: matches.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-4 py-3 text-sm text-muted",
					children: "Not in this list. Try a generic name, a brand, or a peptide people actually search."
				}) : matches.map((drug, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					role: "option",
					"aria-selected": index === highlight,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: `flex min-h-11 w-full flex-col items-start px-4 py-2 text-left ${index === highlight ? "bg-green-soft" : "bg-card"}`,
						onMouseDown: (event) => event.preventDefault(),
						onClick: () => onPick(drug.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-ink",
							children: drug.generic
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-muted",
							children: [
								brandLine(drug),
								" · ",
								drug.bucket
							]
						})]
					})
				}, drug.id))
			})
		] })]
	});
}
function Intro() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 grid gap-3 sm:grid-cols-3",
		children: [
			[
				"Serious",
				"Ask before combining",
				"Blood pressure crashes, slowed breathing, bleeding, kidney injury."
			],
			[
				"Conversation",
				"Don’t shrug it off",
				"Dose caps, lab checks, or a pairing that is sometimes intentional."
			],
			[
				"Smaller note",
				"Mention it anyway",
				"Duplicate bottles, timing gaps, supplements with a mild effect."
			]
		].map(([title, hint, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl border border-line bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-xl text-ink",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm font-semibold text-green-ink",
					children: hint
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: body
				})
			]
		}, title))
	});
}
function buildSummary(count, highest, counts) {
	if (count === 0) return {
		kickerText: "How a result reads",
		kicker: "text-green-ink",
		title: "Plain language, sorted by how much it matters",
		body: "Fill both boxes and press Interactions. A quiet result is shown honestly — silence here is not a safety certificate.",
		panel: "bg-card"
	};
	if (count === 1) return {
		kickerText: "One item",
		kicker: "text-muted",
		title: "Add a second to check an overlap",
		body: "Single medicines still carry their own cautions — timing, food, and what not to bolt on later.",
		panel: "bg-card"
	};
	if (!highest) return {
		kickerText: "No rule hit",
		kicker: "text-green-ink",
		title: "Nothing in our list between these",
		body: "No curated interaction fired. Read the limit under the result before you treat that as an all-clear.",
		panel: "bg-green-soft"
	};
	if (highest === "major") return {
		kickerText: "Needs a real answer",
		kicker: "text-terra",
		title: counts.major === 1 ? "One serious interaction" : `${counts.major} serious interactions`,
		body: "Read these before the milder notes. Don’t change a prescribed medicine tonight because a page said so — do get a pharmacist or prescriber on the list.",
		panel: "bg-terra-soft"
	};
	if (highest === "moderate") return {
		kickerText: "Worth a conversation",
		kicker: "text-amber",
		title: "Something here should be mentioned",
		body: "No top-tier alarm in our list. These are still the kind of overlaps a pharmacist wants to hear about before you add a bottle.",
		panel: "bg-amber-soft"
	};
	return {
		kickerText: "Smaller notes only",
		kicker: "text-minor",
		title: "No serious overlap in our list",
		body: "A few lesser points are worth naming at your next visit. Absence of a serious flag is not a complete safety check.",
		panel: "bg-minor-soft"
	};
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checker, {});
}
//#endregion
export { Home as component };
