//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DD27HR3P.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BwrCiOji.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BwrCiOji.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CbyjKRLL.js"]
	}
} });
//#endregion
export { tsrStartManifest };
