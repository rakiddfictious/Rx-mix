//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C77b3EeR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DuW_WzPk.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DuW_WzPk.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DLd9z1S-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
